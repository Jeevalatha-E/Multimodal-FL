"""
STAGE 09 — Non-IID FedAvg vs FedProx (roadmap PHASE 14-15)

Controlled heterogeneity via class-wise Dirichlet(alpha). Sweeps alpha (IID-ish -> strong
non-IID) and compares FedAvg vs FedProx under identical splits/seeds.

Needs: numpy, torch.  Colab: !python stage09_non_iid.py
Outputs -> results/07_non_iid/{stage09_report.txt, non_iid.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import numpy as np

from ppflfm_common import get_feature_dirs, stage_dir, append_results, MODEL, FL, TRAIN, SEED
from ppflfm_eval import classification_metrics, verification_metrics
from ppflfm_ml import load_windows, run_federated, predict_proba


def evaluate(model, d):
    proba = predict_proba(model, d["X_test"])
    cls = classification_metrics(d["y_test"], proba.argmax(1), n_classes=d["n_classes"])
    ver = verification_metrics(proba, d["y_test"], labels=np.arange(d["n_classes"]))
    return cls, ver


def main():
    _, processed, _ = get_feature_dirs()
    out = stage_dir("07_non_iid")
    d = load_windows(processed)
    cfg = {**FL, **TRAIN}

    rows, ledger, report = [], [], []
    for alpha in FL["dirichlet_alpha"]:
        for method, mu in (("FedAvg", 0.0), ("FedProx", FL["fedprox_mu"])):
            model, hist, sizes = run_federated(d, cfg, alpha=alpha, aggregation="fedavg",
                                               mu=mu, seed=SEED, norm=MODEL["norm"])
            cls, ver = evaluate(model, d)
            rows.append(dict(alpha=alpha, method=method, accuracy=cls["accuracy"],
                             macro_f1=cls["macro_f1"], eer=ver["eer"], auc=ver["auc"],
                             min_client=min(sizes), max_client=max(sizes)))
            ledger.append(dict(stage="09_non_iid", method=method, setting=f"alpha={alpha}",
                               seed=SEED, task="A+B", accuracy=cls["accuracy"],
                               macro_f1=cls["macro_f1"], balanced_accuracy=cls["balanced_accuracy"],
                               eer=ver["eer"], auc=ver["auc"], macro_eer=ver["macro_eer"]))
            msg = (f"  alpha={alpha:<5} {method:8s} acc={cls['accuracy']:.4f} "
                   f"macroF1={cls['macro_f1']:.4f} EER={ver['eer']:.4f} "
                   f"(client sizes {min(sizes)}..{max(sizes)})")
            print(msg); report.append(msg)

    with open(out / "non_iid.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    append_results(ledger)
    txt = ("=" * 70 + "\nSTAGE 09 - NON-IID (Dirichlet) FedAvg vs FedProx\n" + "=" * 70 +
           f"\nlower alpha = stronger heterogeneity\n\n" + "\n".join(report) + "\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage09_report.txt").write_text(txt, "utf-8")
    print(f"[stage09] wrote {out}")


if __name__ == "__main__":
    main()
