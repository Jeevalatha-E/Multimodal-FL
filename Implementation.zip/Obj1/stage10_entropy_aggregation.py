"""
STAGE 10 — Proposed entropy-weighted aggregation vs FedAvg (roadmap PHASE 16)

Compares the proposed aggregation  alpha_k = (1/H(p_k)) / sum_j (1/H(p_j))  against
FedAvg under IID and several non-IID levels, with identical splits/seeds.

We do NOT assume entropy weighting wins — the code decides. If FedAvg is better, we
report that (it strengthens credibility).

Needs: numpy, torch.  Colab: !python stage10_entropy_aggregation.py
Outputs -> results/08_entropy/{stage10_report.txt, entropy_vs_fedavg.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import numpy as np

from ppflfm_common import get_feature_dirs, stage_dir, append_results, MODEL, FL, TRAIN, SEED
from ppflfm_eval import classification_metrics, verification_metrics
from ppflfm_ml import load_windows, run_federated, predict_proba


def evaluate(model, d):
    proba = predict_proba(model, d["X_test"])
    cls = classification_metrics(d["y_test"], proba.argmax(1), n_classes=d["n_classes"])
    ver = verification_metrics(proba, d["y_test"], labels=np.arange(d["n_classes"]))
    return cls, ver


def main():
    _, processed, _ = get_feature_dirs()
    out = stage_dir("08_entropy")
    d = load_windows(processed)
    cfg = {**FL, **TRAIN}
    settings = [("IID", None)] + [(f"alpha={a}", a) for a in FL["dirichlet_alpha"]]

    rows, ledger, report = [], [], []
    for label, alpha in settings:
        res = {}
        for agg in ("fedavg", "entropy"):
            model, hist, sizes = run_federated(d, cfg, alpha=alpha, aggregation=agg, seed=SEED,
                                               norm=MODEL["norm"])
            cls, ver = evaluate(model, d)
            res[agg] = (cls, ver)
            ledger.append(dict(stage="10_entropy",
                               method=("FedAvg" if agg == "fedavg" else "EntropyAgg"),
                               setting=label, seed=SEED, task="A+B",
                               accuracy=cls["accuracy"], macro_f1=cls["macro_f1"],
                               balanced_accuracy=cls["balanced_accuracy"],
                               eer=ver["eer"], auc=ver["auc"], macro_eer=ver["macro_eer"]))
        fa, en = res["fedavg"][0], res["entropy"][0]
        winner = "Entropy" if en["accuracy"] > fa["accuracy"] else "FedAvg"
        rows.append(dict(setting=label, fedavg_acc=fa["accuracy"], entropy_acc=en["accuracy"],
                         fedavg_eer=res["fedavg"][1]["eer"], entropy_eer=res["entropy"][1]["eer"],
                         winner_acc=winner))
        msg = (f"  {label:10s} FedAvg acc={fa['accuracy']:.4f} | "
               f"Entropy acc={en['accuracy']:.4f}  -> winner: {winner}")
        print(msg); report.append(msg)

    with open(out / "entropy_vs_fedavg.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    append_results(ledger)
    txt = ("=" * 70 + "\nSTAGE 10 - ENTROPY-WEIGHTED vs FedAvg\n" + "=" * 70 +
           "\n(the data decides; we do not assume the proposed method wins)\n\n" +
           "\n".join(report) + "\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage10_report.txt").write_text(txt, "utf-8")
    print(f"[stage10] wrote {out}")


if __name__ == "__main__":
    main()
