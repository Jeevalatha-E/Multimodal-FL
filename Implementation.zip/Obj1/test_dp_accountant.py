"""
test_dp_accountant.py — independent audit of the RDP privacy accountant (review MUST).

Two layers of checking:
  1) PROPERTY tests (must always hold for a correct subsampled-Gaussian accountant):
       - epsilon decreases as sigma increases
       - epsilon increases with the number of steps
       - epsilon increases with the sampling rate q
       - sigma -> large  =>  epsilon -> ~0
  2) REFERENCE comparison against Opacus' RDPAccountant (the trusted implementation)
     for the EXACT config Stage 12 uses. If Opacus isn't installed, this layer is
     skipped with a clear message (in Colab: `!pip install opacus`).

Run:  python test_dp_accountant.py
      (in Colab, first: !pip install opacus  -- to enable the reference check)
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ppflfm_ml import dp_epsilon  # noqa: E402

# Stage-12 realistic config: train windows ~23722, batch 256, 15 epochs.
N, BATCH, EPOCHS = 23722, 256, 15
Q = BATCH / N
STEPS = EPOCHS * -(-N // BATCH)     # ceil(N/BATCH) steps per epoch
DELTA = 1e-5
SIGMAS = [0.5, 1.0, 2.0, 4.0]


def property_tests():
    ok = True
    print("PROPERTY TESTS")
    eps = {s: dp_epsilon(Q, s, STEPS, DELTA) for s in SIGMAS}
    mono_sigma = all(eps[SIGMAS[i]] > eps[SIGMAS[i + 1]] for i in range(len(SIGMAS) - 1))
    print(f"  eps decreasing in sigma: {['%.3f' % eps[s] for s in SIGMAS]} -> {mono_sigma}")
    ok = ok and mono_sigma
    e1 = dp_epsilon(Q, 1.0, STEPS, DELTA); e2 = dp_epsilon(Q, 1.0, STEPS * 2, DELTA)
    print(f"  eps increasing in steps: {e1:.3f} (T) < {e2:.3f} (2T) -> {e2 > e1}")
    ok = ok and (e2 > e1)
    eqa = dp_epsilon(Q, 1.0, STEPS, DELTA); eqb = dp_epsilon(Q * 2, 1.0, STEPS, DELTA)
    print(f"  eps increasing in q: {eqa:.3f} (q) < {eqb:.3f} (2q) -> {eqb > eqa}")
    ok = ok and (eqb > eqa)
    ebig = dp_epsilon(Q, 50.0, STEPS, DELTA)
    print(f"  sigma huge -> eps ~0: eps(sigma=50)={ebig:.4f} -> {ebig < 0.5}")
    ok = ok and (ebig < 0.5)
    return ok, eps


def opacus_reference(eps_ours):
    try:
        from opacus.accountants import RDPAccountant
    except Exception as e:
        print(f"\nREFERENCE (Opacus): SKIPPED ({e}). In Colab run: !pip install opacus")
        return None
    print("\nREFERENCE COMPARISON vs Opacus RDPAccountant")
    print("  (ours = conservative integer-order RDP UPPER bound; expect ours >= opacus,")
    print("   within a small factor. ours < opacus would be UNSAFE and fails.)")
    ok = True
    for s in SIGMAS:
        acc = RDPAccountant()
        for _ in range(STEPS):
            acc.step(noise_multiplier=s, sample_rate=Q)
        eps_op = acc.get_epsilon(delta=DELTA)
        # safe (conservative) if ours is not below opacus and not wildly above (<=1.5x)
        safe = eps_ours[s] >= eps_op * 0.95 and eps_ours[s] <= eps_op * 1.5 + 0.5
        ok = ok and safe
        print(f"  sigma={s:4}: ours={eps_ours[s]:9.3f}  opacus={eps_op:9.3f}  "
              f"ratio={eps_ours[s]/max(eps_op,1e-9):5.2f}x  {'OK(conservative)' if safe else 'CHECK'}")
    return ok


def main():
    print(f"config: N={N} batch={BATCH} q={Q:.5f} steps={STEPS} delta={DELTA}\n")
    ok, eps = property_tests()
    ref = opacus_reference(eps)
    overall = ok and (ref is not False)
    print("\n" + ("ALL CHECKS PASS" if overall else "SOME CHECKS FAILED"))
    if ref is None:
        print("(reference check skipped — install opacus for the full independent audit)")
    sys.exit(0 if overall else 1)


if __name__ == "__main__":
    main()
