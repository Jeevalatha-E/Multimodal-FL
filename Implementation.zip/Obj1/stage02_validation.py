"""
STAGE 02 — Keystroke data-quality validation / Gate 1  (expanded, review point #4/#5)

Reconstructs each user x device raw keyboard stream and runs an expanded battery of
integrity + statistical checks BEFORE any split/feature work.

Integrity (hard gate — must pass):
  no negative holds, no bad/malformed rows, no impossible timestamps (year outside
  2016-2018), no non-monotonic raw events.
Reported (not auto-failed; logged for inspection):
  missing/empty streams (known BB-MAS gaps), duplicate raw events, duplicate
  timestamps, extremely short holds (<1 ms), suspicious long holds (>=5 s).
Distributions (per user x device): keypress count, duration, hold p05/p50/p95,
  inter-key (down-down) p50/p95.

Suspicious-hold POLICY (explicit, review #5): hold < 5 s -> retain;
  hold >= 5 s -> flag & log for investigation (NEVER auto-deleted here).

Colab: !python stage02_validation.py
Outputs -> results/01_data_validation/{keystroke_validation.csv, keystroke_quality.json,
           stage02_report.txt}  + gate
"""
from __future__ import annotations

import csv
import json
import statistics
import sys
from collections import Counter
from pathlib import Path

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

from ppflfm_common import (resolve_root, get_out_dirs, user_folders, DEVICES,
                           resolve_keyboard_path, reconstruct, load_raw_events,
                           write_gate, SUSPICIOUS_HOLD_MS)

SHORT_HOLD_MS = 1.0
VALID_YEARS = (2016, 2017, 2018)


def pctl(xs, q):
    if not xs:
        return 0.0
    s = sorted(xs)
    return s[min(len(s) - 1, int(q * (len(s) - 1)))]


def main():
    root = resolve_root()
    _, out_dir, _ = get_out_dirs()
    uids = user_folders(root)
    print(f"[stage02] validating {len(uids)} users x {len(DEVICES)} devices")

    rows = []
    for uid in uids:
        udir = root / str(uid)
        for dev in DEVICES:
            kpath = resolve_keyboard_path(udir, dev)
            if kpath is None:
                rows.append(dict(user=uid, device=dev, present=0, empty=0, keypresses=0,
                                 raw_events=0, distinct_keys=0, duration_s=0, orphan_down=0,
                                 orphan_up=0, bad_rows=0, nonmonotonic=0, neg_hold=0,
                                 dup_events=0, dup_timestamps=0, impossible_ts=0,
                                 short_hold=0, susp_hold=0, hold_p05=0, hold_p50=0, hold_p95=0,
                                 ik_p50=0, ik_p95=0, note="MISSING_FILE"))
                continue
            events, n_bad, n_nonmono = load_raw_events(kpath)
            empty = 1 if not events else 0
            # duplicates / impossible timestamps on raw events
            seen = Counter((k, d, t) for k, d, t in events)
            dup_events = sum(c - 1 for c in seen.values() if c > 1)
            ts_counts = Counter(t for _, _, t in events)
            dup_ts = sum(c - 1 for c in ts_counts.values() if c > 1)
            impossible = sum(1 for _, _, t in events if t.year not in VALID_YEARS)

            r = reconstruct(kpath)
            kps = r.keypresses
            holds = [k.hold_ms for k in kps]
            ik = [(kps[i + 1].t_down - kps[i].t_down).total_seconds() * 1000.0
                  for i in range(len(kps) - 1)]
            short = sum(1 for h in holds if h < SHORT_HOLD_MS)
            if kps:
                dur = (kps[-1].t_down - kps[0].t_down).total_seconds()
                distinct = len({k.key for k in kps})
            else:
                dur = distinct = 0
            rows.append(dict(
                user=uid, device=dev, present=1, empty=empty, keypresses=len(kps),
                raw_events=len(events), distinct_keys=distinct, duration_s=round(dur, 1),
                orphan_down=r.n_orphan_down, orphan_up=r.n_orphan_up, bad_rows=n_bad,
                nonmonotonic=n_nonmono, neg_hold=r.n_negative_hold, dup_events=dup_events,
                dup_timestamps=dup_ts, impossible_ts=impossible, short_hold=short,
                susp_hold=r.n_suspicious_hold,
                hold_p05=round(pctl(holds, 0.05), 1), hold_p50=round(pctl(holds, 0.50), 1),
                hold_p95=round(pctl(holds, 0.95), 1),
                ik_p50=round(pctl(ik, 0.50), 1), ik_p95=round(pctl(ik, 0.95), 1), note=""))
        print(f"  user {uid:3d}", end="\r")
    print()

    with open(out_dir / "keystroke_validation.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

    present = [r for r in rows if r["present"]]
    missing = [r for r in rows if not r["present"]]
    S = lambda k: sum(r[k] for r in present)  # noqa: E731

    integrity = {
        "no_negative_holds": S("neg_hold") == 0,
        "no_bad_rows": S("bad_rows") == 0,
        "no_impossible_timestamps": S("impossible_ts") == 0,
        "no_nonmonotonic_events": S("nonmonotonic") == 0,
        "no_empty_present_streams": sum(r["empty"] for r in present) == 0,
    }
    quality = dict(
        n_users=len(uids), streams_present=len(present), streams_missing=len(missing),
        missing=[f"{r['user']}|{r['device']}" for r in missing],
        total_keypresses=S("keypresses"),
        reported=dict(dup_events=S("dup_events"), dup_timestamps=S("dup_timestamps"),
                      short_holds=S("short_hold"), suspicious_holds=S("susp_hold"),
                      orphan_down=S("orphan_down"), orphan_up=S("orphan_up")),
        per_device={dev: dict(streams=sum(1 for r in present if r["device"] == dev),
                              keypresses=sum(r["keypresses"] for r in present if r["device"] == dev))
                    for dev in DEVICES},
        integrity_gates=integrity, gate_pass=all(integrity.values()),
        suspicious_hold_policy=f"<{int(SUSPICIOUS_HOLD_MS)}ms retain; >= flag+log (never auto-delete)",
    )
    (out_dir / "keystroke_quality.json").write_text(json.dumps(quality, indent=2), "utf-8")
    write_gate("stage02", quality["gate_pass"], {k: v for k, v in integrity.items()})

    L = ["=" * 70, "STAGE 02 - KEYSTROKE DATA-QUALITY VALIDATION (expanded)", "=" * 70,
         f"users                : {len(uids)}",
         f"streams present      : {len(present)} / {len(uids)*len(DEVICES)}",
         f"streams missing      : {len(missing)}  {quality['missing']}  [known BB-MAS gaps]",
         f"total keypresses     : {S('keypresses'):,}", "",
         "INTEGRITY GATES (must pass):"]
    for k, v in integrity.items():
        L.append(f"  [{'PASS' if v else 'FAIL'}] {k}")
    L += ["", "REPORTED (logged, not auto-failed):",
          f"  duplicate raw events : {S('dup_events')}",
          f"  duplicate timestamps : {S('dup_timestamps')}",
          f"  short holds (<1ms)   : {S('short_hold')}",
          f"  suspicious holds(>=5s): {S('susp_hold')}   [policy: retain<5s, flag>=5s]",
          f"  orphan down/up       : {S('orphan_down')}/{S('orphan_up')}", "",
          "Per device:"]
    for dev in DEVICES:
        pd = quality["per_device"][dev]
        L.append(f"  {dev:8s} streams={pd['streams']:3d} keypresses={pd['keypresses']:>9,}")
    L += ["", f"GATE 1 (data) verdict: {'PASS' if quality['gate_pass'] else 'FAIL'}", "=" * 70]
    report = "\n".join(L)
    print(report)
    (out_dir / "stage02_report.txt").write_text(report, "utf-8")
    if not quality["gate_pass"]:
        sys.exit("[stage02] GATE 1 FAILED — fix data integrity before splitting.")
    print(f"[stage02] wrote outputs to {out_dir}")


if __name__ == "__main__":
    main()
