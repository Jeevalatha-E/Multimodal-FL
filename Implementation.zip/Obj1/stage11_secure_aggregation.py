"""
STAGE 11 — Secure aggregation: DIRECT numerical-equivalence test (review #10/#16)

The correct test compares the SAME client updates under plain aggregation vs secure
aggregation and checks ||A_plain - A_secure||_inf ~ machine precision — NOT two
separately trained models. Pairwise additive masks cancel in the sum, so the server
never sees an individual update yet the aggregate is preserved exactly.

Tested for K in {2,3,5,10} on realistic model-sized update vectors, plus a weighted
aggregation case. Also measures communication overhead and aggregation latency.

Colab: !python stage11_secure_aggregation.py   (needs numpy, torch)
Outputs -> results/09_secure/{stage11_report.txt, secure_agg.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import time

import numpy as np
import torch

from ppflfm_common import stage_dir, append_results, SEED
from ppflfm_ml import secure_aggregate

TOL = 1e-9
DIM = 11_000            # ~ BehaviorAuthNet parameter count (15->128->64->117)


def direct_test(K, weighted, seed=SEED):
    rng = np.random.default_rng(seed + K)
    # realistic update magnitudes ~ N(0, 0.02)
    vecs = [torch.tensor(rng.normal(0, 0.02, DIM), dtype=torch.float64) for _ in range(K)]
    if weighted:
        w = rng.random(K); w = w / w.sum()
        plain = torch.stack([v * wk for v, wk in zip(vecs, w)]).sum(0)
        masked_input = [v * wk for v, wk in zip(vecs, w)]
    else:
        plain = torch.stack(vecs).sum(0)
        masked_input = vecs
    t0 = time.perf_counter()
    agg, overhead = secure_aggregate(masked_input, seed=seed)
    latency_ms = (time.perf_counter() - t0) * 1000
    err = float((agg - plain).abs().max())
    return err, overhead, latency_ms


def main():
    out = stage_dir("09_secure")
    rows, report = [], []
    all_ok = True
    print(f"[stage11] DIRECT equivalence test (dim={DIM}, tol={TOL})")
    for K in (2, 3, 5, 10):
        for weighted in (False, True):
            err, overhead, lat = direct_test(K, weighted)
            ok = err < TOL
            all_ok = all_ok and ok
            tag = "weighted" if weighted else "uniform "
            rows.append(dict(K=K, mode=tag.strip(), max_abs_err=f"{err:.2e}",
                             overhead_floats_per_client=overhead, latency_ms=round(lat, 2),
                             pass_=int(ok)))
            msg = (f"  K={K:2d} {tag} ||plain-secure||_inf={err:.2e} "
                   f"overhead={overhead} floats/client  {'PASS' if ok else 'FAIL'}")
            print(msg); report.append(msg)

    with open(out / "secure_agg.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    append_results([dict(stage="11_secure", method="SecureAgg", setting="direct_equivalence",
                         seed=SEED, task="-", extra=f"max_err<{TOL}={all_ok}")])

    txt = ("=" * 70 + "\nSTAGE 11 - SECURE AGGREGATION (direct equivalence)\n" + "=" * 70 +
           f"\nSame client updates -> plain vs secure aggregate, ||.||_inf tol={TOL}\n\n" +
           "\n".join(report) +
           f"\n\nVERDICT: {'ALL PASS - aggregate preserved to machine precision' if all_ok else 'FAIL'}"
           "\nMasks scale with the signal RMS, so individual updates stay hidden while"
           "\nthe sum cancels exactly. (Real deployment would add fixed-point + modular"
           "\narithmetic for bit-exactness and dropout robustness.)\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage11_report.txt").write_text(txt, "utf-8")
    if not all_ok:
        raise SystemExit("[stage11] secure aggregation equivalence FAILED")
    print(f"[stage11] wrote {out}")


if __name__ == "__main__":
    main()
