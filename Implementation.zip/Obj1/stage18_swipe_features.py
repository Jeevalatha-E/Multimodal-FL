"""
STAGE 18 — Swipe modality: leakage-safe features + quick eval  (multimodal step 1)

Reconstructs swipe strokes from raw TouchEvent (Phone/Tablet), builds a leakage-safe
per-stroke dataset (temporal within-device + cross-device LODO), runs the SAME leakage
auditor as keystroke, fits a train-only scaler, saves npz, and reports a quick
centralized BehaviorAuthNet evaluation so swipe's discriminative power is visible now.

Colab: !python stage18_swipe_features.py   (needs numpy, torch; run stages 01-04 first
        for the gate; swipe uses its own raw reconstruction)
Outputs -> data/processed/swipe_windows.npz (+ _lodo_{Phone,Tablet}.npz),
           results/16_swipe/{stage18_report.txt, swipe_audit*.json, swipe_eval.csv}
"""
from __future__ import annotations

import csv
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

from ppflfm_common import (resolve_root, get_feature_dirs, stage_dir, append_results,
                           require_gate, make_stream_split, leakage_audit, user_folders,
                           FEATURES, TRAIN, SEED)
from ppflfm_eval import classification_metrics, verification_metrics, whole_session_aggregate
from ppflfm_ml import set_seed, BehaviorAuthNet, train_model, predict_proba
import ppflfm_swipe as SW

DEVICE_CODE = {"Phone": 1, "Tablet": 2}


def build_cache(root):
    cache = {}
    for uid in user_folders(root):
        for dev in SW.SWIPE_DEVICES:
            p = SW.resolve_touch_path(root / str(uid), dev)
            if p is None:
                continue
            strokes = SW.reconstruct_strokes(p, SW.SWIPE["min_points"], SW.SWIPE["max_v"])
            if strokes:
                cache[(uid, dev)] = (p.name, strokes)
    return cache


def eligible(strokes):
    s = SW.SWIPE
    if len(strokes) < s["min_strokes"]:
        return False
    dur = (strokes[-1].t_start - strokes[0].t_start).total_seconds()
    return dur >= s["min_duration_s"]


def temporal_segments(cache):
    s = SW.SWIPE
    segs = []
    for (uid, dev), (fname, st) in cache.items():
        if not eligible(st):
            continue
        sp = make_stream_split(uid, dev, len(st), s["train_frac"], s["val_frac"], s["test_frac"],
                               s["guard_events"], s["min_strokes"], s["min_partition"])
        if not sp.usable:
            continue
        for part, (a, b) in (("train", sp.train), ("val", sp.val), ("test", sp.test)):
            segs.append(dict(user=uid, device=dev, file=fname, partition=part, e0=a, e1=b))
    return segs


def lodo_folds(cache):
    s = SW.SWIPE
    folds = {}
    for held in SW.SWIPE_DEVICES:
        segs = []
        for (uid, dev), (fname, st) in cache.items():
            if not eligible(st):
                continue
            n = len(st)
            if dev == held:
                segs.append(dict(user=uid, device=dev, file=fname, partition="test", e0=0, e1=n))
            else:
                n_tr = int(0.85 * n); g = s["guard_events"]
                if n_tr < s["min_partition"] or (n - n_tr - g) < s["min_partition"]:
                    continue
                segs.append(dict(user=uid, device=dev, file=fname, partition="train", e0=0, e1=n_tr))
                segs.append(dict(user=uid, device=dev, file=fname, partition="val", e0=n_tr + g, e1=n))
        folds[held] = segs
    return folds


def window(segs, cache):
    """One stroke = one sample (window=1). Returns X,y,dev,parts,meta,hashes."""
    X, y, dev, parts, meta, hashes = [], [], [], [], [], []
    wid = 0
    for sg in segs:
        key = (sg["user"], sg["device"])
        if key not in cache:
            continue
        fname, st = cache[key]
        for i in range(sg["e0"], sg["e1"]):
            fv = st[i].feat
            X.append(fv); y.append(sg["user"]); dev.append(DEVICE_CODE[sg["device"]])
            parts.append(sg["partition"]); hashes.append(hash(tuple(round(v, 6) for v in fv)))
            meta.append(dict(window_id=wid, user=sg["user"], device=sg["device"], file=fname,
                             partition=sg["partition"], event_start=i, event_end=i + 1,
                             t_start=st[i].t_start.isoformat(), t_end=st[i].t_end.isoformat()))
            wid += 1
    return (np.asarray(X, float), np.asarray(y, np.int64), np.asarray(dev, np.int64),
            parts, meta, hashes)


def scale_split(X, parts):
    parts = np.asarray(parts); tr = parts == "train"
    mean = X[tr].mean(0); scale = X[tr].std(0)
    scale = np.where(scale < FEATURES["std_eps"], FEATURES["std_eps"], scale)
    Xs = (X - mean) / scale
    return Xs, mean, scale, tr


def to_dict(Xs, y, dev, parts):
    parts = np.asarray(parts)
    labels = np.unique(y)
    enc = {c: i for i, c in enumerate(labels)}
    ye = np.array([enc[c] for c in y], np.int64)
    g = lambda nm: (Xs[parts == nm].astype(np.float32), ye[parts == nm], dev[parts == nm])  # noqa
    tr, va, te = g("train"), g("val"), g("test")
    return dict(X_train=tr[0], y_train=tr[1], device_train=tr[2],
                X_val=va[0], y_val=va[1], device_val=va[2],
                X_test=te[0], y_test=te[1], device_test=te[2],
                n_classes=len(labels), in_dim=Xs.shape[1]), labels


def dedup_cross_partition(X, y, dev, parts, meta, hashes):
    """Drop val/test rows whose EXACT feature vector already appears in an earlier
    partition (train, then val). Swipe per-stroke features are low-dimensional, so
    distinct time-disjoint strokes can coincide; this removes any memorization path.
    Returns filtered arrays + n_dropped."""
    # partition-priority sets (order-independent): train wins over val wins over test
    train_h = {h for h, p in zip(hashes, parts) if p == "train"}
    val_h = {h for h, p in zip(hashes, parts) if p == "val" and h not in train_h}
    keep = []
    for h, p in zip(hashes, parts):
        if p == "train":
            keep.append(True)
        elif p == "val":
            keep.append(h not in train_h)
        else:  # test
            keep.append(h not in train_h and h not in val_h)
    keep = np.asarray(keep)
    n_drop = int((~keep).sum())
    fp = [p for p, k in zip(parts, keep) if k]
    fm = [m for m, k in zip(meta, keep) if k]
    fh = [hh for hh, k in zip(hashes, keep) if k]
    return X[keep], y[keep], dev[keep], fp, fm, fh, n_drop


def process(segs, cache, tag, protocol, processed, out):
    X, y, dev, parts, meta, hashes = window(segs, cache)
    if len(y) == 0:
        return None
    X, y, dev, parts, meta, hashes, n_drop = dedup_cross_partition(X, y, dev, parts, meta, hashes)
    audit = leakage_audit(segs, parts, hashes, protocol, meta=meta)
    audit["n_dedup_dropped"] = n_drop
    Xs, mean, scale, tr = scale_split(X, parts)
    audit["checks"]["scaler_fit_on_train_only"] = True
    audit["checks"]["no_nan_inf"] = bool(np.isfinite(Xs).all())
    audit["pass"] = all(audit["checks"].values())
    d, labels = to_dict(Xs, y, dev, parts)
    np.savez_compressed(processed / f"swipe_windows{tag}.npz",
                        X_train=d["X_train"], y_train=d["y_train"], device_train=d["device_train"],
                        X_val=d["X_val"], y_val=d["y_val"], device_val=d["device_val"],
                        X_test=d["X_test"], y_test=d["y_test"], device_test=d["device_test"],
                        feature_names=np.asarray(SW.SWIPE_FEATURE_NAMES),
                        scaler_mean=mean, scaler_scale=scale)
    (out / f"swipe_audit{tag}.json").write_text(__import__("json").dumps(audit, indent=2), "utf-8")
    return d, audit


def main():
    require_gate("stage04")
    root = resolve_root()
    _, processed, _ = get_feature_dirs()
    out = stage_dir("16_swipe")
    print("[stage18] reconstructing swipe strokes from raw TouchEvent ...")
    cache = build_cache(root)
    n_elig = sum(1 for _, (f, st) in cache.items() if eligible(st))
    print(f"[stage18] swipe streams={len(cache)} eligible={n_elig} "
          f"(users={len({u for (u, dv) in cache})})")

    tsegs = temporal_segments(cache)
    dt = process(tsegs, cache, "", "temporal", processed, out)
    report = ["=" * 70, "STAGE 18 - SWIPE MODALITY (leakage-safe, per-stroke)", "=" * 70,
              f"swipe streams={len(cache)} eligible={n_elig}",
              f"features={SW.N_SWIPE_FEATURES}: {', '.join(SW.SWIPE_FEATURE_NAMES)}", ""]
    if dt is None:
        report.append("no eligible swipe data")
        (out / "stage18_report.txt").write_text("\n".join(report), "utf-8")
        print("no eligible swipe data"); return
    d, audit = dt
    report.append(f"temporal windows train/val/test="
                  f"{len(d['y_train'])}/{len(d['y_val'])}/{len(d['y_test'])} "
                  f"users={d['n_classes']}  audit={'PASS' if audit['pass'] else 'FAIL'}")
    for k, v in audit["checks"].items():
        report.append(f"    [{'ok' if v else 'XX'}] {k}")

    # LODO (Phone/Tablet)
    folds = lodo_folds(cache)
    for held, segs in folds.items():
        r = process(segs, cache, f"_lodo_{held}", "lodo", processed, out)
        if r:
            report.append(f"  LODO held-out={held}: test windows={len(r[0]['y_test'])} "
                          f"audit={'PASS' if r[1]['pass'] else 'FAIL'}")

    # quick centralized eval on temporal swipe
    set_seed(SEED)
    from ppflfm_common import MODEL
    model = BehaviorAuthNet(d["in_dim"], d["n_classes"], MODEL["hidden1"], MODEL["hidden2"],
                            MODEL["dropout"], norm=MODEL["norm"])
    train_model(model, d, TRAIN)
    proba = predict_proba(model, d["X_test"])
    cls = classification_metrics(d["y_test"], proba.argmax(1), n_classes=d["n_classes"])
    ver = verification_metrics(proba, d["y_test"], labels=np.arange(d["n_classes"]))
    Ps, Ys = whole_session_aggregate(proba, d["y_test"], np.asarray(d["device_test"]))
    verS = verification_metrics(Ps, Ys, labels=np.arange(d["n_classes"])) if len(Ys) else {"eer": float("nan"), "auc": float("nan")}
    report += ["", f"CENTRALIZED swipe: acc={cls['accuracy']:.4f} macroF1={cls['macro_f1']:.4f} "
                   f"EER={ver['eer']:.4f} AUC={ver['auc']:.4f} | session EER={verS['eer']:.4f}",
               f"chance=1/{d['n_classes']}={1.0/d['n_classes']:.4f}"]
    with open(out / "swipe_eval.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["metric", "value"])
        for k, v in (("accuracy", cls["accuracy"]), ("macro_f1", cls["macro_f1"]),
                     ("eer", ver["eer"]), ("auc", ver["auc"]), ("session_eer", verS["eer"])):
            w.writerow([k, v])
    append_results([dict(stage="18_swipe", method="BehaviorAuthNet", setting="centralized",
                         seed=SEED, task="A+B", accuracy=cls["accuracy"], macro_f1=cls["macro_f1"],
                         eer=ver["eer"], auc=ver["auc"], macro_eer=ver["macro_eer"])])
    report.append("=" * 70)
    txt = "\n".join(report)
    print("\n" + txt)
    (out / "stage18_report.txt").write_text(txt, "utf-8")
    print(f"[stage18] wrote {out}")


if __name__ == "__main__":
    main()
