"""
ppflfm_swipe.py — swipe reconstruction from RAW TouchEvent streams (Stage 18).

Why raw (not the shipped Swipe_Features/*.csv)? Same reason as keystroke: the shipped
per-swipe feature files carry NO wall-clock timestamps, so they cannot support a
chronological, guard-gapped, leakage-safe split. The raw
<uid>_Hand{Phone,Tablet}_TouchEvent_*.csv streams DO have timestamps + an actionType
flag, from which swipe strokes and their dynamics are reconstructable.

Raw schema: EID,Xvalue,Yvalue,pressure,touchMajor,touchMinor,pointerID,
            fingerOrientation,actionType,time
  actionType 0=DOWN, 2=MOVE, 1=UP ; rows with empty actionType have time="null" (skipped
  for timing). A stroke = DOWN -> (MOVEs) -> UP. Swipe is Phone/Tablet only (no Desktop).

One STROKE = one behavioral sample (per-swipe features), analogous to a keystroke window.
Strokes are split chronologically by index with a guard gap; the generic leakage auditor
(ppflfm_common.leakage_audit) then proves partition disjointness.
"""
from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from pathlib import Path

from ppflfm_common import parse_ts  # reuse the robust timestamp parser

DEVICE_TOUCH_GLOB = {
    "Phone": "*_HandPhone_TouchEvent_*.csv",
    "Tablet": "*_HandTablet_TouchEvent_*.csv",
}
SWIPE_DEVICES = ["Phone", "Tablet"]

# Stage 18 config
SWIPE = dict(
    min_points=3,           # a stroke needs >= this many timestamped points
    min_strokes=30,         # eligibility: user x device needs >= this many strokes
    min_duration_s=60.0,    # eligibility: total stroke-span duration
    train_frac=0.70, val_frac=0.15, test_frac=0.15,
    guard_events=5,         # strokes dropped at each partition boundary
    min_partition=8,        # min strokes per partition
    max_v=50.0,             # clip per-segment speed (px/ms) outliers
)

SWIPE_FEATURE_NAMES = [
    "duration_ms", "path_length", "net_disp", "straightness",
    "v_mean", "v_std", "v_max", "dx", "dy", "direction",
    "pressure_mean", "touchmajor_mean", "bbox_area", "n_points",
]
N_SWIPE_FEATURES = len(SWIPE_FEATURE_NAMES)


@dataclass
class Stroke:
    t_start: object
    t_end: object
    feat: list


def resolve_touch_path(user_dir: Path, device: str):
    pat = DEVICE_TOUCH_GLOB.get(device)
    if not pat:
        return None
    m = sorted(user_dir.glob(pat))
    return m[0] if m else None


def _load_touch_events(path: Path):
    """Return list of (actionType:int, x, y, pressure, touchMajor, ts) with valid time."""
    ev = []
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as fh:
        r = csv.reader(fh)
        try:
            next(r)
        except StopIteration:
            return ev
        for row in r:
            if len(row) != 10:
                continue
            at = row[8].strip()
            if at not in ("0.0", "1.0", "2.0"):
                continue
            ts = parse_ts(row[9])      # time is column index 9
            if ts is None:
                continue
            try:
                x = float(row[1]); y = float(row[2]); pr = float(row[3]); tm = float(row[4])
            except ValueError:
                continue
            ev.append((int(float(at)), x, y, pr, tm, ts))
    return ev


def _stroke_features(pts, max_v):
    """pts: list of (x,y,pressure,touchMajor,ts) sorted by time. Returns feature list."""
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    prs = [p[2] for p in pts]; tms = [p[3] for p in pts]
    ts = [p[4] for p in pts]
    dur_ms = (ts[-1] - ts[0]).total_seconds() * 1000.0
    seg_len, speeds = [], []
    for i in range(len(pts) - 1):
        d = math.hypot(xs[i + 1] - xs[i], ys[i + 1] - ys[i])
        seg_len.append(d)
        dt = (ts[i + 1] - ts[i]).total_seconds() * 1000.0
        if dt > 0:
            speeds.append(min(d / dt, max_v))
    path_length = sum(seg_len)
    net_disp = math.hypot(xs[-1] - xs[0], ys[-1] - ys[0])
    straightness = net_disp / path_length if path_length > 0 else 0.0
    v_mean = (sum(speeds) / len(speeds)) if speeds else 0.0
    v_std = (sum((s - v_mean) ** 2 for s in speeds) / len(speeds)) ** 0.5 if speeds else 0.0
    v_max = max(speeds) if speeds else 0.0
    dx = xs[-1] - xs[0]; dy = ys[-1] - ys[0]
    direction = math.atan2(dy, dx)
    pressure_mean = sum(prs) / len(prs)
    touchmajor_mean = sum(tms) / len(tms)
    bbox_area = (max(xs) - min(xs)) * (max(ys) - min(ys))
    return [dur_ms, path_length, net_disp, straightness, v_mean, v_std, v_max,
            dx, dy, direction, pressure_mean, touchmajor_mean, bbox_area, float(len(pts))]


def reconstruct_strokes(path: Path, min_points=3, max_v=50.0):
    """Group raw touch events into strokes (DOWN..UP) and compute per-stroke features."""
    ev = _load_touch_events(path)
    strokes = []
    cur = []

    def close():
        if len(cur) >= min_points:
            dur = (cur[-1][5] - cur[0][5]).total_seconds()   # index 5 = timestamp
            if dur > 0:
                pts = [(x, y, pr, tm, ts) for (_, x, y, pr, tm, ts) in cur]
                strokes.append(Stroke(cur[0][5], cur[-1][5], _stroke_features(pts, max_v)))

    for e in ev:
        at = e[0]
        if at == 0:              # DOWN -> start new stroke (close any dangling one)
            if cur:
                close()
            cur = [e]
        elif at == 2:            # MOVE
            if cur:
                cur.append(e)
        elif at == 1:            # UP -> close
            if cur:
                cur.append(e); close(); cur = []
    if cur:
        close()
    strokes.sort(key=lambda s: s.t_start)
    return strokes
