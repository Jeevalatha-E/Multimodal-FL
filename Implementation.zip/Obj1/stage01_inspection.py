"""
STAGE 01 — Dataset inspection  (Colab)

Computes the BB-MAS ground-truth inventory directly from disk (roadmap PHASE 3).
Requires ppflfm_common.py in the same folder.

Colab:   !python stage01_inspection.py
Outputs: PPFLFM_Rebuild_out/results/01_data_validation/{dataset_inventory.csv,
         dataset_summary.json, stage01_report.txt}
"""
from __future__ import annotations

import csv
import json
from datetime import datetime

from ppflfm_common import (
    resolve_root, get_out_dirs, user_folders, iter_all_files,
    read_header, count_lines, INSPECT_MAX_MB,
)


def main():
    root = resolve_root()
    _, out_dir, _ = get_out_dirs()
    print(f"[stage01] root={root}")

    uids = user_folders(root)
    recs = list(iter_all_files(root))
    print(f"[stage01] users={len(uids)} files={len(recs)} (counting rows <= {INSPECT_MAX_MB} MB)")

    max_bytes = INSPECT_MAX_MB * 1024 * 1024
    for i, r in enumerate(recs, 1):
        if not r.empty:
            r.columns = read_header(r.path)
            r.rows = count_lines(r.path) - 1 if r.size_bytes <= max_bytes else -1
        else:
            r.rows = 0
        if i % 500 == 0 or i == len(recs):
            print(f"  ...{i}/{len(recs)}", end="\r")
    print()

    with open(out_dir / "dataset_inventory.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["scope", "user", "device", "modality", "file",
                    "size_bytes", "empty", "rows", "n_columns", "columns"])
        for r in recs:
            w.writerow([r.scope, r.user, r.device, r.modality, r.path.name,
                        r.size_bytes, int(r.empty), r.rows, len(r.columns), "|".join(r.columns)])

    summary = {"generated": datetime.now().isoformat(timespec="seconds"),
               "root": str(root), "n_users": len(uids), "n_files": len(recs), "by_scope": {}}
    L = ["=" * 70, "STAGE 01 - BB-MAS GROUND-TRUTH INVENTORY", "=" * 70,
         f"root   : {root}", f"users  : {len(uids)} (ids {min(uids)}..{max(uids)})",
         f"files  : {len(recs)}", "", "By scope (rows shown only for counted files):"]
    for scope in ("raw", "keystroke", "swipe", "gait"):
        s = [r for r in recs if r.scope == scope]
        emp = sum(1 for r in s if r.empty)
        rows = sum(r.rows for r in s if r.rows > 0)
        users = len({r.user for r in s if r.user is not None})
        summary["by_scope"][scope] = dict(files=len(s), empty=emp, nonempty=len(s) - emp,
                                           users=users, counted_rows=rows)
        L.append(f"  {scope:10s} files={len(s):5d} empty={emp:5d} nonempty={len(s)-emp:5d} "
                 f"users={users:3d} rows={rows:,}")
    gait = [r for r in recs if r.scope == "gait"]
    summary["gait_all_empty"] = all(r.empty for r in gait) if gait else None
    L += ["", f"gait files all empty: {summary['gait_all_empty']} "
              f"({sum(1 for r in gait if r.empty)}/{len(gait)})", "=" * 70]

    (out_dir / "dataset_summary.json").write_text(json.dumps(summary, indent=2), "utf-8")
    report = "\n".join(L)
    print(report)
    (out_dir / "stage01_report.txt").write_text(report, "utf-8")
    print(f"\n[stage01] wrote outputs to {out_dir}")


if __name__ == "__main__":
    main()
