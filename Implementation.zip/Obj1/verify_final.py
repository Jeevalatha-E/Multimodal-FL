"""
verify_final.py — end-to-end consistency audit of a completed run (Phase D freeze gate).

Checks the exact blockers reviewers keep raising and prints a PASS/FAIL checklist:
  1. no PILOT / DEV_SUBSET marker anywhere in the reports
  2. Stage 04 used the full population (users == 117 keystroke; not a subset)
  3. gates stage02/03/04 all PASS
  4. reproducibility manifest: norm=layer, dataset_hash + code_hash present
  5. K/S/M coverage present (fusion population defined)
  6. DP epsilon is MONOTONIC in sigma, in Stage 12 and Stage 21
  7. DP single-source proof: the stored epsilon in Stage 12 and Stage 21 EXACTLY equals
     dp_epsilon() recomputed from each stage's own (q, steps) -> same accountant
  8. multimodal results contain BOTH early and late fusion
  9. opacus present (independent DP reference available)

Run:  python verify_final.py
Exit code 0 iff every hard check passes.
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
from ppflfm_common import OUT_BASE, DP  # noqa: E402
from ppflfm_ml import dp_epsilon        # noqa: E402

RES = Path(OUT_BASE) / "results"
checks = []


def add(name, ok, detail=""):
    checks.append((name, bool(ok), detail))


def read_csv(p):
    p = Path(p)
    if not p.exists():
        return None
    with open(p, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def main():
    # 1) no PILOT marker in any stage report
    pilot_hits = []
    for rep in RES.rglob("*report*.txt"):
        try:
            if "PILOT" in rep.read_text("utf-8", errors="replace"):
                pilot_hits.append(rep.name)
        except OSError:
            pass
    add("no_pilot_markers", not pilot_hits, f"found in {pilot_hits}" if pilot_hits else "")

    # 2) full population at Stage 04 (experiment_manifest)
    man = RES / "experiment_manifest.json"
    n_users = None
    if man.exists():
        m = json.loads(man.read_text("utf-8"))
        prot = m.get("protocols", {})
        n_users = (prot.get("temporal") or prot.get("(temporal)") or {}).get("n_users")
    add("stage04_full_population(users>=100)", (n_users or 0) >= 100, f"users={n_users}")

    # 3) gates
    gates = {}
    gp = RES / "gates.json"
    if gp.exists():
        gates = json.loads(gp.read_text("utf-8"))
    add("gates_02_03_04_pass",
        all(gates.get(s, {}).get("pass") for s in ("stage02", "stage03", "stage04")),
        str({k: v.get("pass") for k, v in gates.items()}))

    # 4) reproducibility manifest
    rep = RES / "reproducibility.json"
    if rep.exists():
        r = json.loads(rep.read_text("utf-8"))
        add("frozen_layernorm", r.get("frozen_norm") == "layer", f"norm={r.get('frozen_norm')}")
        add("dataset_and_code_hash", bool(r.get("dataset_hash")) and bool(r.get("code_hash")),
            f"dataset={r.get('dataset_hash')} code={r.get('code_hash')}")
        add("opacus_present", _opacus(), "install with !pip install opacus" if not _opacus() else "")
    else:
        add("frozen_layernorm", False, "reproducibility.json missing")
        add("dataset_and_code_hash", False, "reproducibility.json missing")
        add("opacus_present", _opacus(), "")

    # 5) coverage
    cov = read_csv(RES / "18_fusion" / "coverage.csv")
    add("coverage_report_present", cov is not None,
        f"{len(cov)} rows" if cov else "coverage.csv missing")

    # 6/7) DP monotonicity + single-source recompute, Stage 12 and Stage 21
    _dp_checks("12_dp", "dp_sweep.csv", "epsilon", None)
    _dp_checks("19_mm_ppflfm", "mm_dp.csv", "epsilon", "fusion")

    # 8) both fusion strategies in multimodal
    mm = read_csv(RES / "19_mm_ppflfm" / "mm_fl.csv")
    fusions = {r.get("fusion") for r in mm} if mm else set()
    add("multimodal_early_and_late", {"early", "late"} <= fusions, f"fusions={fusions or 'none'}")

    # ---- print ----
    print("=" * 70 + "\nFINAL CONSISTENCY AUDIT\n" + "=" * 70)
    hard_ok = True
    for name, ok, detail in checks:
        soft = name == "opacus_present"
        mark = "PASS" if ok else ("WARN" if soft else "FAIL")
        if not ok and not soft:
            hard_ok = False
        print(f"  [{mark}] {name}" + (f"  ({detail})" if detail else ""))
    print("=" * 70)
    print("RESULT: " + ("ALL HARD CHECKS PASS — ready for consistency freeze."
                        if hard_ok else "FAILED — not paper-ready; see FAIL lines above."))
    sys.exit(0 if hard_ok else 1)


def _opacus():
    try:
        import opacus  # noqa: F401
        return True
    except Exception:
        return False


def _dp_checks(subdir, fname, eps_col, group_col):
    rows = read_csv(RES / subdir / fname)
    if not rows:
        add(f"{subdir}:dp_present", False, f"{fname} missing")
        return
    # group rows (Stage 21 has early/late); check monotonic + recompute within each group
    groups = {}
    for r in rows:
        g = r.get(group_col) if group_col else "all"
        groups.setdefault(g, []).append(r)
    mono_ok, recompute_ok = True, True
    detail = []
    for g, rs in groups.items():
        rs = [r for r in rs if r[eps_col] not in ("inf", "")]
        rs.sort(key=lambda r: float(r["sigma"]))
        eps = [float(r[eps_col]) for r in rs]
        if any(eps[i] < eps[i + 1] - 1e-6 for i in range(len(eps) - 1)):
            mono_ok = False; detail.append(f"{g}:non-monotonic {eps}")
        # single-source recompute from each row's own q/steps
        for r in rs:
            if "q" in r and "steps" in r and r["q"] and r["steps"]:
                recomputed = dp_epsilon(float(r["q"]), float(r["sigma"]), int(float(r["steps"])), DP["delta"])
                if abs(recomputed - float(r[eps_col])) > max(0.01, 0.01 * recomputed):
                    recompute_ok = False
                    detail.append(f"{g} s={r['sigma']}: stored {r[eps_col]} != recompute {recomputed:.3f}")
    add(f"{subdir}:eps_monotonic", mono_ok, "; ".join(detail[:2]))
    add(f"{subdir}:eps_single_source_recompute", recompute_ok, "; ".join(detail[:2]))


if __name__ == "__main__":
    main()
