"""
ppflfm_fusion.py — cross-modal time-aligned feature table (Stages 20/21).

The three modalities have different natural units (keystroke = 50-keypress window,
swipe = per-stroke, motion = 2 s window), so they cannot be concatenated directly. This
builds ONE aligned table: for each user x device (Phone/Tablet, where all three sensors
co-occur in the same session), it reconstructs keystroke/swipe/motion from raw streams,
lays a COMMON time grid (default 30 s bins — large enough that sparse swipes co-occur
with keystroke+motion), and computes a per-modality feature block per bin.

Each record: user (ORIGINAL id), device, bin index, t_start, and blocks K/S/M (each a
feature list or None if that modality has insufficient data in the bin). Downstream:
  - EARLY fusion  = concatenate present blocks for a modality combo (one model)
  - LATE fusion   = per-modality models on the same bins, scores combined
  - ABLATION      = choose which blocks to include
Desktop is keystroke-only (no swipe/motion sensors) and is excluded from fusion.
"""
from __future__ import annotations

from datetime import timedelta

from ppflfm_common import (resolve_keyboard_path, reconstruct, window_feature_vector,
                           FEATURES, FEATURE_NAMES, user_folders)
import ppflfm_swipe as SW
import ppflfm_motion as MO

FUSION_DEVICES = ["Phone", "Tablet"]
FUSION = dict(
    bin_s=30.0,            # common time-bin length (s) — big enough for swipe co-occurrence
    min_kp=5,              # keystrokes needed in a bin for a K block
    min_strokes=1,         # strokes needed for an S block
    min_motion=100,        # accel & gyro samples needed for an M block
    min_bins=6,            # eligibility: user x device needs >= this many bins (per combo)
    train_frac=0.70, val_frac=0.15, test_frac=0.15,
    guard_events=2, min_partition=2,
)
BLOCK_NAMES = {"K": FEATURE_NAMES, "S": SW.SWIPE_FEATURE_NAMES, "M": MO.MOTION_FEATURE_NAMES}
BLOCK_DIM = {"K": len(FEATURE_NAMES), "S": len(SW.SWIPE_FEATURE_NAMES), "M": len(MO.MOTION_FEATURE_NAMES)}


def _mean_cols(list_of_vecs):
    n = len(list_of_vecs)
    d = len(list_of_vecs[0])
    return [sum(v[i] for v in list_of_vecs) / n for i in range(d)]


def build_user_device_bins(root, uid, dev, cfg=FUSION):
    """Return list of per-bin records for one user x device (or [] if no data)."""
    udir = root / str(uid)
    kb = resolve_keyboard_path(udir, dev)
    kps = reconstruct(kb).keypresses if kb else []
    strokes = []
    tp = SW.resolve_touch_path(udir, dev)
    if tp:
        strokes = SW.reconstruct_strokes(tp, SW.SWIPE["min_points"], SW.SWIPE["max_v"])
    ap, gp = MO.resolve_inertial_paths(udir, dev)

    starts = []
    if kps:
        starts.append(kps[0].t_down)
    if strokes:
        starts.append(strokes[0].t_start)
    a_first = next(MO._stream_xyzt(ap), None) if ap else None
    g_first = next(MO._stream_xyzt(gp), None) if gp else None
    if a_first:
        starts.append(a_first[3])
    if g_first:
        starts.append(g_first[3])
    if not starts:
        return []
    t0 = min(starts)
    bs = cfg["bin_s"]

    def binof(ts):
        return int((ts - t0).total_seconds() // bs)

    # keystroke blocks
    kb_bins = {}
    for kp in kps:
        kb_bins.setdefault(binof(kp.t_down), []).append(kp)
    K = {b: window_feature_vector(v, FEATURES["max_flight_ms"])
         for b, v in kb_bins.items() if len(v) >= cfg["min_kp"]}
    # swipe blocks (mean of per-stroke features in the bin)
    sw_bins = {}
    for s in strokes:
        sw_bins.setdefault(binof(s.t_start), []).append(s.feat)
    S = {b: _mean_cols(v) for b, v in sw_bins.items() if len(v) >= cfg["min_strokes"]}
    # motion blocks (accel+gyro samples in the bin)
    M = {}
    if ap and gp:
        ab = MO._bucketize(ap, t0, bs)
        gb = MO._bucketize(gp, t0, bs)
        for b in set(ab) & set(gb):
            if len(ab[b]) >= cfg["min_motion"] and len(gb[b]) >= cfg["min_motion"]:
                M[b] = MO._window_features(ab[b], gb[b])

    all_bins = sorted(set(K) | set(S) | set(M))
    recs = []
    for b in all_bins:
        recs.append(dict(user=uid, device=dev, bin=b,
                         t_start=(t0 + timedelta(seconds=b * bs)),
                         K=K.get(b), S=S.get(b), M=M.get(b)))
    return recs


def build_fusion_table(root, dev_subset=None, cfg=FUSION):
    """Build aligned bin records for all eligible user x device (Phone/Tablet)."""
    uids = user_folders(root)
    if dev_subset is not None:
        keep = set(uids[:dev_subset]) if isinstance(dev_subset, int) else set(dev_subset)
        uids = [u for u in uids if u in keep]
    table = []
    for uid in uids:
        for dev in FUSION_DEVICES:
            recs = build_user_device_bins(root, uid, dev, cfg)
            table.extend(recs)
        print(f"  fusion user {uid} binned", end="\r")
    print()
    return table
