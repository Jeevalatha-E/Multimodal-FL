"""
STAGE 19 — Motion modality: leakage-safe accel+gyro window features + quick eval
(multimodal step 2). Heaviest stage: streams the ~25 MB inertial files.

Reconstructs 2 s inertial windows from raw Hand{Phone,Tablet} accel+gyro, builds a
leakage-safe per-window dataset (temporal within-device + cross-device LODO), runs the
SAME auditor, train-only scaler, saves npz, and reports a quick centralized eval.

Colab: !python stage19_motion_features.py   (needs numpy, torch; run stages 01-04 first)
   TIP: set DEV_SUBSET in ppflfm_common.py (e.g. 15) to debug fast before the full run.
Outputs -> data/processed/motion_windows.npz (+ _lodo_{Phone,Tablet}.npz),
           results/17_motion/{stage19_report.txt, motion_audit*.json, motion_eval.csv}
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

from ppflfm_common import (resolve_root, get_feature_dirs, stage_dir, append_results,
                           require_gate, make_stream_split, leakage_audit, user_folders,
                           TRAIN, SEED, MODEL, DEV_SUBSET)
from ppflfm_eval import classification_metrics, verification_metrics, whole_session_aggregate
from ppflfm_ml import set_seed, BehaviorAuthNet, train_model, predict_proba
from stage18_swipe_features import dedup_cross_partition, scale_split, to_dict, DEVICE_CODE
import ppflfm_motion as MO


def _subset_uids(all_uids):
    if DEV_SUBSET is None:
        return set(all_uids)
    if isinstance(DEV_SUBSET, int):
        return set(all_uids[:DEV_SUBSET])
    return set(DEV_SUBSET)


def build_cache(root):
    cache = {}
    keep = _subset_uids(user_folders(root))
    for uid in sorted(keep):
        for dev in MO.MOTION_DEVICES:
            ap, gp = MO.resolve_inertial_paths(root / str(uid), dev)
            w = MO.reconstruct_motion_windows(ap, gp, MO.MOTION["window_s"], MO.MOTION["min_samples"])
            if w:
                cache[(uid, dev)] = (ap.name if ap else f"{uid}_{dev}", w)
        print(f"  motion user {uid} cached", end="\r")
    print()
    return cache


def eligible(win):
    m = MO.MOTION
    if len(win) < m["min_windows"]:
        return False
    dur = (win[-1].t_start - win[0].t_start).total_seconds()
    return dur >= m["min_duration_s"]


def segments_temporal(cache):
    m = MO.MOTION; segs = []
    for (uid, dev), (fname, win) in cache.items():
        if not eligible(win):
            continue
        sp = make_stream_split(uid, dev, len(win), m["train_frac"], m["val_frac"], m["test_frac"],
                               m["guard_events"], m["min_windows"], m["min_partition"])
        if not sp.usable:
            continue
        for part, (a, b) in (("train", sp.train), ("val", sp.val), ("test", sp.test)):
            segs.append(dict(user=uid, device=dev, file=fname, partition=part, e0=a, e1=b))
    return segs


def lodo_folds(cache):
    m = MO.MOTION; folds = {}
    for held in MO.MOTION_DEVICES:
        segs = []
        for (uid, dev), (fname, win) in cache.items():
            if not eligible(win):
                continue
            n = len(win)
            if dev == held:
                segs.append(dict(user=uid, device=dev, file=fname, partition="test", e0=0, e1=n))
            else:
                n_tr = int(0.85 * n); g = m["guard_events"]
                if n_tr < m["min_partition"] or (n - n_tr - g) < m["min_partition"]:
                    continue
                segs.append(dict(user=uid, device=dev, file=fname, partition="train", e0=0, e1=n_tr))
                segs.append(dict(user=uid, device=dev, file=fname, partition="val", e0=n_tr + g, e1=n))
        folds[held] = segs
    return folds


def window(segs, cache):
    X, y, dev, parts, meta, hashes = [], [], [], [], [], []
    wid = 0
    for sg in segs:
        key = (sg["user"], sg["device"])
        if key not in cache:
            continue
        fname, win = cache[key]
        for i in range(sg["e0"], sg["e1"]):
            fv = win[i].feat
            X.append(fv); y.append(sg["user"]); dev.append(DEVICE_CODE[sg["device"]])
            parts.append(sg["partition"]); hashes.append(hash(tuple(round(v, 6) for v in fv)))
            meta.append(dict(window_id=wid, user=sg["user"], device=sg["device"], file=fname,
                             partition=sg["partition"], event_start=i, event_end=i + 1,
                             t_start=win[i].t_start.isoformat(), t_end=win[i].t_end.isoformat()))
            wid += 1
    return (np.asarray(X, float), np.asarray(y, np.int64), np.asarray(dev, np.int64),
            parts, meta, hashes)


def process(segs, cache, tag, protocol, processed, out):
    X, y, dev, parts, meta, hashes = window(segs, cache)
    if len(y) == 0:
        return None
    X, y, dev, parts, meta, hashes, n_drop = dedup_cross_partition(X, y, dev, parts, meta, hashes)
    audit = leakage_audit(segs, parts, hashes, protocol, meta=meta)
    Xs, mean, scale, tr = scale_split(X, parts)
    audit["checks"]["scaler_fit_on_train_only"] = True
    audit["checks"]["no_nan_inf"] = bool(np.isfinite(Xs).all())
    audit["pass"] = all(audit["checks"].values())
    audit["n_dedup_dropped"] = n_drop
    d, labels = to_dict(Xs, y, dev, parts)
    np.savez_compressed(processed / f"motion_windows{tag}.npz",
                        X_train=d["X_train"], y_train=d["y_train"], device_train=d["device_train"],
                        X_val=d["X_val"], y_val=d["y_val"], device_val=d["device_val"],
                        X_test=d["X_test"], y_test=d["y_test"], device_test=d["device_test"],
                        feature_names=np.asarray(MO.MOTION_FEATURE_NAMES),
                        scaler_mean=mean, scaler_scale=scale)
    (out / f"motion_audit{tag}.json").write_text(json.dumps(audit, indent=2), "utf-8")
    return d, audit


def main():
    require_gate("stage04")
    root = resolve_root()
    _, processed, _ = get_feature_dirs()
    out = stage_dir("17_motion")
    print(f"[stage19] reconstructing motion windows (window={MO.MOTION['window_s']}s) "
          f"DEV_SUBSET={DEV_SUBSET} ... (streams big files; be patient)")
    cache = build_cache(root)
    n_elig = sum(1 for _, (f, w) in cache.items() if eligible(w))
    print(f"[stage19] motion streams={len(cache)} eligible={n_elig} "
          f"users={len({u for (u, dv) in cache})}")

    report = ["=" * 70, "STAGE 19 - MOTION MODALITY (accel+gyro, 2s windows)", "=" * 70,
              f"motion streams={len(cache)} eligible={n_elig}",
              f"features={MO.N_MOTION_FEATURES}", ""]
    tsegs = segments_temporal(cache)
    dt = process(tsegs, cache, "", "temporal", processed, out)
    if dt is None:
        report.append("no eligible motion data")
        (out / "stage19_report.txt").write_text("\n".join(report), "utf-8")
        print("no eligible motion data"); return
    d, audit = dt
    report.append(f"temporal windows train/val/test="
                  f"{len(d['y_train'])}/{len(d['y_val'])}/{len(d['y_test'])} "
                  f"users={d['n_classes']}  audit={'PASS' if audit['pass'] else 'FAIL'}")
    for k, v in audit["checks"].items():
        report.append(f"    [{'ok' if v else 'XX'}] {k}")

    for held, segs in lodo_folds(cache).items():
        r = process(segs, cache, f"_lodo_{held}", "lodo", processed, out)
        if r:
            report.append(f"  LODO held-out={held}: test windows={len(r[0]['y_test'])} "
                          f"audit={'PASS' if r[1]['pass'] else 'FAIL'}")

    set_seed(SEED)
    model = BehaviorAuthNet(d["in_dim"], d["n_classes"], MODEL["hidden1"], MODEL["hidden2"],
                            MODEL["dropout"], norm=MODEL["norm"])
    train_model(model, d, TRAIN)
    proba = predict_proba(model, d["X_test"])
    cls = classification_metrics(d["y_test"], proba.argmax(1), n_classes=d["n_classes"])
    ver = verification_metrics(proba, d["y_test"], labels=np.arange(d["n_classes"]))
    Ps, Ys = whole_session_aggregate(proba, d["y_test"], np.asarray(d["device_test"]))
    verS = verification_metrics(Ps, Ys, labels=np.arange(d["n_classes"])) if len(Ys) else {"eer": float("nan")}
    report += ["", f"CENTRALIZED motion: acc={cls['accuracy']:.4f} macroF1={cls['macro_f1']:.4f} "
                   f"EER={ver['eer']:.4f} AUC={ver['auc']:.4f} | session EER={verS['eer']:.4f}",
               f"chance=1/{d['n_classes']}={1.0/d['n_classes']:.4f}", "=" * 70]
    with open(out / "motion_eval.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["metric", "value"])
        for k, v in (("accuracy", cls["accuracy"]), ("macro_f1", cls["macro_f1"]),
                     ("eer", ver["eer"]), ("auc", ver["auc"]), ("session_eer", verS["eer"])):
            w.writerow([k, v])
    append_results([dict(stage="19_motion", method="BehaviorAuthNet", setting="centralized",
                         seed=SEED, task="A+B", accuracy=cls["accuracy"], macro_f1=cls["macro_f1"],
                         eer=ver["eer"], auc=ver["auc"], macro_eer=ver["macro_eer"])])
    txt = "\n".join(report)
    print("\n" + txt)
    (out / "stage19_report.txt").write_text(txt, "utf-8")
    print(f"[stage19] wrote {out}")


if __name__ == "__main__":
    main()
