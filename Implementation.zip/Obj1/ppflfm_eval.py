"""
ppflfm_eval.py — shared evaluation metrics (no torch).

Task A (identification): accuracy, macro-F1, balanced accuracy, macro precision/recall,
                         confusion matrix.
Task B (verification)  : from a softmax score matrix, FAR/FRR/EER/ROC-AUC/TAR@FAR.

Kept dependency-light (numpy only) so it can run anywhere Colab does.
"""
from __future__ import annotations

import numpy as np


# --------------------------------------------------------------------------- #
# Task A — identification
# --------------------------------------------------------------------------- #
def classification_metrics(y_true, y_pred, n_classes=None) -> dict:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    labels = np.arange(n_classes) if n_classes else np.unique(np.concatenate([y_true, y_pred]))
    idx = {c: i for i, c in enumerate(labels)}
    K = len(labels)
    cm = np.zeros((K, K), dtype=np.int64)
    for t, p in zip(y_true, y_pred):
        cm[idx[t], idx[p]] += 1

    acc = float((y_true == y_pred).mean()) if len(y_true) else 0.0
    # per-class precision/recall/F1
    tp = np.diag(cm).astype(float)
    pred_sum = cm.sum(axis=0).astype(float)
    true_sum = cm.sum(axis=1).astype(float)
    with np.errstate(divide="ignore", invalid="ignore"):
        prec = np.where(pred_sum > 0, tp / pred_sum, 0.0)
        rec = np.where(true_sum > 0, tp / true_sum, 0.0)
        f1 = np.where((prec + rec) > 0, 2 * prec * rec / (prec + rec), 0.0)
    present = true_sum > 0     # classes actually present in y_true
    return {
        "accuracy": acc,
        "macro_precision": float(prec[present].mean()) if present.any() else 0.0,
        "macro_recall": float(rec[present].mean()) if present.any() else 0.0,
        "macro_f1": float(f1[present].mean()) if present.any() else 0.0,
        "balanced_accuracy": float(rec[present].mean()) if present.any() else 0.0,
        "n_classes_present": int(present.sum()),
        "confusion_matrix": cm.tolist(),
    }


# --------------------------------------------------------------------------- #
# Task B — verification (identification-as-verification protocol)
# --------------------------------------------------------------------------- #
def _average_ranks(x: np.ndarray) -> np.ndarray:
    """1-based ranks with ties assigned the mean of their rank span (Mann-Whitney)."""
    x = np.asarray(x, dtype=np.float64)
    order = np.argsort(x, kind="mergesort")
    sx = x[order]
    ranks = np.empty(len(x), dtype=np.float64)
    i, n = 0, len(x)
    while i < n:
        j = i
        while j + 1 < n and sx[j + 1] == sx[i]:
            j += 1
        ranks[order[i:j + 1]] = (i + j) / 2.0 + 1.0     # mean of ranks i..j (1-based)
        i = j + 1
    return ranks


def _roc_eer_auc(genuine: np.ndarray, impostor: np.ndarray):
    """Return (eer, auc, roc) from genuine/impostor score arrays (higher=more genuine)."""
    genuine = np.asarray(genuine, dtype=np.float64)
    impostor = np.asarray(impostor, dtype=np.float64)
    if len(genuine) == 0 or len(impostor) == 0:
        return float("nan"), float("nan"), None

    thr = np.unique(np.concatenate([genuine, impostor]))
    # sweep descending thresholds
    thr = np.sort(thr)[::-1]
    g_sorted = np.sort(genuine)
    i_sorted = np.sort(impostor)
    ng, ni = len(genuine), len(impostor)

    # FAR(thr) = fraction impostor >= thr ; TAR(thr) = fraction genuine >= thr
    far = 1.0 - np.searchsorted(i_sorted, thr, side="left") / ni
    tar = 1.0 - np.searchsorted(g_sorted, thr, side="left") / ng
    frr = 1.0 - tar

    # EER: where |FAR - FRR| minimal
    j = int(np.argmin(np.abs(far - frr)))
    eer = float((far[j] + frr[j]) / 2.0)

    # AUC via rank statistic (Mann-Whitney U) with AVERAGE ranks for ties
    # (ties must share the mean rank, else all-equal scores give AUC 0 not 0.5).
    order = np.concatenate([genuine, impostor])
    ranks = _average_ranks(order)
    r_gen = ranks[:ng].sum()
    auc = float((r_gen - ng * (ng + 1) / 2.0) / (ng * ni))

    def tar_at_far(target):
        ok = np.where(far <= target)[0]
        return float(tar[ok].max()) if len(ok) else 0.0

    return eer, auc, {
        "far": far, "tar": tar, "frr": frr, "thr": thr,
        "tar_at_far_1pct": tar_at_far(0.01),
        "tar_at_far_0.1pct": tar_at_far(0.001),
    }


def verification_metrics(scores: np.ndarray, y_true, labels=None) -> dict:
    """scores: (n_samples, n_classes) softmax probabilities. y_true: (n_samples,).

    Genuine score  = P(sample, its true class).
    Impostor scores= P(sample, every other class).
    Also computes the macro (per-claimed-identity averaged) EER.
    """
    scores = np.asarray(scores, dtype=np.float64)
    y_true = np.asarray(y_true)
    n, K = scores.shape
    labels = np.arange(K) if labels is None else np.asarray(labels)
    lab_idx = {c: i for i, c in enumerate(labels)}
    yi = np.array([lab_idx[c] for c in y_true])

    genuine = scores[np.arange(n), yi]
    mask = np.ones_like(scores, dtype=bool)
    mask[np.arange(n), yi] = False
    impostor = scores[mask]

    eer, auc, roc = _roc_eer_auc(genuine, impostor)

    # per-claimed-identity EER (column c: genuine = true c, impostor = others claiming c)
    per_user_eer = []
    for c in range(K):
        gen_c = scores[yi == c, c]
        imp_c = scores[yi != c, c]
        if len(gen_c) and len(imp_c):
            e, _, _ = _roc_eer_auc(gen_c, imp_c)
            per_user_eer.append(e)
    macro_eer = float(np.mean(per_user_eer)) if per_user_eer else float("nan")

    out = {"eer": eer, "auc": auc, "macro_eer": macro_eer,
           "n_users_scored": len(per_user_eer)}
    if roc:
        out["tar_at_far_1pct"] = roc["tar_at_far_1pct"]
        out["tar_at_far_0.1pct"] = roc["tar_at_far_0.1pct"]
    return out


# --------------------------------------------------------------------------- #
# Temporal aggregation for continuous authentication (shared by stages 13/14)
# --------------------------------------------------------------------------- #
def stream_runs(y, dev):
    """Yield (start, end) index ranges of contiguous (user, device) streams."""
    y = np.asarray(y); dev = np.asarray(dev)
    n = len(y); i = 0
    while i < n:
        j = i + 1
        while j < n and y[j] == y[i] and dev[j] == dev[i]:
            j += 1
        yield i, j
        i = j


def temporal_aggregate(proba, y, dev, W, stride=1):
    """Average proba over W-window chunks inside each stream.

    stride=1 (default) => SLIDING/overlapping decision windows: a stream of length
    L yields max(0, L-W+1) decisions (decisions overlap, so they are correlated).
    stride=W => non-overlapping chunks. Aggregation is over TEST windows only (all
    already leakage-safe), so overlap here introduces no train/test leakage; it only
    raises the decision count. Streams shorter than W contribute 0 decisions, so
    large W is inherently limited by test-stream length.
    """
    proba = np.asarray(proba); y = np.asarray(y)
    P, Y = [], []
    for a, b in stream_runs(y, dev):
        pos = a
        while pos + W <= b:
            P.append(proba[pos:pos + W].mean(axis=0)); Y.append(y[pos]); pos += stride
    return (np.array(P), np.array(Y)) if P else (np.zeros((0, proba.shape[1])), np.array([]))


def whole_session_aggregate(proba, y, dev):
    """One decision per stream: mean of ALL its windows. Robust session-level metric
    (exactly one decision per user x device test stream)."""
    proba = np.asarray(proba); y = np.asarray(y)
    P, Y = [], []
    for a, b in stream_runs(y, dev):
        if b > a:
            P.append(proba[a:b].mean(axis=0)); Y.append(y[a])
    return (np.array(P), np.array(Y)) if P else (np.zeros((0, proba.shape[1])), np.array([]))


def summarize(name: str, cls: dict, ver: dict | None = None) -> str:
    s = (f"{name:22s} acc={cls['accuracy']:.4f} macroF1={cls['macro_f1']:.4f} "
         f"balAcc={cls['balanced_accuracy']:.4f}")
    if ver:
        s += (f" | EER={ver['eer']:.4f} AUC={ver['auc']:.4f} "
              f"macroEER={ver['macro_eer']:.4f} TAR@1%={ver.get('tar_at_far_1pct', 0):.3f}")
    return s
