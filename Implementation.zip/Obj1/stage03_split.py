"""
STAGE 03 — Leakage-safe split, DUAL protocol  (roadmap PHASE 4 + review points #1/#2)

BB-MAS has ONE session per user x device (verified in inspection: single day, largest
intra-stream gap < ~3 min). A "session-disjoint within device" split is therefore
impossible. We build two protocols instead:

  Protocol A (temporal)     : within-stream chronological train/val/test with guard
                              gaps (continuous-authentication evaluation).
  Protocol B (cross-device) : leave-one-device-out — train on 2 devices, test on the
                              held-out device (the only honest "unseen condition";
                              framed as CROSS-DEVICE generalization, not cross-session).

Emits segment manifests (Stage 04 consumes them) and a PASS/FAIL gate.

Colab: !python stage03_split.py
Outputs -> data/splits/{segments_temporal.json, segments_lodo.json},
           results/01_data_validation/{split_summary.csv, stage03_report.txt}
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

from ppflfm_common import (resolve_root, get_out_dirs, build_kps_cache,
                           build_temporal_segments, build_lodo_folds, dataset_hash,
                           make_stream_split, assert_leakage_safe, write_gate, require_gate,
                           eligibility_report, user_folders, DEVICES, SPLIT, ELIGIBILITY, DEV_SUBSET)


def main():
    require_gate("stage02")          # refuse to split if data-quality gate failed
    root = resolve_root()
    devices = DEVICES
    sp = SPLIT
    out_base, out_dir, splits_dir = get_out_dirs()
    print(f"[stage03] reconstructing streams (once) ...")
    cache = build_kps_cache(root, devices)          # honors DEV_SUBSET
    dh = dataset_hash(root, devices)

    # FROZEN eligibility: report 117 discovered -> N eligible (review: define before eval)
    n_discovered_users = len(user_folders(root))
    elig_rows, eligible_keys = eligibility_report(cache, ELIGIBILITY)
    import csv as _csv
    with open(out_dir / "eligibility.csv", "w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=["user", "device", "n_keypresses", "eligible", "reason"])
        w.writeheader(); w.writerows(elig_rows)
    eligible_users = {u for (u, d) in eligible_keys}
    print(f"[stage03] users discovered={n_discovered_users} dev_subset={DEV_SUBSET} "
          f"| streams present={len(cache)} eligible={len(eligible_keys)} "
          f"| eligible users={len(eligible_users)}  dataset_hash={dh}")

    # --- Protocol A: temporal ---
    tsegs = build_temporal_segments(cache, sp)
    # hard invariant re-check per stream
    for (uid, dev), (fname, kps) in cache.items():
        s = make_stream_split(uid, dev, len(kps), sp["train_frac"], sp["val_frac"],
                              sp["test_frac"], sp["guard_events"], sp["min_keypresses"],
                              sp["min_partition_events"])
        assert_leakage_safe(s)
    n_streams_temporal = len({(s["user"], s["device"]) for s in tsegs}) // 1
    temporal = {"protocol": "temporal", "dataset_hash": dh, "config": sp, "segments": tsegs}
    (splits_dir / "segments_temporal.json").write_text(json.dumps(temporal, indent=2), "utf-8")

    # --- Protocol B: cross-device LODO ---
    folds = build_lodo_folds(cache, sp, devices)
    lodo = {"protocol": "lodo", "dataset_hash": dh, "config": {**sp, "train_frac_within_device": 0.85},
            "folds": folds}
    (splits_dir / "segments_lodo.json").write_text(json.dumps(lodo, indent=2), "utf-8")

    # --- summary + gate ---
    def part_counts(segs):
        from collections import Counter
        return dict(Counter(s["partition"] for s in segs))

    rows = []
    tp = part_counts(tsegs)
    rows.append(dict(protocol="temporal", fold="-", **tp,
                     streams=len({(s['user'], s['device']) for s in tsegs})))
    for held, segs in folds.items():
        pc = part_counts(segs)
        rows.append(dict(protocol="lodo", fold=f"test={held}", **pc,
                         streams=len({(s['user'], s['device']) for s in segs})))
    with open(out_dir / "split_summary.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["protocol", "fold", "train", "val", "test", "streams"])
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, 0) for k in ["protocol", "fold", "train", "val", "test", "streams"]})

    ok = len(tsegs) > 0 and all(len(v) > 0 for v in folds.values())
    write_gate("stage03", ok, {"dataset_hash": dh, "n_streams": len(cache),
                               "temporal_segments": len(tsegs),
                               "lodo_folds": {k: len(v) for k, v in folds.items()}})

    L = ["=" * 70, "STAGE 03 - DUAL-PROTOCOL LEAKAGE-SAFE SPLIT", "=" * 70,
         f"dataset_hash : {dh}",
         f"users discovered : {n_discovered_users}  (dev_subset={DEV_SUBSET})",
         f"streams present  : {len(cache)}   ELIGIBLE (frozen rule {ELIGIBILITY}): "
         f"{len(eligible_keys)}   eligible users: {len(eligible_users)}", "",
         "Evaluation concepts (label precisely in the paper):",
         "  E1 temporal within-device      = Protocol A",
         "  E2 cross-device KNOWN-USER     = Protocol B LODO (users seen via other devices)",
         "  E3 unseen-user generalization  = NOT built (needs enrollment; off-objective)", "",
         "Protocol A (temporal within-stream):",
         f"  segments train/val/test = {tp.get('train',0)}/{tp.get('val',0)}/{tp.get('test',0)} "
         f"over {len({(s['user'],s['device']) for s in tsegs})} streams",
         "", "Protocol B (cross-device leave-one-device-out):"]
    for held, segs in folds.items():
        pc = part_counts(segs)
        L.append(f"  held-out={held:8s} train/val segs={pc.get('train',0)}/{pc.get('val',0)} "
                 f"test segs={pc.get('test',0)}")
    L += ["", f"GATE stage03: {'PASS' if ok else 'FAIL'}", "=" * 70]
    report = "\n".join(L)
    print("\n" + report)
    (out_dir / "stage03_report.txt").write_text(report, "utf-8")
    print(f"[stage03] wrote manifests to {splits_dir}")


if __name__ == "__main__":
    main()
