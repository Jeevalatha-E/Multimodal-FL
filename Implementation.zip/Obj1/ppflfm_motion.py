"""
ppflfm_motion.py — motion (accel+gyro) window features from RAW inertial streams (Stage 19).

Uses the hand-held device inertial streams recorded DURING the typing session:
  Phone  -> <uid>_HandPhone_Accelerometer_*.csv + _Gyroscope_*
  Tablet -> <uid>_HandTablet_Accelerometer_*.csv + _Gyroscope_*
(PocketPhone is the gait/walking context — excluded here; no Desktop inertial.)

Each raw file: EID,Xvalue,Yvalue,Zvalue,time  (~103 Hz, ISO timestamps).
One MOTION SAMPLE = a fixed-length TIME window (default 2 s) of inertial signal; features
are standard statistical descriptors over accel/gyro channels + their magnitudes. Windows
are split chronologically by index with a guard gap; the generic leakage auditor proves
partition disjointness. These are the big files, so parsing is streamed in one pass.
"""
from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from pathlib import Path

from ppflfm_common import parse_ts

DEVICE_INERTIAL_GLOB = {
    "Phone": ("*_HandPhone_Accelerometer_*.csv", "*_HandPhone_Gyroscope_*.csv"),
    "Tablet": ("*_HandTablet_Accelerometer_*.csv", "*_HandTablet_Gyroscope_*.csv"),
}
MOTION_DEVICES = ["Phone", "Tablet"]

MOTION = dict(
    window_s=2.0,           # inertial window length (seconds)
    min_samples=50,         # each window needs >= this many accel AND gyro samples
    min_windows=30,         # eligibility: user x device needs >= this many windows
    min_duration_s=60.0,
    train_frac=0.70, val_frac=0.15, test_frac=0.15,
    guard_events=3,         # windows dropped at each partition boundary
    min_partition=8,
)

_CH = ["ax", "ay", "az", "amag", "gx", "gy", "gz", "gmag"]
MOTION_FEATURE_NAMES = [f"{c}_{s}" for c in _CH for s in ("mean", "std", "rms")] + \
                       ["sma_accel", "sma_gyro"]
N_MOTION_FEATURES = len(MOTION_FEATURE_NAMES)   # 8*3 + 2 = 26


@dataclass
class MotionWindow:
    t_start: object
    t_end: object
    feat: list


def resolve_inertial_paths(user_dir: Path, device: str):
    ga, gg = DEVICE_INERTIAL_GLOB[device]
    a = sorted(user_dir.glob(ga)); g = sorted(user_dir.glob(gg))
    return (a[0] if a else None), (g[0] if g else None)


def _stream_xyzt(path: Path):
    """Yield (x,y,z,ts) for rows with valid values+timestamp."""
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as fh:
        r = csv.reader(fh)
        try:
            next(r)
        except StopIteration:
            return
        for row in r:
            if len(row) != 5:
                continue
            ts = parse_ts(row[4])
            if ts is None:
                continue
            try:
                yield float(row[1]), float(row[2]), float(row[3]), ts
            except ValueError:
                continue


def _bucketize(path, t0, window_s):
    """Return {win_idx: [(x,y,z), ...]} for one inertial stream."""
    buckets = {}
    for x, y, z, ts in _stream_xyzt(path):
        idx = int((ts - t0).total_seconds() // window_s)
        if idx < 0:
            continue
        buckets.setdefault(idx, []).append((x, y, z))
    return buckets


def _chan_stats(vals):
    n = len(vals)
    m = sum(vals) / n
    var = sum((v - m) ** 2 for v in vals) / n
    rms = (sum(v * v for v in vals) / n) ** 0.5
    return m, var ** 0.5, rms


def _window_features(acc, gyr):
    """acc, gyr: lists of (x,y,z). Returns the 26-D feature vector."""
    def unpack(pts):
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]; zs = [p[2] for p in pts]
        mag = [math.sqrt(a * a + b * b + c * c) for a, b, c in pts]
        return xs, ys, zs, mag
    ax, ay, az, amag = unpack(acc)
    gx, gy, gz, gmag = unpack(gyr)
    feats = []
    for ch in (ax, ay, az, amag, gx, gy, gz, gmag):
        m, sd, rms = _chan_stats(ch)
        feats += [m, sd, rms]
    sma_a = sum(abs(a) + abs(b) + abs(c) for a, b, c in acc) / len(acc)
    sma_g = sum(abs(a) + abs(b) + abs(c) for a, b, c in gyr) / len(gyr)
    feats += [sma_a, sma_g]
    return feats


def reconstruct_motion_windows(accel_path, gyro_path, window_s=2.0, min_samples=50):
    """Build time-aligned motion windows from accel+gyro. Returns list[MotionWindow]."""
    if accel_path is None or gyro_path is None:
        return []
    # find common start time (streaming first row of each)
    a_first = next(_stream_xyzt(accel_path), None)
    g_first = next(_stream_xyzt(gyro_path), None)
    if a_first is None or g_first is None:
        return []
    t0 = min(a_first[3], g_first[3])
    ab = _bucketize(accel_path, t0, window_s)
    gb = _bucketize(gyro_path, t0, window_s)
    windows = []
    for idx in sorted(set(ab) & set(gb)):
        acc, gyr = ab[idx], gb[idx]
        if len(acc) >= min_samples and len(gyr) >= min_samples:
            from datetime import timedelta
            ts = t0 + timedelta(seconds=idx * window_s)
            windows.append(MotionWindow(ts, ts + timedelta(seconds=window_s),
                                        _window_features(acc, gyr)))
    windows.sort(key=lambda w: w.t_start)
    return windows
