"""
STAGE 21 — Multimodal PPFLFM: EARLY *and* LATE fusion through FL + SA + DP + continuous
(multimodal step 4 — Phase C integration, both fusion paths)

                 ┌── EARLY (concat) ─→ FL / non-IID / DP / continuous
K + S + M ───────┤
                 └── LATE  (per-modality models, val-calibrated score fusion) ─→ same stack

Both paths use the SAME aligned Phone/Tablet population (bins where K, S and M all
co-occur; Desktop excluded — no touch/inertial sensors), the SAME leakage-safe split,
and multi-seed 95% CI. DP epsilon uses the single shared accountant (ppflfm_ml.dp_epsilon)
and prints (n,q,steps) so it is auditable against Stage 12.

Colab: !python stage21_multimodal_ppflfm.py   (needs numpy, torch; run stages 01-04 first.
        Heavy — use DEV_SUBSET only to debug.)
Outputs -> results/19_mm_ppflfm/{stage21_report.txt, mm_fl.csv, mm_dp.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import itertools
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

from ppflfm_common import (resolve_root, stage_dir, append_results, require_gate,
                           make_stream_split, assert_leakage_safe, MODEL, TRAIN, FL, DP,
                           SEED, SEEDS, DEV_SUBSET)
from ppflfm_eval import (classification_metrics, verification_metrics, whole_session_aggregate)
from ppflfm_ml import (set_seed, BehaviorAuthNet, train_model, predict_proba, run_federated,
                       dp_train, dp_epsilon, secure_aggregate, flatten_state, _clone_state)
import ppflfm_fusion as FU

DEVICE_CODE = {"Phone": 1, "Tablet": 2}
MODS = ("K", "S", "M")
PHASEC_SEEDS = SEEDS[:3] if len(SEEDS) >= 3 else SEEDS


def ci95(vals):
    v = np.asarray(vals, float); n = len(v)
    m = float(v.mean()); sd = float(v.std(ddof=1)) if n > 1 else 0.0
    return m, (1.96 * sd / np.sqrt(n) if n > 1 else 0.0)


def simplex(k, step=0.25):
    pts = [i * step for i in range(int(round(1 / step)) + 1)]
    return [c for c in itertools.product(pts, repeat=k) if abs(sum(c) - 1) < 1e-6]


def calibrate_weights(val_probas, yval, nC):
    best, best_eer = None, float("inf")
    for w in simplex(len(val_probas)):
        fused = sum(wi * p for wi, p in zip(w, val_probas))
        e = verification_metrics(fused, yval, labels=np.arange(nC))["eer"]
        if e < best_eer:
            best_eer, best = e, w
    return best


def build_fused(root, dev_subset):
    """Aligned K+S+M dataset. Returns d with concat + per-modality blocks (train-only scaled)."""
    table = FU.build_fusion_table(root, dev_subset=dev_subset)
    by = {}
    for r in table:
        if r["K"] is not None and r["S"] is not None and r["M"] is not None:
            by.setdefault((r["user"], r["device"]), []).append(r)
    f = FU.FUSION
    parts = {}
    for key, rs in by.items():
        rs.sort(key=lambda r: r["bin"])
        sp = make_stream_split(key[0], key[1], len(rs), f["train_frac"], f["val_frac"],
                               f["test_frac"], f["guard_events"], f["min_bins"], f["min_partition"])
        if not sp.usable:
            continue
        assert_leakage_safe(sp)
        for i, r in enumerate(rs):
            for nm, (a, b) in (("train", sp.train), ("val", sp.val), ("test", sp.test)):
                if a <= i < b:
                    parts[id(r)] = nm
    incl = sorted({k[0] for k in by}); enc = {u: i for i, u in enumerate(incl)}
    raw = {p: dict(K=[], S=[], M=[], y=[], dev=[]) for p in ("train", "val", "test")}
    for key in sorted(by):
        for r in by[key]:
            if id(r) not in parts:
                continue
            p = parts[id(r)]
            raw[p]["K"].append(r["K"]); raw[p]["S"].append(r["S"]); raw[p]["M"].append(r["M"])
            raw[p]["y"].append(enc[r["user"]]); raw[p]["dev"].append(DEVICE_CODE[r["device"]])

    d = {"n_classes": len(incl)}
    for p in ("train", "val", "test"):
        d[f"y_{p}"] = np.asarray(raw[p]["y"], np.int64)
        d[f"device_{p}"] = np.asarray(raw[p]["dev"], np.int64)
    # scale each block (and the concat) on TRAIN only
    blocks = {}
    for m in MODS:
        tr = np.asarray(raw["train"][m], np.float32)
        mean = tr.mean(0); sd = tr.std(0); sd = np.where(sd < 1e-9, 1e-9, sd)
        blocks[m] = {p: (np.asarray(raw[p][m], np.float32) - mean) / sd for p in ("train", "val", "test")}
    d["blocks"] = blocks
    concat = {}
    for p in ("train", "val", "test"):
        concat[p] = np.concatenate([blocks[m][p] for m in MODS], axis=1)
    d["concat"] = concat
    d["in_dim"] = concat["train"].shape[1]
    return d, incl


def dd(d, X_by_part):
    return dict(X_train=X_by_part["train"], y_train=d["y_train"],
                X_val=X_by_part["val"], y_val=d["y_val"],
                X_test=X_by_part["test"], y_test=d["y_test"],
                device_test=d["device_test"], in_dim=X_by_part["train"].shape[1],
                n_classes=d["n_classes"])


def ev(proba, y, dev, nC):
    cls = classification_metrics(y, proba.argmax(1), n_classes=nC)
    ver = verification_metrics(proba, y, labels=np.arange(nC))
    Ps, Ys = whole_session_aggregate(proba, y, dev)
    se = verification_metrics(Ps, Ys, labels=np.arange(nC))["eer"] if len(Ys) else float("nan")
    return cls["accuracy"], ver["eer"], ver["auc"], se


def train_centralized(data, seed):
    set_seed(seed)
    m = BehaviorAuthNet(data["in_dim"], data["n_classes"], MODEL["hidden1"], MODEL["hidden2"],
                        MODEL["dropout"], norm=MODEL["norm"])
    train_model(m, data, TRAIN)
    return m


def main():
    require_gate("stage04")
    root = resolve_root()
    out = stage_dir("19_mm_ppflfm")
    if DEV_SUBSET is not None:
        print("!" * 70 + f"\n!!! DEV_SUBSET={DEV_SUBSET}: PILOT ONLY, NOT FINAL.\n" + "!" * 70)
    print("[stage21] building aligned K+S+M dataset ...")
    d, incl = build_fused(root, DEV_SUBSET)
    nC = d["n_classes"]; yte = d["y_test"]; dev = np.asarray(d["device_test"])
    print(f"[stage21] fused dim={d['in_dim']} users={nC} "
          f"train/val/test={len(d['y_train'])}/{len(d['y_val'])}/{len(yte)}")
    if len(d["y_train"]) < 20 or nC < 2:
        print("[stage21] too few fused samples; run full population (DEV_SUBSET=None)."); return
    cfg = {**FL, **TRAIN}
    rows, report = [], []
    report.append(f"aligned K+S+M dim={d['in_dim']} users={nC} train/test={len(d['y_train'])}/{len(yte)} "
                  f"(Phone/Tablet; Desktop excluded)  seeds={PHASEC_SEEDS}")
    if DEV_SUBSET is not None:
        report.insert(0, f"*** PILOT (DEV_SUBSET={DEV_SUBSET}) — NOT FINAL ***")

    alpha_ni = FL["dirichlet_alpha"][-2]
    # (name, fusion, kind, alpha, mu)
    specs = [("Centralized", "early", "cen", None, 0.0),
             ("FedAvg-IID", "early", "fedavg", None, 0.0),
             ("FedProx-IID", "early", "fedavg", None, FL["fedprox_mu"]),
             (f"FedAvg-a{alpha_ni}", "early", "fedavg", alpha_ni, 0.0),
             ("FedAvg-IID", "late", "fedavg", None, 0.0),
             (f"FedAvg-a{alpha_ni}", "late", "fedavg", alpha_ni, 0.0)]
    agg = {}
    for sd in PHASEC_SEEDS:
        for name, fusion, kind, alpha, mu in specs:
            if fusion == "early":
                data = dd(d, d["concat"])
                if kind == "cen":
                    model = train_centralized(data, sd)
                else:
                    model, _, _ = run_federated(data, cfg, alpha=alpha, aggregation=kind, mu=mu,
                                                seed=sd, norm=MODEL["norm"])
                p = predict_proba(model, data["X_test"])
            else:  # LATE: per-modality models -> val-calibrated score fusion
                valp, testp = [], []
                for m in MODS:
                    dm = dd(d, d["blocks"][m])
                    mm, _, _ = run_federated(dm, cfg, alpha=alpha, aggregation=kind, mu=mu,
                                             seed=sd, norm=MODEL["norm"])
                    valp.append(predict_proba(mm, dm["X_val"]))
                    testp.append(predict_proba(mm, dm["X_test"]))
                w = calibrate_weights(valp, d["y_val"], nC)
                p = sum(wi * tp for wi, tp in zip(w, testp))
            a, e, u, se = ev(p, yte, dev, nC)
            k = (name, fusion)
            agg.setdefault(k, {"acc": [], "eer": [], "auc": [], "sess": []})
            agg[k]["acc"].append(a); agg[k]["eer"].append(e); agg[k]["auc"].append(u); agg[k]["sess"].append(se)
        print(f"  seed {sd} done")

    report.append("  method            fusion   acc            EER            sessEER")
    for (name, fusion), v in agg.items():
        am, ah = ci95(v["acc"]); em, eh = ci95(v["eer"]); um, _ = ci95(v["auc"]); sm, sh = ci95(v["sess"])
        rows.append(dict(method=name, fusion=fusion, acc_mean=round(am, 4), acc_ci=round(ah, 4),
                         eer_mean=round(em, 4), eer_ci=round(eh, 4), auc_mean=round(um, 4),
                         sess_eer_mean=round(sm, 4), sess_eer_ci=round(sh, 4)))
        report.append(f"  {name:16s} {fusion:6s}  acc={am:.4f}+/-{ah:.4f}  EER={em:.4f}+/-{eh:.4f}  "
                      f"sessEER={sm:.4f}+/-{sh:.4f}")

    # Secure aggregation equivalence at multimodal model size (deterministic; modality-agnostic)
    mm = BehaviorAuthNet(d["in_dim"], nC, norm=MODEL["norm"])
    vec, _ = flatten_state(_clone_state(mm.state_dict()))
    rng = np.random.default_rng(SEED)
    ups = [torch.tensor(rng.normal(0, 0.02, vec.numel()), dtype=torch.float64) for _ in range(FL["n_clients"])]
    sa_err = float((secure_aggregate(ups, seed=SEED)[0] - torch.stack(ups).sum(0)).abs().max())
    report.append(f"  SecureAgg (dim={vec.numel()}): ||plain-secure||inf={sa_err:.2e} "
                  f"(applies to BOTH fusion paths; per-modality FL updates masked identically)")

    # DP-SGD: EARLY (concat) and LATE (per-modality, fused), multi-seed
    dp_cfg = {"lr": DP["lr"], "batch_size": DP["batch_size"], "epochs": DP["epochs"]}
    dp_seeds = list(range(1, DP.get("n_seeds", 3) + 1))
    dp_rows = []
    for sigma in DP["noise_multipliers"]:
        for fusion in ("early", "late"):
            eers, steps_rec, q_rec = [], None, None
            for sd in dp_seeds:
                if fusion == "early":
                    model, steps_rec, q_rec = dp_train(dd(d, d["concat"]), dp_cfg, clip=DP["clip_norm"],
                                                       sigma=sigma, seed=sd, norm="layer")
                    p = predict_proba(model, d["concat"]["test"])
                else:
                    tps = []
                    for m in MODS:
                        model, steps_rec, q_rec = dp_train(dd(d, d["blocks"][m]), dp_cfg,
                                                           clip=DP["clip_norm"], sigma=sigma, seed=sd, norm="layer")
                        tps.append(predict_proba(model, d["blocks"][m]["test"]))
                    p = sum(tps) / len(tps)     # equal-weight late score fusion under DP
                eers.append(ev(p, yte, dev, nC)[1])
            eps = dp_epsilon(q_rec, sigma, steps_rec, DP["delta"]) if sigma > 0 else float("inf")
            eps_s = "inf" if not np.isfinite(eps) else f"{eps:.3f}"
            em, eh = ci95(eers)
            dp_rows.append(dict(sigma=sigma, fusion=fusion, epsilon=eps_s, n_train=len(d["y_train"]),
                                q=round(q_rec, 5), steps=steps_rec, eer_mean=round(em, 4), eer_ci=round(eh, 4)))
            report.append(f"  DP-MM {fusion:5s} sigma={sigma:<4} eps={eps_s:>8} (n={len(d['y_train'])} "
                          f"q={q_rec:.4f} steps={steps_rec}) EER={em:.4f}+/-{eh:.4f} (sample-level)")

    best = min(rows, key=lambda r: r["sess_eer_mean"])
    report.append(f"  Continuous best: {best['method']}/{best['fusion']} "
                  f"sessEER={best['sess_eer_mean']:.4f}+/-{best['sess_eer_ci']:.4f} "
                  f"(vs its window EER={best['eer_mean']:.4f})")

    with open(out / "mm_fl.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    with open(out / "mm_dp.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(dp_rows[0].keys())); w.writeheader(); w.writerows(dp_rows)
    append_results([dict(stage="21_mm_ppflfm", method=f"{r['method']}-{r['fusion']}",
                         setting="multimodal", seed="mean", task="A+B", accuracy=r["acc_mean"],
                         eer=r["eer_mean"], auc=r["auc_mean"],
                         extra=f"eer_ci={r['eer_ci']};sessEER={r['sess_eer_mean']}") for r in rows])
    txt = ("=" * 70 + "\nSTAGE 21 - MULTIMODAL PPFLFM (EARLY & LATE fusion through FL+SA+DP+CA)\n"
           + "=" * 70 + "\n" + "\n".join(report) + "\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage21_report.txt").write_text(txt, "utf-8")
    print(f"[stage21] wrote {out}")


if __name__ == "__main__":
    main()
