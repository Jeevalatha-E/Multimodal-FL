"""
STAGE 05 — Centralized baselines (roadmap PHASE 8)

Simple reference classifiers on the Stage-04 features, evaluated on the SEALED test
set. Directly answers the editor's "comparison with simple reference classifiers".

Baselines: Majority, Random(stratified), Logistic Regression, Linear SVM,
           Random Forest, MLP (sklearn).
Metrics  : Task A (accuracy, macro-F1, balanced accuracy) + Task B verification
           (EER/AUC) for models exposing probabilities.

Needs: numpy, scikit-learn.  Colab: !python stage05_baselines.py
Outputs -> results/03_baselines/{stage05_report.txt, baselines.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import json

import numpy as np

from ppflfm_common import get_feature_dirs, stage_dir, append_results, SEED
from ppflfm_eval import classification_metrics, verification_metrics, summarize
from ppflfm_ml import load_windows

from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.dummy import DummyClassifier


def main():
    _, processed, _ = get_feature_dirs()
    out = stage_dir("03_baselines")
    d = load_windows(processed)
    Xtr, ytr, Xte, yte = d["X_train"], d["y_train"], d["X_test"], d["y_test"]
    nC = d["n_classes"]
    print(f"[stage05] train={Xtr.shape} test={Xte.shape} classes={nC}")

    models = {
        "Majority": (DummyClassifier(strategy="most_frequent"), False),
        "Random": (DummyClassifier(strategy="stratified", random_state=SEED), True),
        "LogisticRegression": (LogisticRegression(max_iter=2000, C=1.0, n_jobs=-1), True),
        "LinearSVM": (LinearSVC(C=1.0, max_iter=5000), False),
        "RandomForest": (RandomForestClassifier(n_estimators=300, n_jobs=-1,
                         random_state=SEED), True),
        "MLP": (MLPClassifier(hidden_layer_sizes=(128, 64), max_iter=300,
                random_state=SEED), True),
    }

    rows, report, ledger = [], [], []
    for name, (clf, has_proba) in models.items():
        clf.fit(Xtr, ytr)
        yp = clf.predict(Xte)
        cls = classification_metrics(yte, yp, n_classes=nC)
        ver = None
        if name == "Random":
            # honest random-VERIFICATION baseline: independent U(0,1) scores -> AUC~0.5.
            # (The stratified dummy returns CONSTANT class priors, which would give a
            #  misleading AUC>0.5 under non-uniform priors — not a metric bug.)
            rng = np.random.default_rng(SEED)
            ver = verification_metrics(rng.random((len(Xte), nC)), yte, labels=np.arange(nC))
        elif has_proba and hasattr(clf, "predict_proba"):
            proba = clf.predict_proba(Xte)
            # align proba columns to 0..nC-1 (dummy/others may omit classes)
            full = np.zeros((len(Xte), nC))
            for j, c in enumerate(clf.classes_):
                full[:, int(c)] = proba[:, j]
            ver = verification_metrics(full, yte, labels=np.arange(nC))
        line = summarize(name, cls, ver)
        print("  " + line)
        report.append(line)
        rows.append(dict(method=name, **{k: cls[k] for k in
                    ("accuracy", "macro_f1", "balanced_accuracy")},
                    eer=(ver or {}).get("eer", ""), auc=(ver or {}).get("auc", ""),
                    macro_eer=(ver or {}).get("macro_eer", "")))
        ledger.append(dict(stage="05_baselines", method=name, setting="centralized",
                           seed=SEED, task="A+B",
                           accuracy=cls["accuracy"], macro_f1=cls["macro_f1"],
                           balanced_accuracy=cls["balanced_accuracy"],
                           eer=(ver or {}).get("eer", ""), auc=(ver or {}).get("auc", ""),
                           macro_eer=(ver or {}).get("macro_eer", ""),
                           tar_at_far_1pct=(ver or {}).get("tar_at_far_1pct", "")))

    with open(out / "baselines.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    append_results(ledger)

    chance = 1.0 / nC
    txt = ("=" * 70 + "\nSTAGE 05 - CENTRALIZED BASELINES\n" + "=" * 70 +
           f"\nchance level (1/{nC}) = {chance:.4f}\n\n" + "\n".join(report) + "\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage05_report.txt").write_text(txt, "utf-8")
    print(f"\n[stage05] wrote {out}")


if __name__ == "__main__":
    main()
