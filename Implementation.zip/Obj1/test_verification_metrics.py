"""
test_verification_metrics.py — sanity tests for the verification evaluator
(review Priority 2). Proves FAR/FRR/EER/ROC-AUC are implemented correctly by
feeding synthetic score matrices with known answers.

Expected:
  random   scores ~ U(0,1)         -> AUC ~ 0.5, EER ~ 0.5
  perfect  (genuine >> impostor)   -> AUC ~ 1.0, EER ~ 0.0
  inverted (genuine << impostor)   -> AUC ~ 0.0, EER ~ 1.0
  constant (all equal)             -> AUC ~ 0.5, EER ~ 0.5

Run:  python test_verification_metrics.py   (exit code 0 = all pass)
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ppflfm_eval import verification_metrics  # noqa: E402


def make(n=3000, K=20, seed=0):
    rng = np.random.default_rng(seed)
    y = rng.integers(0, K, size=n)
    idx = np.arange(n)
    random_s = rng.random((n, K))
    perfect = rng.random((n, K)) * 0.4
    perfect[idx, y] = 1.0
    inverted = rng.random((n, K)) * 0.4 + 0.6
    inverted[idx, y] = 0.0
    constant = np.ones((n, K)) * 0.5
    return y, {"random": random_s, "perfect": perfect, "inverted": inverted, "constant": constant}


def close(a, b, tol):
    return abs(a - b) <= tol


def main():
    y, mats = make()
    K = mats["random"].shape[1]
    expect = {  # (auc, eer, tol)
        "random":   (0.5, 0.5, 0.05),
        "perfect":  (1.0, 0.0, 0.02),
        "inverted": (0.0, 1.0, 0.02),
        "constant": (0.5, 0.5, 0.05),
    }
    ok = True
    print(f"{'case':10s} {'AUC':>8s} {'EER':>8s}   verdict")
    for name, scores in mats.items():
        m = verification_metrics(scores, y, labels=np.arange(K))
        eauc, eeer, tol = expect[name]
        passed = close(m["auc"], eauc, tol) and close(m["eer"], eeer, tol)
        ok = ok and passed
        print(f"{name:10s} {m['auc']:8.4f} {m['eer']:8.4f}   "
              f"{'PASS' if passed else 'FAIL'} (expect AUC~{eauc}, EER~{eeer})")
    print("\nALL PASS" if ok else "\nSOME FAILED")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
