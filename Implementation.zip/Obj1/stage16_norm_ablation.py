"""
STAGE 16 — Normalization ablation: BatchNorm vs LayerNorm vs NoNorm  (review #7)

BatchNorm keeps per-client running statistics that FedAvg averages naively, which can
hurt under heterogeneous clients. This stage compares the three normalizations under
centralized training AND FedAvg (IID) so the architecture is chosen from evidence, not
assumed. Run before finalizing the model.

Colab: !python stage16_norm_ablation.py   (needs numpy, torch; run stages 01-04 first)
Outputs -> results/14_norm/{stage16_report.txt, norm_ablation.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import numpy as np

from ppflfm_common import get_feature_dirs, stage_dir, append_results, require_gate, MODEL, TRAIN, FL, SEED
from ppflfm_eval import classification_metrics, verification_metrics
from ppflfm_ml import (load_windows, set_seed, BehaviorAuthNet, train_model,
                       predict_proba, run_federated)


def evaluate(model, d):
    proba = predict_proba(model, d["X_test"])
    cls = classification_metrics(d["y_test"], proba.argmax(1), n_classes=d["n_classes"])
    ver = verification_metrics(proba, d["y_test"], labels=np.arange(d["n_classes"]))
    return cls, ver


def main():
    require_gate("stage04")
    _, processed, _ = get_feature_dirs()
    out = stage_dir("14_norm")
    d = load_windows(processed)
    cfg = {**FL, **TRAIN}

    rows, ledger, report = [], [], []
    for norm in ("batch", "layer", "none"):
        # centralized
        set_seed(SEED)
        mc = BehaviorAuthNet(d["in_dim"], d["n_classes"], MODEL["hidden1"], MODEL["hidden2"],
                             MODEL["dropout"], norm=norm)
        train_model(mc, d, TRAIN)
        cC, vC = evaluate(mc, d)
        # federated (IID)
        mf, _, _ = run_federated(d, cfg, alpha=None, aggregation="fedavg", seed=SEED, norm=norm)
        cF, vF = evaluate(mf, d)

        rows.append(dict(norm=norm, cen_acc=cC["accuracy"], cen_eer=vC["eer"],
                         fl_acc=cF["accuracy"], fl_eer=vF["eer"]))
        for scope, cls, ver in (("centralized", cC, vC), ("fedavg_iid", cF, vF)):
            ledger.append(dict(stage="16_norm", method=f"{scope}", setting=f"norm={norm}",
                               seed=SEED, task="A+B", accuracy=cls["accuracy"], macro_f1=cls["macro_f1"],
                               balanced_accuracy=cls["balanced_accuracy"], eer=ver["eer"], auc=ver["auc"],
                               macro_eer=ver["macro_eer"]))
        msg = (f"  norm={norm:6s} centralized acc={cC['accuracy']:.4f} EER={vC['eer']:.4f} | "
               f"FedAvg acc={cF['accuracy']:.4f} EER={vF['eer']:.4f}")
        print(msg); report.append(msg)

    with open(out / "norm_ablation.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    append_results(ledger)
    txt = ("=" * 70 + "\nSTAGE 16 - NORMALIZATION ABLATION (Batch vs Layer vs None)\n" + "=" * 70 +
           "\n(pick the architecture from evidence; BatchNorm can hurt FL under heterogeneity)\n\n" +
           "\n".join(report) + "\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage16_report.txt").write_text(txt, "utf-8")
    print(f"[stage16] wrote {out}")


if __name__ == "__main__":
    main()
