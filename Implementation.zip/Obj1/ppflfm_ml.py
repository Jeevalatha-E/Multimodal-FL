"""
ppflfm_ml.py — shared ML / FL / privacy utilities (torch).

Contents:
  * set_seed, load_windows (npz -> arrays with 0-indexed labels)
  * BehaviorAuthNet (roadmap architecture; norm switchable for DP compatibility)
  * centralized train / evaluate (early stopping)
  * FL: IID + Dirichlet non-IID partitioning, local update (+FedProx),
        FedAvg and entropy-weighted aggregation
  * secure aggregation: pairwise additive masks (sum cancels) + verifier
  * DP-SGD: per-example clipping + Gaussian noise, and an RDP accountant

Only stages 06+ import this. Stages 01–04 stay torch-free.
"""
from __future__ import annotations

import math
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn


# --------------------------------------------------------------------------- #
# Reproducibility & data
# --------------------------------------------------------------------------- #
def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_windows(processed_dir: Path) -> dict:
    d = np.load(Path(processed_dir) / "keystroke_windows.npz", allow_pickle=True)
    labels = np.unique(d["y_train"])            # user ids present in train
    enc = {c: i for i, c in enumerate(labels)}

    def remap(y):
        return np.array([enc[c] for c in y], dtype=np.int64)

    return {
        "X_train": d["X_train"].astype(np.float32), "y_train": remap(d["y_train"]),
        "X_val": d["X_val"].astype(np.float32), "y_val": remap(d["y_val"]),
        "X_test": d["X_test"].astype(np.float32), "y_test": remap(d["y_test"]),
        "device_train": d["device_train"], "device_val": d["device_val"],
        "device_test": d["device_test"],
        "labels": labels, "n_classes": len(labels),
        "feature_names": list(d["feature_names"]),
        "in_dim": d["X_train"].shape[1],
    }


# --------------------------------------------------------------------------- #
# Model
# --------------------------------------------------------------------------- #
def _norm(kind, dim):
    if kind == "batch":
        return nn.BatchNorm1d(dim)
    if kind == "layer":
        return nn.LayerNorm(dim)
    return nn.Identity()


class BehaviorAuthNet(nn.Module):
    """FC(128)-Norm-ReLU-Drop - FC(64)-Norm-ReLU-Drop - FC(n_classes).

    norm='batch' matches the manuscript; DP-SGD requires 'none' or 'layer'
    (BatchNorm mixes samples and breaks per-example gradients / DP guarantees).
    """
    def __init__(self, in_dim, n_classes, hidden1=128, hidden2=64, dropout=0.3, norm="batch"):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden1), _norm(norm, hidden1), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden1, hidden2), _norm(norm, hidden2), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden2, n_classes),
        )

    def forward(self, x):
        return self.net(x)


def _tensors(X, y, device):
    return torch.tensor(X, dtype=torch.float32, device=device), \
        torch.tensor(y, dtype=torch.long, device=device)


# --------------------------------------------------------------------------- #
# Centralized training / evaluation
# --------------------------------------------------------------------------- #
def train_model(model, data, cfg, device="cpu", verbose=False):
    model.to(device)
    Xtr, ytr = _tensors(data["X_train"], data["y_train"], device)
    Xva, yva = _tensors(data["X_val"], data["y_val"], device)
    opt = torch.optim.Adam(model.parameters(), lr=cfg["lr"], weight_decay=cfg.get("weight_decay", 0.0))
    lossf = nn.CrossEntropyLoss()
    n = len(Xtr)
    bs = cfg["batch_size"]
    best_val, best_state, wait = float("inf"), None, 0
    history = []
    for ep in range(cfg["epochs"]):
        model.train()
        perm = torch.randperm(n, device=device)
        tot = 0.0
        for i in range(0, n, bs):
            idx = perm[i:i + bs]
            if len(idx) < 2:
                continue
            opt.zero_grad()
            out = model(Xtr[idx])
            loss = lossf(out, ytr[idx])
            loss.backward()
            opt.step()
            tot += loss.item() * len(idx)
        model.eval()
        with torch.no_grad():
            vout = model(Xva)
            vloss = lossf(vout, yva).item()
            vacc = (vout.argmax(1) == yva).float().mean().item()
        history.append({"epoch": ep, "train_loss": tot / n, "val_loss": vloss, "val_acc": vacc})
        if verbose:
            print(f"  ep{ep:03d} train_loss={tot/n:.4f} val_loss={vloss:.4f} val_acc={vacc:.4f}")
        if vloss < best_val - 1e-5:
            best_val, best_state, wait = vloss, {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}, 0
        else:
            wait += 1
            if wait >= cfg.get("patience", 10):
                break
    if best_state:
        model.load_state_dict(best_state)
    return history


@torch.no_grad()
def predict_proba(model, X, device="cpu"):
    model.eval().to(device)
    out = model(torch.tensor(X, dtype=torch.float32, device=device))
    return torch.softmax(out, dim=1).cpu().numpy()


def predict(model, X, device="cpu"):
    return predict_proba(model, X, device).argmax(1)


# --------------------------------------------------------------------------- #
# Federated partitioning
# --------------------------------------------------------------------------- #
def partition_iid(n, K, seed):
    rng = np.random.default_rng(seed)
    idx = rng.permutation(n)
    return [np.sort(a) for a in np.array_split(idx, K)]


def partition_dirichlet(y, K, alpha, seed, min_size=10):
    """Class-wise Dirichlet split (standard non-IID benchmark)."""
    rng = np.random.default_rng(seed)
    y = np.asarray(y)
    classes = np.unique(y)
    for _ in range(100):
        parts = [[] for _ in range(K)]
        for c in classes:
            cidx = np.where(y == c)[0]
            rng.shuffle(cidx)
            prop = rng.dirichlet(np.repeat(alpha, K))
            cuts = (np.cumsum(prop) * len(cidx)).astype(int)[:-1]
            for k, chunk in enumerate(np.split(cidx, cuts)):
                parts[k].extend(chunk.tolist())
        if min(len(p) for p in parts) >= min_size:
            break
    return [np.sort(np.array(p, dtype=int)) for p in parts]


def class_entropy(y, n_classes):
    counts = np.bincount(np.asarray(y), minlength=n_classes).astype(float)
    p = counts / counts.sum()
    p = p[p > 0]
    return float(-(p * np.log(p)).sum())


# --------------------------------------------------------------------------- #
# Local update + aggregation
# --------------------------------------------------------------------------- #
def _clone_state(state):
    return {k: v.detach().cpu().clone() for k, v in state.items()}


def local_update(global_state, model, Xc, yc, cfg, device="cpu", mu=0.0):
    """Train `model` from global_state on one client's data. Returns (state, n, entropy)."""
    model.load_state_dict(global_state)
    model.to(device).train()
    Xt, yt = _tensors(Xc, yc, device)
    opt = torch.optim.Adam(model.parameters(), lr=cfg["lr"])
    lossf = nn.CrossEntropyLoss()
    gref = [p.detach().clone() for p in model.parameters()] if mu > 0 else None
    n = len(Xt)
    bs = cfg["batch_size"]
    for _ in range(cfg["local_epochs"]):
        perm = torch.randperm(n, device=device)
        for i in range(0, n, bs):
            idx = perm[i:i + bs]
            if len(idx) < 2:
                continue
            opt.zero_grad()
            loss = lossf(model(Xt[idx]), yt[idx])
            if mu > 0:
                prox = sum(((p - g) ** 2).sum() for p, g in zip(model.parameters(), gref))
                loss = loss + 0.5 * mu * prox
            loss.backward()
            opt.step()
    return _clone_state(model.state_dict()), n, class_entropy(yc, model.net[-1].out_features)


def aggregate(states, weights):
    weights = np.asarray(weights, dtype=np.float64)
    weights = weights / weights.sum()
    out = {}
    for k in states[0]:
        acc = torch.zeros_like(states[0][k], dtype=torch.float64)
        for w, st in zip(weights, states):
            acc += w * st[k].double()
        out[k] = acc.to(states[0][k].dtype)
    return out


def fedavg_weights(sizes):
    return np.asarray(sizes, dtype=np.float64)


def entropy_weights(entropies, eps=1e-6):
    inv = 1.0 / (np.asarray(entropies, dtype=np.float64) + eps)
    return inv


def run_federated(data, cfg, device="cpu", alpha=None, aggregation="fedavg",
                  mu=0.0, seed=42, eval_every=0, norm="batch"):
    """Train FL. Returns (global_model, history[list per round], client_sizes)."""
    set_seed(seed)
    n_classes, in_dim = data["n_classes"], data["in_dim"]
    Xtr, ytr = data["X_train"], data["y_train"]
    K = cfg["n_clients"]
    if alpha is None:
        parts = partition_iid(len(Xtr), K, seed)
    else:
        parts = partition_dirichlet(ytr, K, alpha, seed)
    sizes = [len(p) for p in parts]

    model = BehaviorAuthNet(in_dim, n_classes, norm=norm)
    global_state = _clone_state(model.state_dict())
    Xva, yva = _tensors(data["X_val"], data["y_val"], device)
    lossf = nn.CrossEntropyLoss()
    history = []
    for rnd in range(cfg["rounds"]):
        states, ns, ents = [], [], []
        for p in parts:
            if len(p) < 2:
                continue
            st, n, ent = local_update(global_state, model, Xtr[p], ytr[p], cfg, device, mu)
            states.append(st); ns.append(n); ents.append(ent)
        w = fedavg_weights(ns) if aggregation == "fedavg" else entropy_weights(ents)
        global_state = aggregate(states, w)
        model.load_state_dict(global_state)
        model.eval()
        with torch.no_grad():
            vout = model(Xva)
            vloss = lossf(vout, yva).item()
            vacc = (vout.argmax(1) == yva).float().mean().item()
        history.append({"round": rnd, "val_loss": vloss, "val_acc": vacc})
    return model, history, sizes


# --------------------------------------------------------------------------- #
# Secure aggregation (pairwise additive masks — sum cancels exactly)
# --------------------------------------------------------------------------- #
def flatten_state(state):
    keys = list(state.keys())
    vec = torch.cat([state[k].reshape(-1).double() for k in keys])
    shapes = [(k, tuple(state[k].shape)) for k in keys]
    return vec, shapes


def unflatten_state(vec, shapes, ref_state):
    out, off = {}, 0
    for k, shp in shapes:
        num = int(np.prod(shp)) if shp else 1
        out[k] = vec[off:off + num].reshape(shp).to(ref_state[k].dtype)
        off += num
    return out


def secure_aggregate(client_vecs, seed=0, mask_gain=8.0):
    """Additive pairwise masks: for i<j a shared r_ij is added by i, subtracted by j,
    so masks cancel in the sum and the server sees only masked updates.

    Masks are scaled to the signal RMS (x mask_gain) so they still hide an individual
    update while keeping float64 cancellation at machine precision (avoids catastrophic
    cancellation when N(0,1) masks would dwarf tiny weight updates). Returns
    (agg_vec, overhead_floats_per_client).
    """
    K = len(client_vecs)
    d = client_vecs[0].numel()
    vecs = [v.double() for v in client_vecs]
    rms = max((float(v.pow(2).mean().sqrt()) for v in vecs), default=1.0)
    scale = mask_gain * (rms if rms > 0 else 1.0)
    rng = np.random.default_rng(seed)
    masks = [torch.zeros(d, dtype=torch.float64) for _ in range(K)]
    for i in range(K):
        for j in range(i + 1, K):
            r = torch.tensor(rng.standard_normal(d), dtype=torch.float64) * scale
            masks[i] += r
            masks[j] -= r
    masked = [v + m for v, m in zip(vecs, masks)]
    agg = torch.stack(masked).sum(0)
    return agg, d * (K - 1)


# --------------------------------------------------------------------------- #
# DP-SGD (per-example clipping + Gaussian noise) + RDP accountant
# --------------------------------------------------------------------------- #
def dp_train(data, cfg, clip, sigma, device="cpu", seed=42, norm="none"):
    """Centralized DP-SGD on the training set. Returns (model, steps, sample_rate)."""
    set_seed(seed)
    model = BehaviorAuthNet(data["in_dim"], data["n_classes"],
                            dropout=0.0, norm=norm).to(device)   # no BN/dropout for DP
    Xtr, ytr = _tensors(data["X_train"], data["y_train"], device)
    lossf = nn.CrossEntropyLoss()
    n = len(Xtr)
    bs = cfg["batch_size"]
    lr = cfg["lr"]
    params = [p for p in model.parameters()]
    steps = 0
    for _ in range(cfg["epochs"]):
        perm = torch.randperm(n, device=device)
        for i in range(0, n, bs):
            idx = perm[i:i + bs]
            B = len(idx)
            if B < 2:
                continue
            accum = [torch.zeros_like(p) for p in params]
            for s in idx:                        # per-example gradient + clip
                model.zero_grad()
                loss = lossf(model(Xtr[s:s + 1]), ytr[s:s + 1])
                loss.backward()
                gnorm = torch.sqrt(sum((p.grad ** 2).sum() for p in params)) + 1e-12
                scale = min(1.0, clip / gnorm.item())
                for a, p in zip(accum, params):
                    a += p.grad.detach() * scale
            # add Gaussian noise once per batch, average, SGD step
            with torch.no_grad():
                for a, p in zip(accum, params):
                    noise = torch.randn_like(a) * (sigma * clip)
                    g = (a + noise) / B
                    p -= lr * g
            steps += 1
    return model, steps, bs / n


# ---- RDP accountant for the subsampled Gaussian mechanism (analytic moments) ----
def _log_add(a, b):
    if a == -np.inf:
        return b
    if b == -np.inf:
        return a
    return max(a, b) + math.log1p(math.exp(-abs(a - b)))


def _log_sub(a, b):
    if b == -np.inf:
        return a
    return a + math.log1p(-math.exp(min(b - a, 0)))


def _compute_log_a_int(q, sigma, alpha):
    log_a = -np.inf
    for i in range(alpha + 1):
        log_coef = (math.lgamma(alpha + 1) - math.lgamma(i + 1) - math.lgamma(alpha - i + 1))
        s = log_coef + i * math.log(q) + (alpha - i) * math.log1p(-q) \
            + (i * i - i) / (2.0 * sigma ** 2)
        log_a = _log_add(log_a, s)
    return float(log_a)


def compute_rdp(q, sigma, steps, orders):
    """RDP epsilons at each order for `steps` of the subsampled Gaussian mechanism.

    `orders` MUST be integers >= 2: _compute_log_a_int is exact only for integer alpha
    (using fractional orders here divides an integer-order log_a by a fractional
    (alpha-1), which is wrong and can saturate epsilon under large q).
    """
    rdp = []
    for alpha in orders:
        a = int(alpha)
        if a < 2:
            rdp.append(np.inf); continue
        if q == 0:
            rdp.append(0.0)
        elif sigma == 0:
            rdp.append(np.inf)
        else:
            rdp.append(_compute_log_a_int(q, sigma, a) / (a - 1))
    return np.array(rdp) * steps


def get_privacy_spent(orders, rdp, delta):
    orders = np.atleast_1d(np.asarray(orders, dtype=float))
    rdp = np.atleast_1d(rdp)
    eps = rdp - math.log(delta) / (orders - 1)
    i = int(np.nanargmin(eps))
    return float(eps[i]), float(orders[i])


def dp_epsilon(q, sigma, steps, delta, orders=None):
    if sigma == 0:
        return float("inf")
    if orders is None:
        orders = list(range(2, 257))      # INTEGER RDP orders only (see compute_rdp)
    rdp = compute_rdp(q, sigma, steps, orders)
    eps, _ = get_privacy_spent(orders, rdp, delta)
    return eps
