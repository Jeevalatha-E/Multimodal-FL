"""
STAGE 20 — Multimodal fusion + ablation (statistically valid)  (multimodal step 3)

Ablation grid K, S, M, K+S, K+M, S+M, K+S+M under BOTH:
  EARLY (feature-level): concatenate present modality blocks -> one model.
  LATE  (score-level):   per-modality models; weights CALIBRATED ON VALIDATION
                         (never the sealed test set) then applied to test.
Reports mean +/- 95% CI over multiple seeds, evaluates early & late on the SAME test
population per combo, and adds a missing-modality robustness test on the tri-modal
model. Also prints a K/S/M coverage report so the fusion population (and Desktop's
exclusion — it has no touch/inertial sensors) is explicit, not silent.

Colab: !python stage20_fusion.py   (needs numpy, torch; run stages 01-04 first for the
        gate. Heavy: re-reconstructs all three modalities on a common grid AND multi-seed
        — use DEV_SUBSET only for debugging; set it to None for real results.)
Outputs -> results/18_fusion/{stage20_report.txt, ablation_fusion.csv, coverage.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import itertools
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

from ppflfm_common import (resolve_root, stage_dir, append_results, require_gate,
                           make_stream_split, assert_leakage_safe, resolve_keyboard_path,
                           user_folders, DEVICES, MODEL, TRAIN, SEED, SEEDS, DEV_SUBSET)
from ppflfm_eval import classification_metrics, verification_metrics, whole_session_aggregate
from ppflfm_ml import set_seed, BehaviorAuthNet, train_model, predict_proba
import ppflfm_fusion as FU
import ppflfm_swipe as SW
import ppflfm_motion as MO

DEVICE_CODE = {"Phone": 1, "Tablet": 2}
COMBOS = [("K",), ("S",), ("M",), ("K", "S"), ("K", "M"), ("S", "M"), ("K", "S", "M")]
FUSION_SEEDS = SEEDS[:3] if len(SEEDS) >= 3 else SEEDS   # >=3 seeds for CI (smoke shrinks)


def ci95(vals):
    v = np.asarray(vals, float); n = len(v)
    m = float(v.mean()); sd = float(v.std(ddof=1)) if n > 1 else 0.0
    h = 1.96 * sd / np.sqrt(n) if n > 1 else 0.0
    return m, sd, h


# ------------------------------------------------------------------ coverage
def coverage_report(root, out):
    """Which user x device streams have K / S / M (file existence). Justifies the
    fusion population and Desktop's exclusion."""
    uids = user_folders(root)
    rows = []
    counts = {d: {"K": 0, "S": 0, "M": 0, "KSM": 0} for d in DEVICES}
    for uid in uids:
        udir = root / str(uid)
        for dev in DEVICES:
            hasK = resolve_keyboard_path(udir, dev) is not None
            hasS = (dev in SW.SWIPE_DEVICES) and (SW.resolve_touch_path(udir, dev) is not None)
            ap, gp = (MO.resolve_inertial_paths(udir, dev) if dev in MO.MOTION_DEVICES else (None, None))
            hasM = ap is not None and gp is not None
            counts[dev]["K"] += hasK; counts[dev]["S"] += hasS; counts[dev]["M"] += hasM
            counts[dev]["KSM"] += (hasK and hasS and hasM)
            rows.append(dict(user=uid, device=dev, K=int(hasK), S=int(hasS), M=int(hasM),
                             fusion_usable=int(hasK and hasS and hasM)))
    with open(out / "coverage.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["user", "device", "K", "S", "M", "fusion_usable"])
        w.writeheader(); w.writerows(rows)
    lines = ["K/S/M coverage (users with each modality present):",
             f"  {'device':8s} {'K':>4s} {'S':>4s} {'M':>4s} {'K+S+M':>6s}"]
    for d in DEVICES:
        c = counts[d]
        lines.append(f"  {d:8s} {c['K']:4d} {c['S']:4d} {c['M']:4d} {c['KSM']:6d}")
    lines.append("  -> Desktop has no touch/inertial sensors (S=M=0): fusion is Phone/Tablet only.")
    return lines


# ------------------------------------------------------------------ split / assemble
def split_records(table):
    by_stream = {}
    for r in table:
        by_stream.setdefault((r["user"], r["device"]), []).append(r)
    parts = {}
    f = FU.FUSION
    for key, rs in by_stream.items():
        rs.sort(key=lambda r: r["bin"])
        sp = make_stream_split(key[0], key[1], len(rs), f["train_frac"], f["val_frac"],
                               f["test_frac"], f["guard_events"], f["min_bins"], f["min_partition"])
        if not sp.usable:
            continue
        assert_leakage_safe(sp)
        for i, r in enumerate(rs):
            if sp.train[0] <= i < sp.train[1]:
                parts[id(r)] = "train"
            elif sp.val[0] <= i < sp.val[1]:
                parts[id(r)] = "val"
            elif sp.test[0] <= i < sp.test[1]:
                parts[id(r)] = "test"
    return parts


def assemble(table, mods, parts):
    rows = [r for r in table if all(r[m] is not None for m in mods) and id(r) in parts]
    if not rows:
        return None
    users = sorted({r["user"] for r in rows}); enc = {u: i for i, u in enumerate(users)}
    out = {p: dict(Xm={m: [] for m in mods}, y=[], dev=[]) for p in ("train", "val", "test")}
    for r in rows:
        p = parts[id(r)]
        for m in mods:
            out[p]["Xm"][m].append(list(r[m]))
        out[p]["y"].append(enc[r["user"]]); out[p]["dev"].append(DEVICE_CODE[r["device"]])
    for p in out:
        out[p]["y"] = np.asarray(out[p]["y"], np.int64)
        out[p]["dev"] = np.asarray(out[p]["dev"], np.int64)
        for m in mods:
            out[p]["Xm"][m] = np.asarray(out[p]["Xm"][m], np.float32)
    return out, len(users)


def _data(Xtr, ytr, Xva, yva, nC):
    return dict(X_train=Xtr, y_train=ytr, X_val=Xva, y_val=yva, in_dim=Xtr.shape[1], n_classes=nC)


def fit_block(Xtr, Xva, ytr, yva, nC, seed):
    """Fit train-only scaler + model. Returns (model, mean, sd, val_proba)."""
    mean = Xtr.mean(0); sd = Xtr.std(0); sd = np.where(sd < 1e-9, 1e-9, sd)
    set_seed(seed)
    m = BehaviorAuthNet(Xtr.shape[1], nC, MODEL["hidden1"], MODEL["hidden2"], MODEL["dropout"],
                        norm=MODEL["norm"])
    train_model(m, _data((Xtr - mean) / sd, ytr, (Xva - mean) / sd, yva, nC), TRAIN)
    return m, mean, sd, predict_proba(m, (Xva - mean) / sd)


def apply_block(model, mean, sd, X):
    return predict_proba(model, (X - mean) / sd)


def simplex(k, step=0.25):
    pts = [i * step for i in range(int(round(1 / step)) + 1)]
    for combo in itertools.product(pts, repeat=k):
        if abs(sum(combo) - 1.0) < 1e-6:
            yield combo


def calibrate_weights(val_probas, yval, nC):
    """Pick late-fusion weights minimizing VALIDATION EER (never touches test)."""
    best, best_eer = None, float("inf")
    for w in simplex(len(val_probas)):
        fused = sum(wi * p for wi, p in zip(w, val_probas))
        e = verification_metrics(fused, yval, labels=np.arange(nC))["eer"]
        if e < best_eer:
            best_eer, best = e, w
    return best


def ev(proba, y, dev, nC):
    cls = classification_metrics(y, proba.argmax(1), n_classes=nC)
    ver = verification_metrics(proba, y, labels=np.arange(nC))
    Ps, Ys = whole_session_aggregate(proba, y, dev)
    verS = verification_metrics(Ps, Ys, labels=np.arange(nC)) if len(Ys) else {"eer": float("nan")}
    return cls["accuracy"], ver["eer"], ver["auc"], verS["eer"]


def main():
    require_gate("stage04")
    root = resolve_root()
    out = stage_dir("18_fusion")
    if DEV_SUBSET is not None:
        print("!" * 70 + f"\n!!! DEV_SUBSET={DEV_SUBSET}: PILOT RESULTS ONLY, NOT FINAL. "
              f"Set DEV_SUBSET=None for paper results.\n" + "!" * 70)

    cov = coverage_report(root, out)
    print("\n".join(cov))
    print(f"[stage20] building fusion table (bin={FU.FUSION['bin_s']}s) DEV_SUBSET={DEV_SUBSET} ...")
    table = FU.build_fusion_table(root, dev_subset=DEV_SUBSET)
    parts = split_records(table)
    print(f"[stage20] aligned bins={len(table)} split-assigned={len(parts)} seeds={FUSION_SEEDS}")

    rows, ledger, report = [], [], list(cov) + [""]
    if DEV_SUBSET is not None:
        report.insert(0, f"*** PILOT (DEV_SUBSET={DEV_SUBSET}) — NOT FINAL RESULTS ***")

    for mods in COMBOS:
        asm = assemble(table, mods, parts)
        if asm is None:
            report.append(f"  {'+'.join(mods):7s}: no co-occurring bins"); continue
        splits, nC = asm
        ntr, nte = len(splits["train"]["y"]), len(splits["test"]["y"])
        if ntr < 10 or nte < 5 or nC < 2:
            report.append(f"  {'+'.join(mods):7s}: too few samples (train={ntr} test={nte} users={nC})")
            continue
        yva, yte, dev_te = splits["val"]["y"], splits["test"]["y"], splits["test"]["dev"]

        early_eer, late_eer, early_acc, late_acc = [], [], [], []
        last_weights = None
        robustness = {}
        ytr = splits["train"]["y"]
        # column ranges of each modality block in the concat (for missing-modality test)
        col = {}; off = 0
        for m in mods:
            d = splits["train"]["Xm"][m].shape[1]; col[m] = (off, off + d); off += d
        for sd in FUSION_SEEDS:
            # per-modality models (for LATE fusion)
            valp, testp = {}, {}
            for m in mods:
                mdl, mean, sdv, vp = fit_block(splits["train"]["Xm"][m], splits["val"]["Xm"][m],
                                               ytr, yva, nC, sd)
                valp[m] = vp; testp[m] = apply_block(mdl, mean, sdv, splits["test"]["Xm"][m])
            # EARLY = concat blocks -> one model
            Xtr = np.concatenate([splits["train"]["Xm"][m] for m in mods], axis=1)
            Xva = np.concatenate([splits["val"]["Xm"][m] for m in mods], axis=1)
            Xte = np.concatenate([splits["test"]["Xm"][m] for m in mods], axis=1)
            me, mean_e, sd_e, _ = fit_block(Xtr, Xva, ytr, yva, nC, sd)
            pe = apply_block(me, mean_e, sd_e, Xte)
            a, e, _, _ = ev(pe, yte, dev_te, nC)
            early_acc.append(a); early_eer.append(e)
            # LATE = val-calibrated weighted score fusion
            if len(mods) > 1:
                w = calibrate_weights([valp[m] for m in mods], yva, nC)
                last_weights = dict(zip(mods, [round(x, 2) for x in w]))
                pl = sum(wi * testp[m] for wi, m in zip(w, mods))
                a2, e2, _, _ = ev(pl, yte, dev_te, nC)
                late_acc.append(a2); late_eer.append(e2)
            # missing-modality robustness (tri-modal early model, reused; last seed)
            if mods == ("K", "S", "M") and sd == FUSION_SEEDS[-1]:
                Xte_s = (Xte - mean_e) / sd_e
                for drop in mods:
                    Xd = Xte_s.copy()
                    Xd[:, col[drop][0]:col[drop][1]] = 0.0     # mean-impute the missing block
                    pdrop = predict_proba(me, Xd)
                    robustness[f"drop_{drop}"] = round(
                        verification_metrics(pdrop, yte, labels=np.arange(nC))["eer"], 4)

        em, esd, eh = ci95(early_eer); am, asd, ah = ci95(early_acc)
        rows.append(dict(combo="+".join(mods), fusion="early", n_users=nC, n_test=nte,
                         acc_mean=round(am, 4), eer_mean=round(em, 4), eer_ci95=round(eh, 4),
                         weights=""))
        ledger.append(dict(stage="20_fusion", method="early", setting="+".join(mods), seed="mean",
                           task="A+B", accuracy=am, eer=em, extra=f"eer_ci95={eh:.4f}"))
        line = f"  {'+'.join(mods):7s} EARLY acc={am:.4f} EER={em:.4f}+/-{eh:.4f} (users={nC}, test={nte})"
        if late_eer:
            lm, lsd, lh = ci95(late_eer); lam, _, _ = ci95(late_acc)
            rows.append(dict(combo="+".join(mods), fusion="late", n_users=nC, n_test=nte,
                             acc_mean=round(lam, 4), eer_mean=round(lm, 4), eer_ci95=round(lh, 4),
                             weights=str(last_weights)))
            ledger.append(dict(stage="20_fusion", method="late", setting="+".join(mods), seed="mean",
                               task="A+B", accuracy=lam, eer=lm, extra=f"eer_ci95={lh:.4f};w={last_weights}"))
            line += f"\n          LATE  acc={lam:.4f} EER={lm:.4f}+/-{lh:.4f}  weights(val-calibrated)={last_weights}"
        if robustness:
            line += f"\n          missing-modality robustness (tri-modal early EER): {robustness}"
        print(line); report.append(line)

    if rows:
        with open(out / "ablation_fusion.csv", "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
        append_results(ledger)
    txt = ("=" * 70 + "\nSTAGE 20 - MULTIMODAL FUSION + ABLATION (early vs late, multi-seed)\n"
           + "=" * 70 + "\n" + "\n".join(report) + "\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage20_report.txt").write_text(txt, "utf-8")
    print(f"[stage20] wrote {out}")


if __name__ == "__main__":
    main()
