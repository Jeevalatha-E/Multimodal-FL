"""
STAGE 06 — Centralized BehaviorAuthNet (roadmap PHASE 9-10)

Trains the manuscript MLP centrally and proves it learns before any FL. This is the
no-privacy performance ceiling for the neural model.

Needs: numpy, torch.  Colab: !python stage06_centralized_net.py
Outputs -> results/04_centralized/{stage06_report.txt, history.csv, confusion.npy} + summary_all.csv
"""
from __future__ import annotations

import csv
import numpy as np

from ppflfm_common import get_feature_dirs, stage_dir, append_results, MODEL, TRAIN, SEED
from ppflfm_eval import classification_metrics, verification_metrics, summarize
from ppflfm_ml import load_windows, set_seed, BehaviorAuthNet, train_model, predict_proba


def main():
    _, processed, _ = get_feature_dirs()
    out = stage_dir("04_centralized")
    d = load_windows(processed)
    set_seed(SEED)
    print(f"[stage06] train={d['X_train'].shape} classes={d['n_classes']}")

    model = BehaviorAuthNet(d["in_dim"], d["n_classes"], MODEL["hidden1"],
                            MODEL["hidden2"], MODEL["dropout"], norm=MODEL["norm"])
    hist = train_model(model, d, TRAIN, verbose=True)

    proba = predict_proba(model, d["X_test"])
    yp = proba.argmax(1)
    cls = classification_metrics(d["y_test"], yp, n_classes=d["n_classes"])
    ver = verification_metrics(proba, d["y_test"], labels=np.arange(d["n_classes"]))
    line = summarize("BehaviorAuthNet", cls, ver)

    with open(out / "history.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(hist[0].keys())); w.writeheader(); w.writerows(hist)
    np.save(out / "confusion.npy", np.array(cls["confusion_matrix"]))
    append_results([dict(stage="06_centralized", method="BehaviorAuthNet", setting="centralized",
                         seed=SEED, task="A+B", accuracy=cls["accuracy"], macro_f1=cls["macro_f1"],
                         balanced_accuracy=cls["balanced_accuracy"], eer=ver["eer"], auc=ver["auc"],
                         macro_eer=ver["macro_eer"], tar_at_far_1pct=ver.get("tar_at_far_1pct", ""))])

    txt = ("=" * 70 + "\nSTAGE 06 - CENTRALIZED BehaviorAuthNet\n" + "=" * 70 +
           f"\nepochs run={len(hist)} best_val_acc={max(h['val_acc'] for h in hist):.4f}\n\n" +
           line + "\n" +
           f"chance={1.0/d['n_classes']:.4f}\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage06_report.txt").write_text(txt, "utf-8")
    print(f"[stage06] wrote {out}")


if __name__ == "__main__":
    main()
