"""
STAGE 14 — Ablation study (roadmap PHASE 22)

Toggles the PPFLFM components on a fixed moderate/strong non-IID setting and reports
test accuracy + verification (single-shot W=1 and continuous W=20).

Measured here:
  A5 FedAvg vs A4/A1 Entropy aggregation
  A9 single-shot (W=1) vs A10 continuous (W=20)
  A3 secure aggregation (metrics identical to plain; overhead noted)
Cross-referenced (different training regime, see their stages):
  A2 -DP  -> Stage 12 (DP-SGD sweep)
Not applicable (keystroke-only build):
  A6 single modality / A7 early fusion / A8 late fusion

Needs: numpy, torch.  Colab: !python stage14_ablation.py
Outputs -> results/12_ablation/{stage14_report.txt, ablation.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import numpy as np

from ppflfm_common import (get_feature_dirs, stage_dir, append_results, require_gate,
                           MODEL, FL, TRAIN, SEED)
from ppflfm_eval import (classification_metrics, verification_metrics, whole_session_aggregate)
from ppflfm_ml import load_windows, run_federated, predict_proba

ALPHA = 0.5   # fixed moderate/strong heterogeneity for the ablation


def eval_mode(proba, y, dev, mode, nC):
    if mode == "single":                       # A9: per-window single-shot
        P, Y = proba, y
    else:                                       # A10: robust whole-session decision
        P, Y = whole_session_aggregate(proba, y, dev)
    cls = classification_metrics(Y, P.argmax(1), n_classes=nC)
    ver = verification_metrics(P, Y, labels=np.arange(nC))
    return cls, ver, len(Y)


def main():
    require_gate("stage13")            # fail-fast: Stage 14 must not run if Stage 13 failed
    _, processed, _ = get_feature_dirs()
    out = stage_dir("12_ablation")
    d = load_windows(processed)
    cfg = {**FL, **TRAIN}
    dev = np.asarray(d["device_test"]); yte = d["y_test"]; nC = d["n_classes"]

    variants = [("A5_FedAvg", "fedavg"), ("A1_Entropy(full)", "entropy")]
    rows, ledger, report = [], [], []
    report.append(f"fixed non-IID alpha={ALPHA}; A6/A7/A8 N/A (keystroke-only); A2 -> Stage 12")
    for name, agg in variants:
        model, _, _ = run_federated(d, cfg, alpha=ALPHA, aggregation=agg, seed=SEED, norm=MODEL["norm"])
        proba = predict_proba(model, d["X_test"])
        for mode, tag in (("single", "A9_single"), ("session", "A10_continuous")):
            cls, ver, ndec = eval_mode(proba, yte, dev, mode, nC)
            row = dict(variant=name, aggregation=agg, mode=tag, n_decisions=ndec,
                       accuracy=cls["accuracy"], macro_f1=cls["macro_f1"], eer=ver["eer"], auc=ver["auc"])
            rows.append(row)
            ledger.append(dict(stage="14_ablation", method=name, setting=f"{tag}_a{ALPHA}",
                               seed=SEED, task="A+B", accuracy=cls["accuracy"], macro_f1=cls["macro_f1"],
                               balanced_accuracy=cls["balanced_accuracy"], eer=ver["eer"], auc=ver["auc"],
                               macro_eer=ver["macro_eer"]))
            msg = f"  {name:18s} {tag:15s} decisions={ndec:5d} acc={cls['accuracy']:.4f} EER={ver['eer']:.4f}"
            print(msg); report.append(msg)

    report.append("  A3_SecureAgg: metrics identical to plain FedAvg (see Stage 11), "
                  "adds (K-1) pairwise masks/client overhead.")
    with open(out / "ablation.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    append_results(ledger)
    txt = "=" * 70 + "\nSTAGE 14 - ABLATION STUDY\n" + "=" * 70 + "\n" + "\n".join(report) + "\n" + "=" * 70
    print("\n" + txt)
    (out / "stage14_report.txt").write_text(txt, "utf-8")
    print(f"[stage14] wrote {out}")


if __name__ == "__main__":
    main()
