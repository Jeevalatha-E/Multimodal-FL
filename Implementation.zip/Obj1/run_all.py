"""
run_all.py — one-command FULL-POPULATION pipeline runner (Phase D).

Runs stages 01..21 in order with the FROZEN config, and REFUSES to run a pilot:
  * aborts immediately if DEV_SUBSET is not None
  * aborts if any stage returns non-zero
  * aborts if any stage prints a "PILOT" banner or "users=8"-style subset marker
Then runs verify_final.py for the consistency audit.

Colab:
    !pip install opacus            # for the independent DP reference check
    !python run_all.py

This removes the #1 recurring mistake (mixing DEV_SUBSET=8 pilot cells with full-run
cells). Motion/fusion/multimodal (19-21) stream the ~25 MB inertial files and are slow
— expect this to take a while on the full 117-user population.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
import ppflfm_common as C  # noqa: E402

STAGES = [
    "stage01_inspection.py", "stage02_validation.py", "stage03_split.py",
    "stage04_features.py", "stage05_baselines.py", "stage06_centralized_net.py",
    "stage07_local_training.py", "stage08_fedavg.py", "stage09_non_iid.py",
    "stage10_entropy_aggregation.py", "stage11_secure_aggregation.py",
    "stage12_differential_privacy.py", "stage13_continuous_authentication.py",
    "stage14_ablation.py", "stage15_statistics.py", "stage16_norm_ablation.py",
    "stage17_lodo_eval.py", "stage18_swipe_features.py", "stage19_motion_features.py",
    "stage20_fusion.py", "stage21_multimodal_ppflfm.py",
]
TESTS = ["test_verification_metrics.py", "test_dp_accountant.py"]


def die(msg):
    print("\n" + "X" * 70 + f"\nABORT: {msg}\n" + "X" * 70)
    sys.exit(1)


def main():
    if C.DEV_SUBSET is not None:
        die(f"DEV_SUBSET={C.DEV_SUBSET!r}. Set DEV_SUBSET=None in ppflfm_common.py for the "
            f"final full-population run.")
    import os
    if os.environ.get("PPFLFM_SMOKE") == "1":
        die("PPFLFM_SMOKE=1 is set. Unset it for the final run.")
    try:
        import opacus  # noqa: F401
        print("[run_all] opacus present -> DP reference check will run.")
    except Exception:
        print("[run_all] WARNING: opacus not installed; DP reference check will be skipped. "
              "Run `!pip install opacus` for the independent audit.")

    print(f"[run_all] FULL run, DEV_SUBSET=None, {len(STAGES)} stages. This is slow.\n")
    for s in STAGES:
        print(f"\n{'='*70}\n[run_all] RUNNING {s}\n{'='*70}")
        r = subprocess.run([sys.executable, s], cwd=REPO, capture_output=True, text=True)
        out = r.stdout + r.stderr
        print(out[-4000:] if len(out) > 4000 else out)   # tail of each stage
        if r.returncode != 0:
            die(f"{s} failed (exit {r.returncode}).")
        if "PILOT" in out or "NOT FINAL" in out:
            die(f"{s} produced PILOT output — subset run detected.")
    for t in TESTS:
        print(f"\n[run_all] TEST {t}")
        r = subprocess.run([sys.executable, t], cwd=REPO, capture_output=True, text=True)
        print(r.stdout[-2000:])
        if r.returncode != 0:
            die(f"{t} failed.")

    print(f"\n{'='*70}\n[run_all] all stages done -> running consistency audit\n{'='*70}")
    subprocess.run([sys.executable, "verify_final.py"], cwd=REPO)


if __name__ == "__main__":
    main()
