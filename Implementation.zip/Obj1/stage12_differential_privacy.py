"""
STAGE 12 — Differential privacy sweep (roadmap PHASE 18-19)

DP-SGD with per-example gradient clipping + Gaussian noise, over a sigma sweep. For
each sigma the actual (epsilon, delta) is computed with an RDP accountant (NOT claimed
from sigma alone). Produces the privacy-utility trade-off (epsilon vs accuracy / EER).

Privacy unit: one training window (sample-level DP). Model uses NO BatchNorm/Dropout
(required for correct per-example gradients / DP guarantees).

Needs: numpy, torch.  Colab: !python stage12_differential_privacy.py
Outputs -> results/10_dp/{stage12_report.txt, dp_sweep.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import numpy as np

from ppflfm_common import get_feature_dirs, stage_dir, append_results, DP, SEED
from ppflfm_eval import classification_metrics, verification_metrics
from ppflfm_ml import load_windows, dp_train, predict_proba, dp_epsilon


def main():
    _, processed, _ = get_feature_dirs()
    out = stage_dir("10_dp")
    d = load_windows(processed)
    cfg = {"lr": DP["lr"], "batch_size": DP["batch_size"], "epochs": DP["epochs"]}
    delta = DP["delta"]
    seeds = list(range(1, DP.get("n_seeds", 3) + 1))
    print(f"[stage12] DP-SGD clip={DP['clip_norm']} delta={delta} batch={DP['batch_size']} "
          f"epochs={DP['epochs']} seeds={seeds} sigmas={DP['noise_multipliers']}")

    rows, ledger, report = [], [], []
    for sigma in DP["noise_multipliers"]:
        accs, eers, f1s = [], [], []
        steps = q = None
        for sd in seeds:
            # DP-SGD uses LayerNorm (frozen arch; BatchNorm breaks per-example gradients/DP).
            model, steps, q = dp_train(d, cfg, clip=DP["clip_norm"], sigma=sigma, seed=sd, norm="layer")
            proba = predict_proba(model, d["X_test"])
            cls = classification_metrics(d["y_test"], proba.argmax(1), n_classes=d["n_classes"])
            ver = verification_metrics(proba, d["y_test"], labels=np.arange(d["n_classes"]))
            accs.append(cls["accuracy"]); eers.append(ver["eer"]); f1s.append(cls["macro_f1"])
        eps = dp_epsilon(q, sigma, steps, delta) if sigma > 0 else float("inf")
        eps_str = "inf" if not np.isfinite(eps) else f"{eps:.3f}"
        am, asd = float(np.mean(accs)), float(np.std(accs, ddof=1) if len(accs) > 1 else 0.0)
        em, esd = float(np.mean(eers)), float(np.std(eers, ddof=1) if len(eers) > 1 else 0.0)
        rows.append(dict(sigma=sigma, epsilon=eps_str, steps=steps, q=round(q, 5), n_seeds=len(seeds),
                         acc_mean=round(am, 4), acc_sd=round(asd, 4),
                         eer_mean=round(em, 4), eer_sd=round(esd, 4)))
        ledger.append(dict(stage="12_dp", method="DP-SGD", setting=f"sigma={sigma}", seed="mean",
                           task="A+B", accuracy=am, macro_f1=float(np.mean(f1s)),
                           eer=em, extra=f"epsilon={eps_str};acc_sd={asd:.4f};eer_sd={esd:.4f}"))
        msg = (f"  sigma={sigma:<5} eps={eps_str:>8}  acc={am:.4f}+/-{asd:.4f}  "
               f"EER={em:.4f}+/-{esd:.4f}  (n={len(seeds)})")
        print(msg); report.append(msg)

    with open(out / "dp_sweep.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    append_results(ledger)
    txt = ("=" * 70 + "\nSTAGE 12 - DIFFERENTIAL PRIVACY (DP-SGD) SWEEP\n" + "=" * 70 +
           f"\nprivacy unit: ONE WINDOW (sample-level DP) — NOT user-level. delta={delta}."
           f"\nepsilon via RDP accountant (conservative integer-order upper bound; depends on"
           f"\n(n,q,steps); audited by test_dp_accountant.py). Stage 21 uses the SAME accountant;"
           f"\nany epsilon difference there is only because the fused dataset has different n/q/steps."
           f"\nIncreasing sigma reduces the privacy budget epsilon; the utility response is"
           f"\nNON-MONOTONIC in the evaluated range (noise can act as mild regularization).\n\n" +
           "\n".join(report) +
           "\n\nNOTE: report as sample-level DP. Do NOT claim user-level privacy without a"
           "\nuser-level clipping/accounting redesign.\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage12_report.txt").write_text(txt, "utf-8")
    print(f"[stage12] wrote {out}")


if __name__ == "__main__":
    main()
