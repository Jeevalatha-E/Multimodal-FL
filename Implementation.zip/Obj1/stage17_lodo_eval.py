"""
STAGE 17 — Cross-device LODO evaluation  (review #17)

Trains the SAME frozen model/protocol on each leave-one-device-out fold (train on 2
devices, test on the held-out device) and reports identification + verification metrics,
including a robust whole-session decision per test stream. This is CROSS-DEVICE
KNOWN-USER generalization (users seen via other devices), NOT unseen-user.

Uses the Stage-04 LODO npz files (keystroke_windows_lodo_<device>.npz).

Colab: !python stage17_lodo_eval.py   (needs numpy, torch; run stages 01-04 first)
Outputs -> results/15_lodo/{stage17_report.txt, lodo_eval.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

from ppflfm_common import get_feature_dirs, stage_dir, append_results, require_gate, MODEL, TRAIN, SEED
from ppflfm_eval import (classification_metrics, verification_metrics, whole_session_aggregate)
from ppflfm_ml import set_seed, BehaviorAuthNet, train_model, predict_proba

DEVICES = ["Desktop", "Phone", "Tablet"]


def load_lodo(processed, held):
    d = np.load(processed / f"keystroke_windows_lodo_{held}.npz", allow_pickle=True)
    labels = np.unique(np.concatenate([d["y_train"], d["y_val"], d["y_test"]]))
    enc = {c: i for i, c in enumerate(labels)}
    rem = lambda y: np.array([enc[c] for c in y], dtype=np.int64)  # noqa: E731
    return {
        "X_train": d["X_train"].astype(np.float32), "y_train": rem(d["y_train"]),
        "X_val": d["X_val"].astype(np.float32), "y_val": rem(d["y_val"]),
        "X_test": d["X_test"].astype(np.float32), "y_test": rem(d["y_test"]),
        "device_test": d["device_test"],
        "n_classes": len(labels), "in_dim": d["X_train"].shape[1],
    }


def main():
    require_gate("stage04")
    _, processed, _ = get_feature_dirs()
    out = stage_dir("15_lodo")

    rows, ledger, report = [], [], []
    for held in DEVICES:
        f = processed / f"keystroke_windows_lodo_{held}.npz"
        if not f.exists():
            report.append(f"  held-out={held}: npz missing (run stage04)"); continue
        d = load_lodo(processed, held)
        set_seed(SEED)
        model = BehaviorAuthNet(d["in_dim"], d["n_classes"], MODEL["hidden1"], MODEL["hidden2"],
                                MODEL["dropout"], norm=MODEL["norm"])
        train_model(model, d, TRAIN)
        proba = predict_proba(model, d["X_test"])
        yte = d["y_test"]; dev = np.asarray(d["device_test"])
        cls = classification_metrics(yte, proba.argmax(1), n_classes=d["n_classes"])
        ver = verification_metrics(proba, yte, labels=np.arange(d["n_classes"]))
        # whole-session (one decision per test stream)
        Ps, Ys = whole_session_aggregate(proba, yte, dev)
        clsS = classification_metrics(Ys, Ps.argmax(1), n_classes=d["n_classes"])
        verS = verification_metrics(Ps, Ys, labels=np.arange(d["n_classes"]))

        rows.append(dict(held_out=held, test_windows=len(yte),
                         win_acc=cls["accuracy"], win_macro_f1=cls["macro_f1"],
                         win_eer=ver["eer"], win_auc=ver["auc"],
                         win_tar_at_far1=ver.get("tar_at_far_1pct", ""),
                         sess_decisions=len(Ys), sess_acc=clsS["accuracy"],
                         sess_macro_f1=clsS["macro_f1"], sess_eer=verS["eer"],
                         sess_auc=verS["auc"], sess_tar_at_far1=verS.get("tar_at_far_1pct", "")))
        ledger.append(dict(stage="17_lodo", method="BehaviorAuthNet", setting=f"held_out={held}",
                           seed=SEED, task="A+B", accuracy=cls["accuracy"], macro_f1=cls["macro_f1"],
                           balanced_accuracy=cls["balanced_accuracy"], eer=ver["eer"], auc=ver["auc"],
                           macro_eer=ver["macro_eer"], extra=f"sess_eer={verS['eer']:.4f}"))
        msg = (f"  held-out={held:8s} window: acc={cls['accuracy']:.4f} EER={ver['eer']:.4f} "
               f"AUC={ver['auc']:.4f} | session: acc={clsS['accuracy']:.4f} EER={verS['eer']:.4f}")
        print(msg); report.append(msg)

    if rows:
        with open(out / "lodo_eval.csv", "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
        append_results(ledger)
        # cross-device summary (mean +/- SD over the 3 held-out folds)
        we = np.array([r["win_eer"] for r in rows]); se = np.array([r["sess_eer"] for r in rows])
        report.append("")
        report.append(f"  cross-device mean EER  window={we.mean():.4f}+/-{we.std(ddof=1) if len(we)>1 else 0:.4f}"
                      f"  session={se.mean():.4f}+/-{se.std(ddof=1) if len(se)>1 else 0:.4f}")
        report.append("  NOTE: cross-device is HARDER than within-device (E1); report honestly.")
    txt = ("=" * 70 + "\nSTAGE 17 - CROSS-DEVICE LODO EVALUATION (known-user)\n" + "=" * 70 +
           "\ntrain on 2 devices, test on the held-out device (users seen via other devices)\n\n" +
           "\n".join(report) + "\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage17_report.txt").write_text(txt, "utf-8")
    print(f"[stage17] wrote {out}")


if __name__ == "__main__":
    main()
