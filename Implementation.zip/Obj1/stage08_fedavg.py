"""
STAGE 08 — Basic FedAvg, IID (roadmap PHASE 12-13)

FedAvg over K IID clients. Records per-round val curves and final test metrics.
Convergence is tracked over the full `rounds` (not stopped arbitrarily at 10).

Needs: numpy, torch.  Colab: !python stage08_fedavg.py
Outputs -> results/06_fedavg/{stage08_report.txt, fedavg_iid.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import numpy as np

from ppflfm_common import get_feature_dirs, stage_dir, append_results, MODEL, FL, TRAIN, SEED
from ppflfm_eval import classification_metrics, verification_metrics, summarize
from ppflfm_ml import load_windows, run_federated, predict_proba


def main():
    _, processed, _ = get_feature_dirs()
    out = stage_dir("06_fedavg")
    d = load_windows(processed)
    cfg = {**FL, **TRAIN}
    print(f"[stage08] FedAvg IID  K={FL['n_clients']} rounds={FL['rounds']} "
          f"local_epochs={FL['local_epochs']}")

    model, hist, sizes = run_federated(d, cfg, alpha=None, aggregation="fedavg", seed=SEED,
                                       norm=MODEL["norm"])
    proba = predict_proba(model, d["X_test"])
    cls = classification_metrics(d["y_test"], proba.argmax(1), n_classes=d["n_classes"])
    ver = verification_metrics(proba, d["y_test"], labels=np.arange(d["n_classes"]))

    with open(out / "fedavg_iid.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(hist[0].keys())); w.writeheader(); w.writerows(hist)
    append_results([dict(stage="08_fedavg", method="FedAvg", setting="IID",
                         seed=SEED, task="A+B", accuracy=cls["accuracy"], macro_f1=cls["macro_f1"],
                         balanced_accuracy=cls["balanced_accuracy"], eer=ver["eer"], auc=ver["auc"],
                         macro_eer=ver["macro_eer"])])

    line = summarize("FedAvg(IID)", cls, ver)
    txt = ("=" * 70 + "\nSTAGE 08 - FedAvg (IID)\n" + "=" * 70 +
           f"\nclient sizes={sizes}\nfinal round val_acc={hist[-1]['val_acc']:.4f}\n\n" +
           line + "\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage08_report.txt").write_text(txt, "utf-8")
    print(f"[stage08] wrote {out}")


if __name__ == "__main__":
    main()
