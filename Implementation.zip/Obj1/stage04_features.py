"""
STAGE 04 — Leakage-safe feature extraction, DUAL protocol  (the data milestone)

Consumes Stage-03 segment manifests, windows each partition, and PROVES leakage
safety programmatically (review point #3) instead of assuming it. Builds:
  Protocol A (temporal)     -> keystroke_windows.npz            (used by stages 05-15)
  Protocol B (cross-device) -> keystroke_windows_lodo_<dev>.npz (3 LODO folds)

Guarantees enforced here:
  * windows built strictly INSIDE one partition (segments carry event ranges)
  * leakage auditor: 0 event-range overlaps across partitions, 0 duplicate feature
    rows across partitions, and (LODO) test source files disjoint from train
  * scaler fit on TRAIN ONLY (audited), applied to val/test
  * rich per-window metadata saved (user, device, file, partition, event range, times)
  * experiment_manifest.json with dataset hash + every parameter

Colab: !python stage04_features.py   (needs numpy; run stage03 first)
Outputs -> data/processed/*.npz, results/02_features/{windows_meta_*.csv,
           audit_*.json, stage04_report.txt}, results/experiment_manifest.json
"""
from __future__ import annotations

import csv
import json
import platform
import sys
from datetime import datetime
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

from ppflfm_common import (resolve_root, get_out_dirs, get_feature_dirs, stage_dir,
                           build_kps_cache, window_segments, leakage_audit, require_gate,
                           write_gate, DEVICES, SPLIT, FEATURES, FEATURE_NAMES, N_FEATURES,
                           SEED, dataset_hash)

DEVICE_CODE = {"Desktop": 0, "Phone": 1, "Tablet": 2}


def fit_apply_scaler(X, parts):
    """Standardize with a scaler fit on TRAIN rows ONLY (returns Xs, mean, scale)."""
    parts = np.asarray(parts)
    tr = parts == "train"
    assert tr.sum() > 0, "no train windows to fit scaler"
    mean = X[tr].mean(axis=0)
    scale = X[tr].std(axis=0)
    scale = np.where(scale < FEATURES["std_eps"], FEATURES["std_eps"], scale)
    return (X - mean) / scale, mean, scale, tr


def split_arrays(Xs, y, dev, parts):
    parts = np.asarray(parts)
    out = {}
    for name in ("train", "val", "test"):
        m = parts == name
        out[name] = (Xs[m], y[m], dev[m])
    return out


def _save_features(processed, tag, split, X, y, dev):
    """Write a split's feature table as parquet (pandas) or CSV fallback."""
    cols = FEATURE_NAMES + ["user", "device_code"]
    try:
        import pandas as pd
        df = pd.DataFrame(np.column_stack([X, y, dev]), columns=cols)
        df.to_parquet(processed / f"features{tag}_{split}.parquet", index=False)
    except Exception:
        with open(processed / f"features{tag}_{split}.csv", "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh); w.writerow(cols)
            for xi, yi, di in zip(X, y, dev):
                w.writerow([*[f"{v:.6g}" for v in xi], int(yi), int(di)])


def process(segments, cache, tag, protocol, processed, report_dir):
    W, S, MAXF = FEATURES["window"], FEATURES["stride"], FEATURES["max_flight_ms"]
    X, y, dev, parts, meta, hashes = window_segments(segments, cache, W, S, MAXF)
    audit = leakage_audit(segments, parts, hashes, protocol, meta=meta)

    Xs, mean, scale, tr_mask = fit_apply_scaler(X, parts)
    audit["checks"]["scaler_fit_on_train_only"] = bool(tr_mask.sum() > 0 and
                                                        (np.asarray(parts) == "train").sum() == tr_mask.sum())
    audit["checks"]["no_nan_inf"] = bool(np.isfinite(Xs).all())
    audit["pass"] = all(audit["checks"].values())

    sp = split_arrays(Xs, y, dev, parts)
    np.savez_compressed(
        processed / f"keystroke_windows{tag}.npz",
        X_train=sp["train"][0], y_train=sp["train"][1], device_train=sp["train"][2],
        X_val=sp["val"][0], y_val=sp["val"][1], device_val=sp["val"][2],
        X_test=sp["test"][0], y_test=sp["test"][1], device_test=sp["test"][2],
        feature_names=np.asarray(FEATURE_NAMES), scaler_mean=mean, scaler_scale=scale,
    )

    # per-split feature tables (parquet/csv) + per-split metadata CSVs
    parts_arr = np.asarray(parts)
    split_name = {"train": "train", "val": "validation", "test": "test"}
    for part in ("train", "val", "test"):
        Xp, yp, dp = sp[part]
        _save_features(processed, tag, split_name[part], Xp, yp, dp)
        mrows = [m for m, p in zip(meta, parts) if p == part]
        if mrows:
            with open(report_dir / f"metadata{tag}_{split_name[part]}.csv", "w", newline="", encoding="utf-8") as fh:
                w = csv.DictWriter(fh, fieldnames=list(mrows[0].keys())); w.writeheader(); w.writerows(mrows)

    # feature_statistics.csv (train-only, pre-scale is meaningful via mean/scale; report scaled train)
    Xtr = sp["train"][0]
    with open(report_dir / f"feature_statistics{tag}.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["feature", "train_mean_raw", "train_std_raw", "scaled_min", "scaled_max"])
        for i, fn in enumerate(FEATURE_NAMES):
            col = Xtr[:, i] if len(Xtr) else np.array([0.0])
            w.writerow([fn, f"{mean[i]:.6g}", f"{scale[i]:.6g}",
                        f"{col.min():.4g}", f"{col.max():.4g}"])

    # class_distribution.csv (windows per user per split)
    with open(report_dir / f"class_distribution{tag}.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["user", "train", "val", "test"])
        users = sorted(set(int(u) for u in y))
        for u in users:
            row = [u]
            for part in ("train", "val", "test"):
                yp = sp[part][1]
                row.append(int((yp == u).sum()))
            w.writerow(row)

    (report_dir / f"leakage_audit{tag}.json").write_text(json.dumps(audit, indent=2), "utf-8")

    counts = {k: int((parts_arr == k).sum()) for k in ("train", "val", "test")}
    return dict(tag=tag, protocol=protocol, counts=counts, audit=audit,
                n_windows=len(y), n_users=int(len(np.unique(y))))


def main():
    require_gate("stage03")                      # refuse to run if Stage 03 failed
    root = resolve_root()
    _, out_dir, splits_dir = get_out_dirs()
    _, processed, report_dir = get_feature_dirs()

    temporal = json.loads((splits_dir / "segments_temporal.json").read_text("utf-8"))
    lodo = json.loads((splits_dir / "segments_lodo.json").read_text("utf-8"))
    dh = dataset_hash(root, DEVICES)
    print(f"[stage04] dataset_hash={dh}  window={FEATURES['window']} features={N_FEATURES}")

    cache = build_kps_cache(root, DEVICES)

    results = []
    # Protocol A -> the default npz used by stages 05-15
    results.append(process(temporal["segments"], cache, "", "temporal", processed, report_dir))
    # Protocol B -> one npz per held-out device
    for held, segs in lodo["folds"].items():
        results.append(process(segs, cache, f"_lodo_{held}", "lodo", processed, report_dir))

    all_pass = all(r["audit"]["pass"] for r in results)

    # experiment manifest (review point #6)
    manifest = {
        "generated": datetime.now().isoformat(timespec="seconds"),
        "dataset": {"name": "BB-MAS", "root": str(root), "dataset_hash": dh, "devices": DEVICES},
        "seed": SEED,
        "split": SPLIT,
        "features": {"names": FEATURE_NAMES, "n": N_FEATURES, **FEATURES},
        "protocols": {r["tag"] or "temporal": {"counts": r["counts"], "n_users": r["n_users"],
                                               "audit_pass": r["audit"]["pass"]} for r in results},
        "versions": {"python": platform.python_version(), "numpy": np.__version__},
        "gate_stage04": all_pass,
    }
    (Path(get_out_dirs()[0]) / "results" / "experiment_manifest.json").write_text(
        json.dumps(manifest, indent=2), "utf-8")

    write_gate("stage04", all_pass, {"dataset_hash": dh,
                                     "audits": {r["tag"] or "temporal": r["audit"]["pass"] for r in results}})

    L = ["=" * 70, "STAGE 04 - LEAKAGE-SAFE FEATURE EXTRACTION (dual protocol)", "=" * 70,
         f"dataset_hash : {dh}", f"features     : {N_FEATURES}  window={FEATURES['window']} "
         f"stride={FEATURES['stride']}", ""]
    for r in results:
        name = r["tag"] or "(temporal)"
        c = r["counts"]
        L.append(f"  {name:16s} windows train/val/test={c['train']}/{c['val']}/{c['test']} "
                 f"users={r['n_users']}  audit={'PASS' if r['audit']['pass'] else 'FAIL'}")
        for k, v in r["audit"]["checks"].items():
            L.append(f"        [{'ok' if v else 'XX'}] {k}")
    L += ["", f"GATE stage04: {'PASS' if all_pass else 'FAIL'}",
          "experiment_manifest.json written.", "=" * 70]
    report = "\n".join(L)
    print("\n" + report)
    (report_dir / "stage04_report.txt").write_text(report, "utf-8")
    if not all_pass:
        sys.exit("[stage04] LEAKAGE AUDIT FAILED — do not proceed to modeling.")
    print(f"[stage04] wrote npz + audits to {processed} / {report_dir}")


if __name__ == "__main__":
    main()
