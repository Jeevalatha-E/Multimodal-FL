"""
ppflfm_common.py — shared code for the PPFLFM_Rebuild Colab stage scripts.

Upload this file to the SAME Colab folder as the stageNN_*.py scripts. Each stage
script does `from ppflfm_common import *` and calls resolve_root() / get_out_dirs().

Contains:
  * CONFIG constants (edit DRIVE_ZIP_PATH / EXTRACT_DIR / LOCAL_ROOT for your setup)
  * Colab bootstrap: mount Drive, extract the BB-MAS zip once, auto-find the root
  * Stage-01 layout inventory helpers
  * Keystroke reconstruction from raw keyboard streams (Stages 02/03)
  * Leakage-safe chronological splitter (Stage 03)
"""
from __future__ import annotations

import csv
import os
import re
import sys
import zipfile
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path

# ===========================================================================
# CONFIG — edit these for your Colab setup
# ===========================================================================
DRIVE_ZIP_PATH = "/content/drive/MyDrive/BB-MAS_Dataset.zip"       # your zip in Drive
EXTRACT_DIR    = "/content/BB-MAS_Dataset"                         # extraction target
LOCAL_ROOT     = "C:/Users/jeeva/Desktop/Dataset/BB-MAS_Dataset"   # used only off-Colab

OUT_BASE       = "PPFLFM_Rebuild_out"     # all stage outputs go under here

DEVICES        = ["Desktop", "Phone", "Tablet"]

# Stage 01: count rows only for files <= this many MB (skips huge inertial CSVs for speed)
INSPECT_MAX_MB = 8

# Stage 03 leakage-safe split parameters
SPLIT = dict(train_frac=0.70, val_frac=0.15, test_frac=0.15,
             guard_events=60, min_keypresses=100, min_partition_events=40)

# FROZEN eligibility criteria — define BEFORE any modeling to avoid selection bias.
# "117 users discovered -> N eligible streams" is reported; ineligible streams are
# excluded with a logged reason, NOT after seeing test performance.
ELIGIBILITY = dict(min_keypresses=100, min_duration_s=120.0)

# Development subset for fast debugging (NOT paper results). None -> all eligible users.
# Set to an int (first N user ids) or a list of user ids to iterate quickly, then set
# back to None and FREEZE config for the production run over all eligible users/streams.
DEV_SUBSET = None

SUSPICIOUS_HOLD_MS = 5000.0

KEYSTROKE_DIR = "Keystroke_Features"
SWIPE_DIR     = "Swipe_Features"
GAIT_DIR      = "Gait_Featuers"           # ships misspelled in BB-MAS

# Stage 04 feature extraction
FEATURES = dict(
    window=50,            # keypresses per window
    stride=50,            # 50 == non-overlapping (strictest anti-leakage)
    max_flight_ms=5000,   # clip flight/latency magnitudes to bound pause outliers
    scaler="standard",    # 'standard' (z-score) fit on TRAIN only
    std_eps=1e-9,         # guard for zero-variance features (like the old min-max 1e-9)
)

SEED = 42

# Stage 06+ neural net (BehaviorAuthNet) and training.
# norm: 'batch' (BatchNorm, manuscript) | 'layer' (LayerNorm, FL-friendlier) | 'none'.
# BatchNorm keeps per-client running stats that FedAvg averages naively -> can hurt
# under heterogeneity; Stage 16 compares the three before finalizing the architecture.
# FROZEN architecture: LayerNorm chosen from Stage-16 evidence (BatchNorm hurts FL
# under heterogeneity: FedAvg EER batch 0.308 vs layer 0.280). ALL model stages read
# MODEL['norm'] so the whole pipeline uses one consistent architecture.
MODEL = dict(hidden1=128, hidden2=64, dropout=0.3, norm="layer")
TRAIN = dict(lr=1e-3, weight_decay=0.0, batch_size=32, epochs=40, patience=8)

# Federated learning (Stages 08+)
FL = dict(
    n_clients=3, rounds=50, local_epochs=3, client_frac=1.0,
    fedprox_mu=0.01,                 # proximal term for FedProx
    dirichlet_alpha=[10.0, 1.0, 0.5, 0.1],   # non-IID severity sweep
)

# Differential privacy (Stage 12) — DP-SGD (SGD optimizer, no BN/dropout)
DP = dict(
    clip_norm=1.0,
    noise_multipliers=[0.0, 0.5, 1.0, 2.0, 4.0],  # sigma sweep (0.25 dropped: eps~1e4, no privacy)
    delta=1e-5,
    lr=0.1,
    batch_size=256,     # larger batch -> smaller sampling rate q -> tighter epsilon
    epochs=15,
    n_seeds=3,          # DP-SGD is slow (per-example clipping); >=3 seeds per sigma
)

# Continuous authentication temporal aggregation (Stage 13)
CONT_AUTH_W = [1, 3, 5, 10, 20]

# Multi-seed statistical validation (Stage 15)
SEEDS = [1, 2, 3, 4, 5]

# Optional fast smoke mode for quick end-to-end checks (set env PPFLFM_SMOKE=1).
# Shrinks epochs/rounds/seeds only; real runs leave it unset.
if os.environ.get("PPFLFM_SMOKE") == "1":
    TRAIN["epochs"] = 5
    FL["rounds"] = 4
    FL["dirichlet_alpha"] = [1.0, 0.1]
    DP["noise_multipliers"] = [0.0, 1.0]
    DP["epochs"] = 2
    DP["n_seeds"] = 1
    CONT_AUTH_W = [1, 5, 20]
    SEEDS = [1, 2]


# ===========================================================================
# OUTPUT DIRS
# ===========================================================================
def get_out_dirs():
    out_base = Path(OUT_BASE)
    out_dir = out_base / "results" / "01_data_validation"
    splits_dir = out_base / "data" / "splits"
    out_dir.mkdir(parents=True, exist_ok=True)
    splits_dir.mkdir(parents=True, exist_ok=True)
    return out_base, out_dir, splits_dir


def get_feature_dirs():
    out_base = Path(OUT_BASE)
    processed = out_base / "data" / "processed"
    feat_report = out_base / "results" / "02_features"
    processed.mkdir(parents=True, exist_ok=True)
    feat_report.mkdir(parents=True, exist_ok=True)
    return out_base, processed, feat_report


def stage_dir(name: str) -> Path:
    d = Path(OUT_BASE) / "results" / name
    d.mkdir(parents=True, exist_ok=True)
    return d


# --- PASS/FAIL gates between stages (review point #11) ---
def write_gate(stage: str, passed: bool, detail: dict | None = None):
    import json
    p = Path(OUT_BASE) / "results" / "gates.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    data = {}
    if p.exists():
        try:
            data = json.loads(p.read_text("utf-8"))
        except Exception:
            data = {}
    data[stage] = {"pass": bool(passed), "detail": detail or {}}
    p.write_text(json.dumps(data, indent=2), "utf-8")
    return passed


def require_gate(stage: str):
    """Abort if an upstream stage's gate is missing or FAILED."""
    import json
    p = Path(OUT_BASE) / "results" / "gates.json"
    if not p.exists():
        raise SystemExit(f"[gate] no gates recorded yet; run {stage} first.")
    data = json.loads(p.read_text("utf-8"))
    if stage not in data:
        raise SystemExit(f"[gate] {stage} has not run; run it before this stage.")
    if not data[stage]["pass"]:
        raise SystemExit(f"[gate] {stage} gate = FAIL; fix it before proceeding. "
                         f"detail={data[stage].get('detail')}")


# Master results ledger — every stage appends rows; Stage 15 aggregates them.
RESULT_FIELDS = ["stage", "method", "setting", "seed", "task",
                 "accuracy", "macro_f1", "balanced_accuracy",
                 "eer", "auc", "macro_eer", "tar_at_far_1pct", "extra"]


def append_results(rows: list):
    import csv
    path = Path(OUT_BASE) / "results" / "summary_all.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    new = not path.exists()
    with open(path, "a", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=RESULT_FIELDS)
        if new:
            w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in RESULT_FIELDS})
    return path


# ===========================================================================
# COLAB BOOTSTRAP
# ===========================================================================
def in_colab() -> bool:
    try:
        import google.colab  # noqa: F401
        return True
    except Exception:
        return False


def find_dataset_root(base: Path):
    """Find the folder that directly holds many numeric user folders (+ Demographics)."""
    base = Path(base)
    candidates = [base] + [p for p in base.rglob("*") if p.is_dir()]
    best, best_score = None, 0
    for d in candidates:
        try:
            numeric = sum(1 for c in d.iterdir() if c.is_dir() and c.name.isdigit())
        except (PermissionError, OSError):
            continue
        score = numeric + (50 if (d / "Demographics.csv").exists() else 0)
        if numeric >= 5 and score > best_score:
            best, best_score = d, score
    return best


def resolve_root() -> Path:
    if in_colab():
        from google.colab import drive  # type: ignore
        if not os.path.ismount("/content/drive"):
            print("[bootstrap] mounting Google Drive ...")
            drive.mount("/content/drive")
        extract_dir = Path(EXTRACT_DIR)
        root = find_dataset_root(extract_dir) if extract_dir.exists() else None
        if root is None:
            zip_path = Path(DRIVE_ZIP_PATH)
            if not zip_path.exists():
                sys.exit(f"[FATAL] zip not found in Drive: {zip_path}\n"
                         f"        Set DRIVE_ZIP_PATH to your BB-MAS zip.")
            print(f"[bootstrap] extracting {zip_path} -> {extract_dir} (one time) ...")
            extract_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(zip_path) as zf:
                zf.extractall(extract_dir)
            root = find_dataset_root(extract_dir)
        if root is None:
            sys.exit(f"[FATAL] could not locate BB-MAS root under {extract_dir}")
        return root
    root = Path(LOCAL_ROOT)
    if not root.is_dir():
        sys.exit(f"[FATAL] LOCAL_ROOT not found: {root}")
    return root


# ===========================================================================
# FAST FILE HELPERS (Stage 01)
# ===========================================================================
def count_lines(path: Path, chunk: int = 1 << 20) -> int:
    if path.stat().st_size == 0:
        return 0
    n = 0
    with open(path, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            n += b.count(b"\n")
    with open(path, "rb") as fh:
        try:
            fh.seek(-1, os.SEEK_END)
            if fh.read(1) != b"\n":
                n += 1
        except OSError:
            n += 1
    return n


def read_header(path: Path) -> list:
    if path.stat().st_size == 0:
        return []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            first = fh.readline().strip()
        return first.split(",") if first else []
    except OSError:
        return []


# ===========================================================================
# LAYOUT PARSING (Stage 01 inventory)
# ===========================================================================
DEVICE_TOKEN = {"Desktop": "Desktop", "HandPhone": "Phone", "PocketPhone": "Phone",
                "HandTablet": "Tablet", "Phone": "Phone", "Tablet": "Tablet"}
_RAW_RE = re.compile(r"^(?P<uid>\d+)_(?P<rest>.+?)\.csv$", re.IGNORECASE)
_FEAT_RE = re.compile(r"^(?P<uid>\d+)_(?P<mid>.+)\.csv$", re.IGNORECASE)


@dataclass
class FileRecord:
    scope: str
    user: int | None
    device: str | None
    modality: str
    path: Path
    size_bytes: int
    empty: bool
    rows: int = -1
    columns: list = field(default_factory=list)


def user_folders(root: Path) -> list:
    return sorted(int(p.name) for p in root.iterdir() if p.is_dir() and p.name.isdigit())


def _classify_raw(uid, fname, path):
    m = _RAW_RE.match(fname)
    if not m:
        return None
    rest = re.sub(r"_\([^)]*\)$", "", m.group("rest"))
    tokens = rest.split("_")
    device = next((DEVICE_TOKEN[t] for t in tokens if t in DEVICE_TOKEN), None)
    modality = "_".join(t for t in tokens if t not in DEVICE_TOKEN) or rest
    if tokens and tokens[0] in ("HandPhone", "PocketPhone", "HandTablet"):
        modality = f"{tokens[0]}_{modality}"
    sz = path.stat().st_size
    return FileRecord("raw", uid, device, modality, path, sz, sz == 0)


def iter_all_files(root: Path):
    for uid in user_folders(root):
        for p in sorted((root / str(uid)).iterdir()):
            if p.is_file() and p.suffix.lower() == ".csv":
                rec = _classify_raw(uid, p.name, p)
                if rec:
                    yield rec
    d = root / KEYSTROKE_DIR
    if d.is_dir():
        for p in sorted(d.iterdir()):
            m = _FEAT_RE.match(p.name)
            if not (p.is_file() and m):
                continue
            parts = m.group("mid").split("_")
            dev = next((t for t in parts if t in ("Desktop", "Phone", "Tablet")), None)
            mod = "_".join(t for t in parts if t not in ("Desktop", "Phone", "Tablet")) or m.group("mid")
            sz = p.stat().st_size
            yield FileRecord("keystroke", int(m.group("uid")), dev, mod, p, sz, sz == 0)
    d = root / SWIPE_DIR
    if d.is_dir():
        for p in sorted(d.iterdir()):
            m = _FEAT_RE.match(p.name)
            if not (p.is_file() and m):
                continue
            dev = m.group("mid")
            sz = p.stat().st_size
            yield FileRecord("swipe", int(m.group("uid")),
                             dev if dev in ("Phone", "Tablet") else None, "Swipe", p, sz, sz == 0)
    d = root / GAIT_DIR
    if d.is_dir():
        for act in sorted(d.iterdir()):
            if not act.is_dir():
                continue
            activity = act.name.replace("_Features", "")
            for p in sorted(act.iterdir()):
                m = _FEAT_RE.match(p.name)
                if not (p.is_file() and m):
                    continue
                dev = next((t for t in ("Phone", "Tablet") if t in p.name), None)
                sz = p.stat().st_size
                yield FileRecord("gait", int(m.group("uid")), dev, activity, p, sz, sz == 0)


# ===========================================================================
# KEYSTROKE RECONSTRUCTION (Stages 02/03)
# ===========================================================================
DEVICE_KEYBOARD_GLOB = {
    "Desktop": "*_Desktop_Keyboard.csv",
    "Phone": "*_HandPhone_Keyboard_*.csv",
    "Tablet": "*_HandTablet_Keyboard_*.csv",
}
_TS_FORMATS = ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S")


def parse_ts(s: str):
    s = s.strip()
    for fmt in _TS_FORMATS:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    try:
        date_part, time_part = s.split(" ", 1)
        y, mo, d = (int(x) for x in date_part.split("-"))
        time_part = time_part.replace(",", ".")
        if time_part.count(":") == 3:
            hh, mm, ss, ms = time_part.split(":")
            micro = int(ms) * 1000
        else:
            hms, _, frac = time_part.partition(".")
            hh, mm, ss = hms.split(":")
            micro = int((frac + "000000")[:6]) if frac else 0
        return datetime(y, mo, d, int(hh), int(mm), int(ss), micro)
    except Exception:
        return None


def resolve_keyboard_path(user_dir: Path, device: str):
    pat = DEVICE_KEYBOARD_GLOB.get(device)
    if not pat:
        return None
    matches = sorted(user_dir.glob(pat))
    return matches[0] if matches else None


@dataclass
class KeyPress:
    key: str
    t_down: datetime
    t_up: datetime
    hold_ms: float


@dataclass
class ReconResult:
    keypresses: list
    n_raw_events: int
    n_orphan_down: int
    n_orphan_up: int
    n_bad_time: int
    n_nonmonotonic: int
    n_negative_hold: int
    n_suspicious_hold: int


def load_raw_events(path: Path):
    """Parse a raw keyboard CSV with the csv module (commas/quotes are real keys)."""
    events = []
    n_bad = n_nonmono = 0
    prev = None
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as fh:
        reader = csv.reader(fh)
        try:
            next(reader)
        except StopIteration:
            return events, n_bad, n_nonmono
        for parts in reader:
            if len(parts) != 4:
                n_bad += 1
                continue
            key, direction, tstr = parts[1], parts[2], parts[3]
            ts = parse_ts(tstr)
            if ts is None:
                n_bad += 1
                continue
            try:
                dd = int(direction)
            except ValueError:
                n_bad += 1
                continue
            if prev is not None and ts < prev:
                n_nonmono += 1
            prev = ts
            events.append((key, dd, ts))
    return events, n_bad, n_nonmono


def reconstruct(path: Path, suspicious_hold_ms: float = SUSPICIOUS_HOLD_MS) -> ReconResult:
    events, n_bad, n_nonmono = load_raw_events(path)
    pending = {}
    kps = []
    n_orphan_up = n_neg = n_susp = 0
    for key, dd, ts in events:
        if dd == 0:
            pending.setdefault(key, []).append(ts)
        elif dd == 1:
            stack = pending.get(key)
            if stack:
                t_down = stack.pop()
                hold = (ts - t_down).total_seconds() * 1000.0
                if hold < 0:
                    n_neg += 1
                    continue
                if hold > suspicious_hold_ms:
                    n_susp += 1
                kps.append(KeyPress(key, t_down, ts, hold))
            else:
                n_orphan_up += 1
    n_orphan_down = sum(len(v) for v in pending.values())
    kps.sort(key=lambda k: k.t_down)
    return ReconResult(kps, len(events), n_orphan_down, n_orphan_up,
                       n_bad, n_nonmono, n_neg, n_susp)


# ===========================================================================
# LEAKAGE-SAFE SPLIT (Stage 03)
# ===========================================================================
@dataclass
class StreamSplit:
    user: int
    device: str
    n_keypresses: int
    guard_events: int
    usable: bool
    reason: str
    train: tuple
    val: tuple
    test: tuple

    def to_json(self):
        d = asdict(self)
        d["train"], d["val"], d["test"] = list(self.train), list(self.val), list(self.test)
        return d


def make_stream_split(user, device, n, train_frac, val_frac, test_frac,
                      guard_events, min_keypresses, min_partition_events=40):
    empty = (0, 0)
    if n < min_keypresses:
        return StreamSplit(user, device, n, guard_events, False,
                           f"below_min_keypresses({n}<{min_keypresses})", empty, empty, empty)
    n_tr = int(train_frac * n)
    n_va = int(val_frac * n)
    tr = (0, n_tr)
    va = (n_tr + guard_events, n_tr + guard_events + n_va)
    te = (va[1] + guard_events, n)
    sizes = {"train": tr[1] - tr[0], "val": va[1] - va[0], "test": te[1] - te[0]}
    ok = tr[1] <= va[0] and va[1] <= te[0] and te[0] < te[1]
    if ok and all(sz >= min_partition_events for sz in sizes.values()):
        return StreamSplit(user, device, n, guard_events, True, "", tr, va, te)
    return StreamSplit(user, device, n, guard_events, False,
                       f"partition_too_small(sizes={sizes})", tr, va, te)


def assert_leakage_safe(s: StreamSplit):
    if not s.usable:
        return
    (a0, a1), (b0, b1), (c0, c1) = s.train, s.val, s.test
    assert b0 - a1 >= s.guard_events, f"train/val guard u{s.user} {s.device}"
    assert c0 - b1 >= s.guard_events, f"val/test guard u{s.user} {s.device}"
    assert a0 < a1 <= b0 < b1 <= c0 < c1 <= s.n_keypresses, f"ranges bad u{s.user} {s.device}"


# ===========================================================================
# FEATURE EXTRACTION (Stage 04)
# ===========================================================================
# 15 features per window, each defined below. All timing features are in ms.
#   Dwell (hold) time  : how long a key is held (down->up)          -> mean/std/median/p95
#   Flight/latency (4 standard digraph definitions between key i and i+1):
#     DD = down(i+1) - down(i)   (press-to-press; typing speed)     -> mean/std
#     UD = down(i+1) - up(i)     (release-to-press; inter-key gap,  -> mean/std
#                                 can be negative when keys overlap)
#     DU = up(i+1)   - down(i)                                       -> mean/std
#     UU = up(i+1)   - up(i)                                         -> mean/std
#   typing_rate    : keys per second across the window               -> 1
#   backspace_ratio: fraction of keys that are BACKSPACE/DELETE      -> 1
#   special_ratio  : fraction of keys that are named (non-character) -> 1
FEATURE_NAMES = [
    "hold_mean", "hold_std", "hold_median", "hold_p95",
    "dd_mean", "dd_std", "ud_mean", "ud_std",
    "du_mean", "du_std", "uu_mean", "uu_std",
    "typing_rate", "backspace_ratio", "special_ratio",
]
N_FEATURES = len(FEATURE_NAMES)


def _clip(x, lo, hi):
    return lo if x < lo else (hi if x > hi else x)


def _mean(xs):
    return sum(xs) / len(xs) if xs else 0.0


def _std(xs, m):
    return (sum((x - m) ** 2 for x in xs) / len(xs)) ** 0.5 if xs else 0.0


def _median(xs):
    if not xs:
        return 0.0
    s = sorted(xs)
    n = len(s)
    mid = n // 2
    return s[mid] if n % 2 else 0.5 * (s[mid - 1] + s[mid])


def _p95(xs):
    if not xs:
        return 0.0
    s = sorted(xs)
    return s[int(0.95 * (len(s) - 1))]


def is_special_key(key: str) -> bool:
    """Named/non-character keys (SPACE, SHIFT, BACKSPACE, LCTRL, ENTER, ...)."""
    return len(key) != 1


def is_backspace(key: str) -> bool:
    return key.upper() in ("BACKSPACE", "DELETE")


def window_feature_vector(win, max_flight_ms: float) -> list:
    """Compute the 15-D feature vector for a window (list of KeyPress, len W)."""
    holds = [k.hold_ms for k in win]
    dd, ud, du, uu = [], [], [], []
    for i in range(len(win) - 1):
        a, b = win[i], win[i + 1]
        dd.append(_clip((b.t_down - a.t_down).total_seconds() * 1000, -max_flight_ms, max_flight_ms))
        ud.append(_clip((b.t_down - a.t_up).total_seconds() * 1000, -max_flight_ms, max_flight_ms))
        du.append(_clip((b.t_up - a.t_down).total_seconds() * 1000, -max_flight_ms, max_flight_ms))
        uu.append(_clip((b.t_up - a.t_up).total_seconds() * 1000, -max_flight_ms, max_flight_ms))

    hold_m = _mean(holds)
    span_s = (win[-1].t_down - win[0].t_down).total_seconds()
    typing_rate = (len(win) - 1) / span_s if span_s > 0 else 0.0
    backspace_ratio = sum(1 for k in win if is_backspace(k.key)) / len(win)
    special_ratio = sum(1 for k in win if is_special_key(k.key)) / len(win)

    return [
        hold_m, _std(holds, hold_m), _median(holds), _p95(holds),
        _mean(dd), _std(dd, _mean(dd)), _mean(ud), _std(ud, _mean(ud)),
        _mean(du), _std(du, _mean(du)), _mean(uu), _std(uu, _mean(uu)),
        typing_rate, backspace_ratio, special_ratio,
    ]


def iter_windows(keypresses, start: int, end: int, window: int, stride: int):
    """Yield (win_index, slice_of_keypresses) fully inside [start, end)."""
    idx = 0
    pos = start
    while pos + window <= end:
        yield idx, keypresses[pos:pos + window]
        idx += 1
        pos += stride


# ===========================================================================
# STAGE 03/04 PIPELINE — dual-protocol segments, metadata windowing, auditor
# ===========================================================================
# BB-MAS has ONE session per user x device (verified: single day, <~3 min max gap),
# so a "session-disjoint within device" split is impossible. Two protocols:
#   A (temporal)     : within-stream chronological train/val/test (continuous auth).
#   B (cross-device) : leave-one-device-out — train on 2 devices, test on the 3rd
#                      (the only honest "unseen condition"; framed as cross-device).
#
# A "segment" is a contiguous keypress-index range of one stream assigned to a
# partition. Stage 04 windows segments and an auditor PROVES (not assumes) leakage
# safety from the window metadata.

import hashlib as _hashlib


def dataset_hash(root: Path, devices=None) -> str:
    """Stable fingerprint of the raw keyboard files (name+size), independent of split."""
    devices = devices or ["Desktop", "Phone", "Tablet"]
    items = []
    for uid in user_folders(root):
        for dev in devices:
            p = resolve_keyboard_path(root / str(uid), dev)
            if p is not None:
                items.append((f"{uid}|{dev}|{p.name}", p.stat().st_size))
    items.sort()
    h = _hashlib.sha256()
    for name, size in items:
        h.update(f"{name}:{size}\n".encode())
    return h.hexdigest()[:16]


def _dev_subset_uids(all_uids, dev_subset):
    if dev_subset is None:
        return set(all_uids)
    if isinstance(dev_subset, int):
        return set(all_uids[:dev_subset])
    return set(dev_subset)


def build_kps_cache(root: Path, devices, susp_ms=SUSPICIOUS_HOLD_MS, dev_subset=DEV_SUBSET) -> dict:
    """Reconstruct each present user x device stream ONCE. Key = (uid, device).

    dev_subset (config DEV_SUBSET) restricts to a small user set for fast debugging;
    None => all users (production).
    """
    allu = user_folders(root)
    keep = _dev_subset_uids(allu, dev_subset)
    cache = {}
    for uid in allu:
        if uid not in keep:
            continue
        for dev in devices:
            p = resolve_keyboard_path(root / str(uid), dev)
            if p is None:
                continue
            cache[(uid, dev)] = (p.name, reconstruct(p, susp_ms).keypresses)
    return cache


def stream_eligible(kps, elig=ELIGIBILITY):
    """FROZEN eligibility rule (define before evaluation). Returns (ok, reason)."""
    if len(kps) < elig["min_keypresses"]:
        return False, f"min_keypresses({len(kps)}<{elig['min_keypresses']})"
    if len(kps) >= 2:
        dur = (kps[-1].t_down - kps[0].t_down).total_seconds()
        if dur < elig["min_duration_s"]:
            return False, f"min_duration({dur:.0f}s<{elig['min_duration_s']:.0f}s)"
    return True, ""


def eligibility_report(cache, elig=ELIGIBILITY):
    """Per-stream eligibility under the FROZEN rule. Returns (rows, eligible_keys)."""
    rows, eligible = [], set()
    for (uid, dev), (fname, kps) in sorted(cache.items()):
        ok, reason = stream_eligible(kps, elig)
        rows.append(dict(user=uid, device=dev, n_keypresses=len(kps), eligible=int(ok), reason=reason))
        if ok:
            eligible.add((uid, dev))
    return rows, eligible


def build_temporal_segments(cache: dict, sp: dict) -> list:
    """Protocol A: 3 segments (train/val/test) per ELIGIBLE, usable stream."""
    segs = []
    for (uid, dev), (fname, kps) in cache.items():
        if not stream_eligible(kps)[0]:
            continue
        s = make_stream_split(uid, dev, len(kps), sp["train_frac"], sp["val_frac"],
                              sp["test_frac"], sp["guard_events"], sp["min_keypresses"],
                              sp["min_partition_events"])
        if not s.usable:
            continue
        for part, (a, b) in (("train", s.train), ("val", s.val), ("test", s.test)):
            segs.append(dict(user=uid, device=dev, file=fname, partition=part, e0=a, e1=b))
    return segs


def build_lodo_folds(cache: dict, sp: dict, devices, train_frac=0.85) -> dict:
    """Protocol B: one fold per held-out device. Train/val come from the other two
    devices (temporal split with guard); test = the whole held-out-device stream."""
    folds = {}
    for held in devices:
        segs = []
        for (uid, dev), (fname, kps) in cache.items():
            n = len(kps)
            if not stream_eligible(kps)[0]:
                continue
            if dev == held:
                segs.append(dict(user=uid, device=dev, file=fname, partition="test", e0=0, e1=n))
            else:
                n_tr = int(train_frac * n)
                g = sp["guard_events"]
                if n_tr < sp["min_partition_events"] or (n - n_tr - g) < sp["min_partition_events"]:
                    continue
                segs.append(dict(user=uid, device=dev, file=fname, partition="train", e0=0, e1=n_tr))
                segs.append(dict(user=uid, device=dev, file=fname, partition="val", e0=n_tr + g, e1=n))
        folds[held] = segs
    return folds


def window_segments(segments: list, cache: dict, W: int, stride: int, max_flight_ms: float):
    """Window each segment; return (X, y, dev_code, parts, meta, row_hashes).

    meta rows carry full provenance so the auditor can prove leakage safety.
    """
    import numpy as _np
    dev_code = {"Desktop": 0, "Phone": 1, "Tablet": 2}
    X, y, dev, parts, meta, hashes = [], [], [], [], [], []
    wid = 0
    for seg in segments:
        key = (seg["user"], seg["device"])
        if key not in cache:
            continue
        fname, kps = cache[key]
        for wi, win in iter_windows(kps, seg["e0"], seg["e1"], W, stride):
            e_start = seg["e0"] + wi * stride          # absolute event range in the stream
            e_end = e_start + W
            fv = window_feature_vector(win, max_flight_ms)
            X.append(fv); y.append(seg["user"]); dev.append(dev_code[seg["device"]])
            parts.append(seg["partition"])
            hashes.append(hash(tuple(round(v, 6) for v in fv)))
            meta.append(dict(window_id=wid, user=seg["user"], device=seg["device"],
                             file=fname, partition=seg["partition"],
                             event_start=e_start, event_end=e_end,
                             t_start=win[0].t_down.isoformat(), t_end=win[-1].t_down.isoformat()))
            wid += 1
    return (_np.asarray(X, dtype=_np.float64), _np.asarray(y, dtype=_np.int64),
            _np.asarray(dev, dtype=_np.int64), parts, meta, hashes)


def _seg_event_ranges(segments):
    """Map (user,device) -> list of (partition, e0, e1) for overlap checking."""
    d = {}
    for s in segments:
        d.setdefault((s["user"], s["device"]), []).append((s["partition"], s["e0"], s["e1"]))
    return d


def leakage_audit(segments: list, parts: list, hashes: list, protocol: str, meta=None) -> dict:
    """PROVE leakage safety from segment ranges + window metadata (review point #3)."""
    checks = {}

    # 1) event-range disjointness across partitions within the same (user,device)
    overlaps = 0
    for key, ranges in _seg_event_ranges(segments).items():
        for i in range(len(ranges)):
            for j in range(i + 1, len(ranges)):
                (pi, a0, a1), (pj, b0, b1) = ranges[i], ranges[j]
                if pi != pj and not (a1 <= b0 or b1 <= a0):
                    overlaps += 1
    checks["no_event_range_overlap_across_partitions"] = (overlaps == 0)

    # 2) no duplicate feature-window across partitions (hash collision across parts)
    from collections import defaultdict
    part_of_hash = defaultdict(set)
    for h, p in zip(hashes, parts):
        part_of_hash[h].add(p)
    dup = sum(1 for h, ps in part_of_hash.items() if len(ps) > 1)
    checks["no_duplicate_feature_rows_across_partitions"] = (dup == 0)

    # 3) cross-device: test source files disjoint from train/val source files
    if protocol == "lodo":
        test_files = {s["file"] for s in segments if s["partition"] == "test"}
        trval_files = {s["file"] for s in segments if s["partition"] in ("train", "val")}
        checks["test_source_files_disjoint_from_train"] = (test_files.isdisjoint(trval_files))

    ts_overlaps = 0
    id_shared = 0
    if meta:
        # 4) TIMESTAMP-range disjointness across partitions within the same stream
        from datetime import datetime as _dt
        by_stream = defaultdict(list)
        for m in meta:
            by_stream[(m["user"], m["device"])].append(
                (m["partition"], _dt.fromisoformat(m["t_start"]), _dt.fromisoformat(m["t_end"])))
        for key, wins in by_stream.items():
            # compare partition time spans (min t_start .. max t_end per partition)
            spans = {}
            for p, ts, te in wins:
                s0, s1 = spans.get(p, (ts, te))
                spans[p] = (min(s0, ts), max(s1, te))
            ps = list(spans)
            for i in range(len(ps)):
                for j in range(i + 1, len(ps)):
                    (a0, a1), (b0, b1) = spans[ps[i]], spans[ps[j]]
                    if not (a1 <= b0 or b1 <= a0):
                        ts_overlaps += 1
        checks["no_timestamp_overlap_across_partitions"] = (ts_overlaps == 0)

        # 5) window_ids are globally unique -> none shared across partitions
        id_to_parts = defaultdict(set)
        for m in meta:
            id_to_parts[m["window_id"]].add(m["partition"])
        id_shared = sum(1 for w, ps in id_to_parts.items() if len(ps) > 1)
        checks["no_window_id_shared_across_partitions"] = (id_shared == 0)

    return {"checks": checks, "n_event_overlaps": overlaps, "n_duplicate_windows": dup,
            "n_timestamp_overlaps": ts_overlaps, "n_shared_window_ids": id_shared,
            "pass": all(checks.values())}
