"""
STAGE 22 — Figures for the paper.

Generates publication charts from whatever stage outputs exist (each figure is guarded,
so a partial run still yields the available figures):
  training_curves.png    centralized val accuracy + train/val loss vs epoch (stage 06)
  fl_convergence.png     FedAvg val accuracy / loss vs round (stage 08)
  roc_curve.png          verification ROC (TAR vs FAR) with EER point (trains the frozen net)
  confusion_matrix.png   117-class row-normalized confusion (stage 06)
  baseline_comparison.png accuracy + EER per baseline (stage 05)
  dp_tradeoff.png        privacy-utility: epsilon vs EER (stage 12)
  continuous_auth.png    EER / AUC vs temporal window W (stage 13)
  noniid.png             EER vs Dirichlet alpha, FedAvg vs FedProx (stage 09)
  entropy_vs_fedavg.png  EER by heterogeneity, FedAvg vs entropy (stage 10)

Run:  python stage22_figures.py     (needs matplotlib, numpy; torch only for the ROC fig)
Outputs -> results/figures/*.png
"""
from __future__ import annotations

import csv
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
from ppflfm_common import OUT_BASE  # noqa: E402

RES = Path(OUT_BASE) / "results"
FIG = RES / "figures"
FIG.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"figure.dpi": 130, "font.size": 10, "axes.grid": True,
                     "grid.alpha": 0.3, "savefig.bbox": "tight"})
made = []


def rd(p):
    p = Path(p)
    if not p.exists():
        return None
    with open(p, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def fnum(x, default=np.nan):
    try:
        return float(x)
    except (ValueError, TypeError):
        return default


def save(fig, name):
    fig.savefig(FIG / name)
    plt.close(fig)
    made.append(name)
    print(f"  [ok] {name}")


def training_curves():
    rows = rd(RES / "04_centralized" / "history.csv")
    if not rows:
        return
    ep = [int(r["epoch"]) for r in rows]
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    ax[0].plot(ep, [fnum(r["train_loss"]) for r in rows], label="train loss")
    ax[0].plot(ep, [fnum(r["val_loss"]) for r in rows], label="val loss")
    ax[0].set(xlabel="epoch", ylabel="cross-entropy loss", title="Centralized training loss")
    ax[0].legend()
    ax[1].plot(ep, [fnum(r["val_acc"]) for r in rows], color="tab:green")
    ax[1].set(xlabel="epoch", ylabel="validation accuracy", title="Centralized validation accuracy")
    save(fig, "training_curves.png")


def fl_convergence():
    rows = rd(RES / "06_fedavg" / "fedavg_iid.csv")
    if not rows:
        return
    rnd = [int(r["round"]) for r in rows]
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    ax[0].plot(rnd, [fnum(r["val_loss"]) for r in rows], color="tab:red")
    ax[0].set(xlabel="round", ylabel="val loss", title="FedAvg convergence (loss)")
    ax[1].plot(rnd, [fnum(r["val_acc"]) for r in rows], color="tab:blue")
    ax[1].set(xlabel="round", ylabel="val accuracy", title="FedAvg convergence (accuracy)")
    save(fig, "fl_convergence.png")


def confusion_matrix():
    p = RES / "04_centralized" / "confusion.npy"
    if not p.exists():
        return
    cm = np.load(p).astype(float)
    rn = cm / np.clip(cm.sum(1, keepdims=True), 1, None)   # row-normalize (recall)
    fig, ax = plt.subplots(figsize=(5.5, 4.6))
    im = ax.imshow(rn, cmap="viridis", vmin=0, vmax=1)
    ax.set(xlabel="predicted user", ylabel="true user",
           title=f"Confusion matrix ({cm.shape[0]} users, row-normalized)")
    fig.colorbar(im, ax=ax, fraction=0.046, label="fraction")
    save(fig, "confusion_matrix.png")


def roc_curve():
    proc_dir = Path(OUT_BASE) / "data" / "processed"
    if not (proc_dir / "keystroke_windows.npz").exists():
        return
    try:
        from ppflfm_ml import load_windows, set_seed, BehaviorAuthNet, train_model, predict_proba
        from ppflfm_common import MODEL, TRAIN, SEED
        from ppflfm_eval import _roc_eer_auc
    except Exception as e:
        print(f"  [skip] roc_curve ({e})"); return
    d = load_windows(proc_dir)
    set_seed(SEED)
    m = BehaviorAuthNet(d["in_dim"], d["n_classes"], MODEL["hidden1"], MODEL["hidden2"],
                        MODEL["dropout"], norm=MODEL["norm"])
    train_model(m, d, TRAIN)
    proba = predict_proba(m, d["X_test"])
    y = d["y_test"]; K = d["n_classes"]
    gen = proba[np.arange(len(y)), y]
    mask = np.ones_like(proba, bool); mask[np.arange(len(y)), y] = False
    imp = proba[mask]
    eer, auc, roc = _roc_eer_auc(gen, imp)
    fig, ax = plt.subplots(figsize=(5, 4.4))
    ax.plot(roc["far"], roc["tar"], color="tab:purple", label=f"ROC (AUC={auc:.3f})")
    ax.plot([0, 1], [0, 1], "k--", alpha=0.4)
    ax.scatter([eer], [1 - eer], color="red", zorder=5, label=f"EER={eer:.3f}")
    ax.set(xlabel="False Accept Rate", ylabel="True Accept Rate",
           title="Verification ROC (keystroke, centralized)")
    ax.legend(loc="lower right")
    save(fig, "roc_curve.png")


def baseline_comparison():
    rows = rd(RES / "03_baselines" / "baselines.csv")
    if not rows:
        return
    names = [r["method"] for r in rows]
    acc = [fnum(r.get("accuracy")) for r in rows]
    eer = [fnum(r.get("eer")) for r in rows]
    x = np.arange(len(names))
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].bar(x, acc, color="tab:blue")
    ax[0].axhline(1 / 117, color="k", ls="--", alpha=0.6, label="chance (1/117)")
    ax[0].set(xticks=x, ylabel="accuracy", title="Baseline identification accuracy")
    ax[0].set_xticklabels(names, rotation=30, ha="right"); ax[0].legend()
    ev = [(n, e) for n, e in zip(names, eer) if np.isfinite(e)]
    if ev:
        xn = np.arange(len(ev))
        ax[1].bar(xn, [e for _, e in ev], color="tab:orange")
        ax[1].axhline(0.5, color="k", ls="--", alpha=0.6, label="EER=0.5 (chance)")
        ax[1].set(xticks=xn, ylabel="EER", title="Baseline verification EER")
        ax[1].set_xticklabels([n for n, _ in ev], rotation=30, ha="right"); ax[1].legend()
    save(fig, "baseline_comparison.png")


def dp_tradeoff():
    rows = rd(RES / "10_dp" / "dp_sweep.csv")
    if not rows:
        return
    pts = [(fnum(r["epsilon"]), fnum(r.get("eer_mean", r.get("eer"))), fnum(r["sigma"]))
           for r in rows if r["epsilon"] not in ("inf", "")]
    pts = [p for p in pts if np.isfinite(p[0]) and np.isfinite(p[1])]
    if not pts:
        return
    pts.sort()
    eps = [p[0] for p in pts]; eer = [p[1] for p in pts]; sig = [p[2] for p in pts]
    fig, ax = plt.subplots(figsize=(5.4, 4))
    ax.plot(eps, eer, "o-", color="tab:red")
    for e, y, s in zip(eps, eer, sig):
        ax.annotate(f"σ={s}", (e, y), textcoords="offset points", xytext=(5, 5), fontsize=8)
    ax.set(xscale="log", xlabel="privacy budget ε (log)", ylabel="EER",
           title="Privacy–utility trade-off (DP-SGD, sample-level)")
    save(fig, "dp_tradeoff.png")


def continuous_auth():
    rows = rd(RES / "11_continuous" / "continuous_auth.csv")
    if not rows:
        return
    rows = [r for r in rows if str(r.get("W")).isdigit()]
    if not rows:
        return
    W = [int(r["W"]) for r in rows]
    fig, ax = plt.subplots(figsize=(5.6, 4))
    ax.plot(W, [fnum(r["eer"]) for r in rows], "o-", label="EER", color="tab:red")
    ax.plot(W, [fnum(r["auc"]) for r in rows], "s-", label="AUC", color="tab:green")
    ax.set(xlabel="temporal window W (windows aggregated)", ylabel="metric",
           title="Continuous authentication vs aggregation length")
    ax.legend()
    save(fig, "continuous_auth.png")


def noniid():
    rows = rd(RES / "07_non_iid" / "non_iid.csv")
    if not rows:
        return
    alphas = sorted({fnum(r["alpha"]) for r in rows}, reverse=True)
    fig, ax = plt.subplots(figsize=(5.6, 4))
    for method, col in (("FedAvg", "tab:blue"), ("FedProx", "tab:orange")):
        ys = []
        for a in alphas:
            m = [r for r in rows if fnum(r["alpha"]) == a and r["method"] == method]
            ys.append(fnum(m[0]["eer"]) if m else np.nan)
        ax.plot([str(a) for a in alphas], ys, "o-", label=method, color=col)
    ax.set(xlabel="Dirichlet α (← more heterogeneous)", ylabel="EER",
           title="Non-IID robustness: FedAvg vs FedProx")
    ax.legend()
    save(fig, "noniid.png")


def entropy_vs_fedavg():
    rows = rd(RES / "08_entropy" / "entropy_vs_fedavg.csv")
    if not rows:
        return
    labels = [r["setting"] for r in rows]
    fa = [fnum(r["fedavg_eer"]) for r in rows]
    en = [fnum(r["entropy_eer"]) for r in rows]
    x = np.arange(len(labels)); w = 0.38
    fig, ax = plt.subplots(figsize=(6.4, 4))
    ax.bar(x - w / 2, fa, w, label="FedAvg", color="tab:blue")
    ax.bar(x + w / 2, en, w, label="Entropy", color="tab:orange")
    ax.set(xticks=x, ylabel="EER", title="Proposed entropy aggregation vs FedAvg")
    ax.set_xticklabels(labels, rotation=20, ha="right"); ax.legend()
    save(fig, "entropy_vs_fedavg.png")


def _ci95(vals):
    v = np.asarray([x for x in vals if np.isfinite(x)], float)
    if len(v) == 0:
        return np.nan, 0.0
    m = float(v.mean()); h = 1.96 * v.std(ddof=1) / np.sqrt(len(v)) if len(v) > 1 else 0.0
    return m, h


def multiseed_ci():
    rows = rd(RES / "13_statistics" / "multiseed.csv")
    if not rows:
        return
    groups = {}
    for r in rows:
        groups.setdefault(r["group"], []).append(fnum(r["eer"]))
    names = list(groups); means, errs = [], []
    for n in names:
        m, h = _ci95(groups[n]); means.append(m); errs.append(h)
    x = np.arange(len(names))
    fig, ax = plt.subplots(figsize=(max(6, len(names) * 0.8), 4))
    ax.bar(x, means, yerr=errs, capsize=4, color="tab:teal")
    ax.set(xticks=x, ylabel="EER (mean ± 95% CI)", title="Multi-seed EER by method")
    ax.set_xticklabels(names, rotation=25, ha="right")
    save(fig, "multiseed_ci.png")


def fusion_ablation():
    rows = rd(RES / "18_fusion" / "ablation_fusion.csv")
    if not rows:
        return
    combos = sorted({r["combo"] for r in rows}, key=lambda c: (len(c), c))
    fig, ax = plt.subplots(figsize=(7, 4)); w = 0.38
    for i, fusion in enumerate(("early", "late")):
        ys, es = [], []
        for c in combos:
            m = [r for r in rows if r["combo"] == c and r["fusion"] == fusion]
            ys.append(fnum(m[0].get("eer_mean")) if m else np.nan)
            es.append(fnum(m[0].get("eer_ci95", m[0].get("eer_ci", 0))) if m else 0)
        ax.bar(np.arange(len(combos)) + (i - 0.5) * w, ys, w, yerr=es, capsize=3,
               label=fusion, color=["tab:blue", "tab:orange"][i])
    ax.set(xticks=np.arange(len(combos)), ylabel="EER", title="Multimodal ablation: early vs late fusion")
    ax.set_xticklabels(combos, rotation=20, ha="right"); ax.legend()
    save(fig, "fusion_ablation.png")


def mm_ppflfm():
    rows = rd(RES / "19_mm_ppflfm" / "mm_fl.csv")
    if not rows:
        return
    labels = [f"{r['method']}\n{r['fusion']}" for r in rows]
    eer = [fnum(r.get("eer_mean")) for r in rows]
    err = [fnum(r.get("eer_ci", 0)) for r in rows]
    x = np.arange(len(labels))
    fig, ax = plt.subplots(figsize=(max(7, len(labels) * 0.9), 4))
    ax.bar(x, eer, yerr=err, capsize=4, color="tab:purple")
    ax.set(xticks=x, ylabel="EER (mean ± 95% CI)", title="Multimodal PPFLFM (early vs late)")
    ax.set_xticklabels(labels, rotation=0, fontsize=8)
    save(fig, "mm_ppflfm.png")


def mm_dp():
    rows = rd(RES / "19_mm_ppflfm" / "mm_dp.csv")
    if not rows:
        return
    fig, ax = plt.subplots(figsize=(5.6, 4))
    for fusion, col in (("early", "tab:blue"), ("late", "tab:orange")):
        pts = [(fnum(r["epsilon"]), fnum(r.get("eer_mean"))) for r in rows
               if r.get("fusion") == fusion and r["epsilon"] not in ("inf", "")]
        pts = [p for p in pts if np.isfinite(p[0]) and np.isfinite(p[1])]
        if pts:
            pts.sort()
            ax.plot([p[0] for p in pts], [p[1] for p in pts], "o-", label=fusion, color=col)
    ax.set(xscale="log", xlabel="privacy budget ε (log)", ylabel="EER",
           title="Multimodal privacy–utility (DP-SGD)")
    ax.legend()
    save(fig, "mm_dp_tradeoff.png")


def main():
    print(f"[stage22] writing figures to {FIG}")
    for f in (training_curves, fl_convergence, roc_curve, confusion_matrix,
              baseline_comparison, dp_tradeoff, continuous_auth, noniid, entropy_vs_fedavg,
              multiseed_ci, fusion_ablation, mm_ppflfm, mm_dp):
        try:
            f()
        except Exception as e:
            print(f"  [skip] {f.__name__} ({e})")
    print(f"[stage22] {len(made)} figures written: {', '.join(made) or 'none'}")


if __name__ == "__main__":
    main()
