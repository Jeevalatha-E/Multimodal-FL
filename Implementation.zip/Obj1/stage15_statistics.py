"""
STAGE 15 — Statistical validation, tables & reproducibility (roadmap PHASE 24-25)

1) Multi-seed comparison of the main methods (Centralized MLP, FedAvg-IID,
   Entropy-IID): reports mean +/- SD and 95% CI across SEEDS.
2) Auto-generates LaTeX tables from results/summary_all.csv (no hand-typed numbers).
3) Writes a reproducibility manifest (configs, seeds, library versions).

Needs: numpy, torch (scipy optional for exact t CI).  Colab: !python stage15_statistics.py
Outputs -> results/13_statistics/{stage15_report.txt, multiseed.csv},
           results/tables/*.tex, results/reproducibility.json
"""
from __future__ import annotations

import csv
import hashlib
import json
import platform
from datetime import datetime
from pathlib import Path

import numpy as np

from ppflfm_common import (get_feature_dirs, stage_dir, SEEDS, FEATURES, MODEL, TRAIN,
                           FL, DP, OUT_BASE)
from ppflfm_eval import classification_metrics, verification_metrics
from ppflfm_ml import (load_windows, set_seed, BehaviorAuthNet, train_model,
                       run_federated, predict_proba)


def ci95(vals):
    vals = np.asarray(vals, dtype=float)
    n = len(vals)
    m, sd = float(vals.mean()), float(vals.std(ddof=1)) if n > 1 else 0.0
    if n > 1:
        try:
            from scipy.stats import t
            h = t.ppf(0.975, n - 1) * sd / np.sqrt(n)
        except Exception:
            h = 1.96 * sd / np.sqrt(n)
    else:
        h = 0.0
    return m, sd, float(h)


def eval_model(model, d):
    proba = predict_proba(model, d["X_test"])
    cls = classification_metrics(d["y_test"], proba.argmax(1), n_classes=d["n_classes"])
    ver = verification_metrics(proba, d["y_test"], labels=np.arange(d["n_classes"]))
    return cls["accuracy"], cls["macro_f1"], ver["eer"], ver["auc"]


def write_manifest(res, tables):
    """Write reproducibility.json (dataset hash + env + code hash). Called early so the
    manifest exists even if the heavy multi-seed loop is interrupted, then re-written
    with the generated tables at the end."""
    import torch
    try:
        import sklearn
        skl = sklearn.__version__
    except Exception:
        skl = "n/a"
    h = hashlib.sha256()
    for p in sorted(Path(__file__).resolve().parent.glob("*.py")):
        h.update(p.name.encode()); h.update(p.read_bytes())
    dataset_hash = None
    mp = Path(res) / "experiment_manifest.json"
    if mp.exists():
        try:
            dataset_hash = json.loads(mp.read_text("utf-8"))["dataset"]["dataset_hash"]
        except Exception:
            pass
    manifest = {
        "generated": datetime.now().isoformat(timespec="seconds"),
        "dataset_hash": dataset_hash, "code_hash": h.hexdigest()[:16],
        "frozen_norm": MODEL["norm"],
        "env": {"python": platform.python_version(), "numpy": np.__version__,
                "torch": torch.__version__, "sklearn": skl,
                "cuda_available": bool(torch.cuda.is_available()),
                "device": "cuda" if torch.cuda.is_available() else "cpu"},
        "seeds": SEEDS,
        "config": {"FEATURES": FEATURES, "MODEL": MODEL, "TRAIN": TRAIN, "FL": FL, "DP": DP},
        "tables": tables,
    }
    (Path(res) / "reproducibility.json").write_text(json.dumps(manifest, indent=2), "utf-8")


def main():
    _, processed, _ = get_feature_dirs()
    out = stage_dir("13_statistics")
    tables = stage_dir("tables")
    write_manifest(Path(OUT_BASE) / "results", [])   # write manifest FIRST so it always exists
    d = load_windows(processed)

    # ---- 1) multi-seed over conditions x methods ----
    # 5-seed statistical comparison. To stay tractable at full population, the multi-seed
    # sweep uses IID + the STRONGEST non-IID level only (the full alpha sweep is already
    # reported single-seed in Stage 09). Methods: FedAvg, FedProx, Entropy + Centralized.
    cfg_fl = {**FL, **TRAIN}
    conditions = [("IID", None), (f"a{FL['dirichlet_alpha'][-1]}", FL["dirichlet_alpha"][-1])]
    fl_methods = [("FedAvg", "fedavg", 0.0), ("FedProx", "fedavg", FL["fedprox_mu"]),
                  ("Entropy", "entropy", 0.0)]
    acc, eer = {}, {}
    per_seed_rows = []
    print(f"[stage15] multi-seed over {SEEDS}: Centralized + {len(conditions)} conditions "
          f"x {len(fl_methods)} FL methods")
    for s in SEEDS:
        set_seed(s)
        mc = BehaviorAuthNet(d["in_dim"], d["n_classes"], norm=MODEL["norm"])
        train_model(mc, d, TRAIN)
        a, f, e, u = eval_model(mc, d)
        acc.setdefault("Centralized", []).append(a); eer.setdefault("Centralized", []).append(e)
        per_seed_rows.append(dict(seed=s, group="Centralized", accuracy=a, macro_f1=f, eer=e, auc=u))
        for clab, alpha in conditions:
            for mlab, agg, mu in fl_methods:
                model, _, _ = run_federated(d, cfg_fl, alpha=alpha, aggregation=agg, mu=mu, seed=s,
                                            norm=MODEL["norm"])
                a, f, e, u = eval_model(model, d)
                g = f"{mlab}-{clab}"
                acc.setdefault(g, []).append(a); eer.setdefault(g, []).append(e)
                per_seed_rows.append(dict(seed=s, group=g, accuracy=a, macro_f1=f, eer=e, auc=u))
        print(f"  seed {s} done")

    with open(out / "multiseed.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(per_seed_rows[0].keys()))
        w.writeheader(); w.writerows(per_seed_rows)

    report = ["=" * 70, "STAGE 15 - STATISTICAL VALIDATION (multi-seed)", "=" * 70,
              f"seeds = {SEEDS}", ""]
    for g in acc:
        am, asd, ah = ci95(acc[g])
        em, esd, eh = ci95(eer[g])
        report.append(f"  {g:16s} acc={am:.4f}+/-{asd:.4f} (95%CI +/-{ah:.4f})  "
                      f"EER={em:.4f}+/-{esd:.4f} (95%CI +/-{eh:.4f})")

    # ---- 1b) PAIRED comparison Entropy vs FedAvg (same seeds), per condition ----
    # Delta_k = metric_Entropy,k - metric_FedAvg,k. Report mean Delta, 95% CI, win-rate.
    paired_rows = []
    report += ["", "PAIRED Entropy - FedAvg (same seeds; negative EER-delta favors Entropy):"]
    for clab, _ in conditions:
        fa, en = f"FedAvg-{clab}", f"Entropy-{clab}"
        if fa not in acc or en not in acc or len(acc[fa]) != len(acc[en]) or len(acc[fa]) < 2:
            continue
        dacc = np.array(acc[en]) - np.array(acc[fa])
        deer = np.array(eer[en]) - np.array(eer[fa])
        am, asd, ah = ci95(dacc); em, esd, eh = ci95(deer)
        acc_sig = (am - ah > 0) or (am + ah < 0)     # 95% CI excludes 0
        eer_sig = (em - eh > 0) or (em + eh < 0)
        paired_rows.append(dict(condition=clab, n=len(dacc),
                                dacc_mean=round(am, 4), dacc_ci95=round(ah, 4), dacc_sig=int(acc_sig),
                                deer_mean=round(em, 4), deer_ci95=round(eh, 4), deer_sig=int(eer_sig)))
        report.append(f"  {clab:6s} dAcc={am:+.4f} (95%CI +/-{ah:.4f}){' *' if acc_sig else '  '}  "
                      f"dEER={em:+.4f} (95%CI +/-{eh:.4f}){' *' if eer_sig else ''}")
    report.append("  (* = 95% CI excludes 0. If none are starred, Entropy is NOT distinguishable "
                  "from FedAvg.)")
    if paired_rows:
        with open(out / "paired_entropy_vs_fedavg.csv", "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(paired_rows[0].keys()))
            w.writeheader(); w.writerows(paired_rows)

    # ---- 2) LaTeX tables — one per stage CSV that exists (robust; not dependent
    #         on summary_all.csv), plus an always-available statistics table. ----
    res = Path(OUT_BASE) / "results"

    def csv_to_tex(src: Path, dst: Path, caption: str) -> bool:
        if not src.exists():
            return False
        with open(src, encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        if not rows:
            return False
        cols = list(rows[0].keys())
        align = "l" * 1 + "r" * (len(cols) - 1)
        L = [r"\begin{table}[t]\centering", f"\\caption{{{caption}}}",
             f"\\begin{{tabular}}{{{align}}}", r"\hline",
             " & ".join(c.replace("_", r"\_") for c in cols) + r" \\", r"\hline"]
        for r in rows:
            L.append(" & ".join(str(r[c]) for c in cols) + r" \\")
        L += [r"\hline", r"\end{tabular}", r"\end{table}"]
        dst.write_text("\n".join(L), "utf-8")
        return True

    table_map = [
        ("baseline_table.tex",   res / "03_baselines" / "baselines.csv",      "Centralized baselines"),
        ("noniid_table.tex",     res / "07_non_iid" / "non_iid.csv",          "Non-IID: FedAvg vs FedProx"),
        ("entropy_table.tex",    res / "08_entropy" / "entropy_vs_fedavg.csv","Entropy vs FedAvg aggregation"),
        ("secureagg_table.tex",  res / "09_secure" / "secure_agg.csv",        "Secure aggregation equivalence"),
        ("dp_table.tex",         res / "10_dp" / "dp_sweep.csv",              "Differential privacy sweep"),
        ("continuous_table.tex", res / "11_continuous" / "continuous_auth.csv","Continuous authentication"),
        ("ablation_table.tex",   res / "12_ablation" / "ablation.csv",        "Ablation study"),
        ("norm_table.tex",       res / "14_norm" / "norm_ablation.csv",       "Normalization ablation"),
        ("lodo_table.tex",       res / "15_lodo" / "lodo_eval.csv",           "Cross-device LODO"),
    ]
    made = [name for name, src, cap in table_map if csv_to_tex(src, tables / name, cap)]

    # statistics_table.tex from in-memory multi-seed (mean +/- SD, 95% CI)
    slines = [r"\begin{table}[t]\centering",
              r"\caption{Multi-seed results (mean $\pm$ SD, 95\% CI)}",
              r"\begin{tabular}{lrr}", r"\hline",
              r"Method & Accuracy & EER \\", r"\hline"]
    for g in acc:
        am, asd, ah = ci95(acc[g]); em, esd, eh = ci95(eer[g])
        slines.append(f"{g.replace('_', chr(92)+'_')} & {am:.4f}$\\pm${asd:.4f} & "
                      f"{em:.4f}$\\pm${esd:.4f} \\\\")
    slines += [r"\hline", r"\end{tabular}", r"\end{table}"]
    (tables / "statistics_table.tex").write_text("\n".join(slines), "utf-8")
    made.append("statistics_table.tex")
    report += ["", f"LaTeX tables generated: {len(made)} -> results/tables/  ({', '.join(made)})", ""]

    # ---- 3) reproducibility manifest (re-write with the generated tables) ----
    write_manifest(res, made)
    report.append("reproducibility manifest -> results/reproducibility.json "
                  f"(norm={MODEL['norm']})")
    report.append("=" * 70)

    txt = "\n".join(report)
    print("\n" + txt)
    (out / "stage15_report.txt").write_text(txt, "utf-8")
    print(f"[stage15] wrote {out} and {tables}")


if __name__ == "__main__":
    main()
