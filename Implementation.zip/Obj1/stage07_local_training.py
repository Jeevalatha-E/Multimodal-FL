"""
STAGE 07 — Single-client local training (roadmap PHASE 11)

Sanity gate before FL: partition the training set into K clients and train each an
INDEPENDENT local model (no aggregation). Confirms local models learn, and gives the
"local-only" baseline that federation must be compared against.

Needs: numpy, torch.  Colab: !python stage07_local_training.py
Outputs -> results/05_local/{stage07_report.txt, local_clients.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import numpy as np

from ppflfm_common import get_feature_dirs, stage_dir, append_results, MODEL, TRAIN, FL, SEED
from ppflfm_eval import classification_metrics, verification_metrics
from ppflfm_ml import (load_windows, set_seed, BehaviorAuthNet, train_model,
                       predict_proba, partition_iid)


def main():
    _, processed, _ = get_feature_dirs()
    out = stage_dir("05_local")
    d = load_windows(processed)
    set_seed(SEED)
    K = FL["n_clients"]
    parts = partition_iid(len(d["X_train"]), K, SEED)
    print(f"[stage07] K={K} clients, IID split sizes={[len(p) for p in parts]}")

    rows, accs, eers = [], [], []
    for k, idx in enumerate(parts):
        sub = dict(d)
        sub["X_train"], sub["y_train"] = d["X_train"][idx], d["y_train"][idx]
        model = BehaviorAuthNet(d["in_dim"], d["n_classes"], norm=MODEL["norm"])
        train_model(model, sub, TRAIN)
        proba = predict_proba(model, d["X_test"])
        cls = classification_metrics(d["y_test"], proba.argmax(1), n_classes=d["n_classes"])
        ver = verification_metrics(proba, d["y_test"], labels=np.arange(d["n_classes"]))
        rows.append(dict(client=k, n_train=len(idx), accuracy=cls["accuracy"],
                         macro_f1=cls["macro_f1"], eer=ver["eer"], auc=ver["auc"]))
        accs.append(cls["accuracy"]); eers.append(ver["eer"])
        print(f"  client {k}: acc={cls['accuracy']:.4f} macroF1={cls['macro_f1']:.4f} EER={ver['eer']:.4f}")

    with open(out / "local_clients.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    append_results([dict(stage="07_local", method="Local-only(mean)", setting=f"K={K}_IID",
                         seed=SEED, task="A+B", accuracy=float(np.mean(accs)),
                         macro_f1=float(np.mean([r['macro_f1'] for r in rows])),
                         eer=float(np.mean(eers)), auc=float(np.mean([r['auc'] for r in rows])))])

    txt = ("=" * 70 + "\nSTAGE 07 - LOCAL-ONLY TRAINING (no aggregation)\n" + "=" * 70 +
           f"\nK={K}  mean acc={np.mean(accs):.4f}  mean EER={np.mean(eers):.4f}\n" +
           "\n".join(f"  client{r['client']}: acc={r['accuracy']:.4f} EER={r['eer']:.4f}" for r in rows) +
           "\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage07_report.txt").write_text(txt, "utf-8")
    print(f"[stage07] wrote {out}")


if __name__ == "__main__":
    main()
