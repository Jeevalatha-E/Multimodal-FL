"""
STAGE 13 — Continuous authentication (roadmap PHASE 21)

Temporal score aggregation: within each intact test stream (user x device), average the
model's softmax over W consecutive windows before deciding. Sweeps W in {1,3,5,10,20}
and reports session-level accuracy + verification (EER/AUC/TAR@FAR). Sessions are never
split (windows already come from the sealed, leakage-safe test partition).

Needs: numpy, torch.  Colab: !python stage13_continuous_authentication.py
Outputs -> results/11_continuous/{stage13_report.txt, continuous_auth.csv} + summary_all.csv
"""
from __future__ import annotations

import csv
import numpy as np

from ppflfm_common import (get_feature_dirs, stage_dir, append_results, write_gate,
                           require_gate, MODEL, TRAIN, CONT_AUTH_W, SEED)
from ppflfm_eval import (classification_metrics, verification_metrics,
                         temporal_aggregate, whole_session_aggregate, stream_runs)
from ppflfm_ml import load_windows, set_seed, BehaviorAuthNet, train_model, predict_proba


def main():
    require_gate("stage04")                 # refuse to run on un-audited features
    _, processed, _ = get_feature_dirs()
    out = stage_dir("11_continuous")
    d = load_windows(processed)
    set_seed(SEED)

    model = BehaviorAuthNet(d["in_dim"], d["n_classes"], norm=MODEL["norm"])
    train_model(model, d, TRAIN)
    proba = predict_proba(model, d["X_test"])
    yte = d["y_test"]
    dev = np.asarray(d["device_test"])
    nC = d["n_classes"]

    # how many test streams can even support each W (stream length >= W)?
    stream_lengths = [b - a for a, b in stream_runs(yte, dev)]
    n_streams = len(stream_lengths)

    rows, ledger, report = [], [], []
    report.append(f"test streams={n_streams}, window/stream length "
                  f"min={min(stream_lengths)} median={int(np.median(stream_lengths))} "
                  f"max={max(stream_lengths)}")
    report.append("SLIDING windows (stride=1); decisions overlap (correlated). "
                  "Streams shorter than W give 0 decisions -> large W is under-sampled.")
    report.append("")
    for W in CONT_AUTH_W:
        Pw, Yw = temporal_aggregate(proba, yte, dev, W, stride=1)
        supporting = sum(1 for L in stream_lengths if L >= W)
        if len(Yw) == 0:
            report.append(f"  W={W:<3} 0 decisions (no stream >= {W} windows)")
            continue
        cls = classification_metrics(Yw, Pw.argmax(1), n_classes=nC)
        ver = verification_metrics(Pw, Yw, labels=np.arange(nC))
        reliable = supporting >= 30           # flag under-sampled operating points
        flag = "" if reliable else "  [UNDER-SAMPLED: few streams support this W]"
        rows.append(dict(W=W, n_decisions=len(Yw), streams_supporting=supporting,
                         session_acc=cls["accuracy"], macro_f1=cls["macro_f1"],
                         eer=ver["eer"], auc=ver["auc"], tar_at_far_1pct=ver.get("tar_at_far_1pct", ""),
                         reliable=int(reliable)))
        ledger.append(dict(stage="13_continuous", method="BehaviorAuthNet", setting=f"W={W}",
                           seed=SEED, task="A+B", accuracy=cls["accuracy"], macro_f1=cls["macro_f1"],
                           balanced_accuracy=cls["balanced_accuracy"], eer=ver["eer"], auc=ver["auc"],
                           macro_eer=ver["macro_eer"], tar_at_far_1pct=ver.get("tar_at_far_1pct", ""),
                           extra=f"decisions={len(Yw)},streams>=W={supporting}"))
        msg = (f"  W={W:<3} decisions={len(Yw):5d} streams>=W={supporting:3d} "
               f"session_acc={cls['accuracy']:.4f} EER={ver['eer']:.4f} "
               f"AUC={ver['auc']:.4f} TAR@1%={ver.get('tar_at_far_1pct',0):.3f}{flag}")
        print(msg); report.append(msg)

    # whole-session: one robust decision per stream (uses ALL its windows)
    Ps, Ys = whole_session_aggregate(proba, yte, dev)
    clsS = classification_metrics(Ys, Ps.argmax(1), n_classes=nC)
    verS = verification_metrics(Ps, Ys, labels=np.arange(nC))
    rows.append(dict(W="session", n_decisions=len(Ys), streams_supporting=n_streams,
                     session_acc=clsS["accuracy"], macro_f1=clsS["macro_f1"],
                     eer=verS["eer"], auc=verS["auc"], tar_at_far_1pct=verS.get("tar_at_far_1pct", ""),
                     reliable=1))
    ledger.append(dict(stage="13_continuous", method="BehaviorAuthNet", setting="whole_session",
                       seed=SEED, task="A+B", accuracy=clsS["accuracy"], macro_f1=clsS["macro_f1"],
                       balanced_accuracy=clsS["balanced_accuracy"], eer=verS["eer"], auc=verS["auc"],
                       macro_eer=verS["macro_eer"], tar_at_far_1pct=verS.get("tar_at_far_1pct", ""),
                       extra=f"decisions={len(Ys)}"))
    sess_msg = (f"  SESSION (all windows/stream) decisions={len(Ys):3d} "
                f"acc={clsS['accuracy']:.4f} EER={verS['eer']:.4f} AUC={verS['auc']:.4f} "
                f"TAR@1%={verS.get('tar_at_far_1pct',0):.3f}")
    print(sess_msg); report.append(""); report.append(sess_msg)

    with open(out / "continuous_auth.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    append_results(ledger)
    txt = ("=" * 70 + "\nSTAGE 13 - CONTINUOUS AUTHENTICATION (temporal aggregation)\n" + "=" * 70 +
           "\n" + "\n".join(report) + "\n" + "=" * 70)
    print("\n" + txt)
    (out / "stage13_report.txt").write_text(txt, "utf-8")
    write_gate("stage13", True, {"n_windows_W": {r["W"]: r["n_decisions"] for r in rows}})
    print(f"[stage13] wrote {out}")


if __name__ == "__main__":
    main()
